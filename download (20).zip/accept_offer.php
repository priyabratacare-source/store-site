<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load configuration – must exist outside web root
$configPath = __DIR__ . '/../config.php';
if (!file_exists($configPath)) {
    $_SESSION['error'] = 'System configuration missing. Please contact administrator.';
    header('Location: employee.php');
    exit;
}
require_once $configPath;

// Required constants from config.php
$requiredConstants = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS', 'SMTP_PORT', 'SMTP_SECURE', 'FROM_EMAIL', 'FROM_NAME', 'APP_URL'];
foreach ($requiredConstants as $const) {
    if (!defined($const)) {
        $_SESSION['error'] = "Configuration error: $const is not defined.";
        header('Location: employee.php');
        exit;
    }
}

$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';
$siteName = SITE_NAME ?? 'CodeBihin';
try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name='site_name'");
    $siteName = $stmt->fetchColumn() ?: $siteName;
} catch (Exception $e) {
    // ignore – use default
}

// --- Validate input ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method.';
    header('Location: employee.php');
    exit;
}

$employee_id = isset($_POST['employee_id']) ? (int)$_POST['employee_id'] : 0;
$offered_role = trim($_POST['offered_role'] ?? '');
$offered_salary = isset($_POST['offered_salary']) ? floatval($_POST['offered_salary']) : 0;
$joining_date = $_POST['joining_date'] ?? '';
$message_text = trim($_POST['message'] ?? '');

if ($employee_id <= 0 || empty($offered_role) || $offered_salary <= 0 || empty($joining_date)) {
    $_SESSION['error'] = 'All required fields (employee, role, salary, joining date) must be filled.';
    header('Location: employee.php');
    exit;
}

// Validate joining date
$dateObj = DateTime::createFromFormat('Y-m-d', $joining_date);
if (!$dateObj || $dateObj->format('Y-m-d') !== $joining_date) {
    $_SESSION['error'] = 'Invalid joining date format. Use YYYY-MM-DD.';
    header('Location: employee.php');
    exit;
}

// --- Fetch employee details ---
$empStmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$empStmt->execute([$employee_id]);
$employee = $empStmt->fetch();
if (!$employee) {
    $_SESSION['error'] = 'Employee not found.';
    header('Location: employee.php');
    exit;
}

// Ensure employee has at least one email address
if (empty($employee['personal_email'])) {
    $_SESSION['error'] = 'Employee has no personal email address on file. Cannot send offer.';
    header('Location: employee.php');
    exit;
}

// Check if employee already has a pending or accepted offer
$checkOffer = $pdo->prepare("SELECT id, status FROM job_offers WHERE employee_id = ? AND status IN ('pending', 'accepted')");
$checkOffer->execute([$employee_id]);
if ($checkOffer->fetch()) {
    $_SESSION['error'] = 'This employee already has a pending or accepted offer. Please resolve that first.';
    header('Location: employee.php');
    exit;
}

// --- Create offer record ---
$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', strtotime('+7 days'));
$signature_id = date('dmy') . substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 3);
$accept_link = rtrim(APP_URL, '/') . "/accept_offer.php?token=" . urlencode($token);
$letter_date = date('d F Y');

// HTML email body
$emailBodyHTML = "
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'><title>Offer Letter</title></head>
<body style='font-family:Arial, sans-serif; background:#f4f4f4; padding:20px;'>
<div style='max-width:650px; margin:auto; background:#fff; border-radius:12px; padding:30px;'>
    <div style='text-align:center;'><img src='" . rtrim(APP_URL, '/') . "/logo.png' width='100' alt='Logo'><h2>Offer of Employment</h2></div>
    <p>Date: $letter_date</p>
    <p>Dear <strong>" . htmlspecialchars($employee['name']) . "</strong>,</p>
    <p>We are pleased to offer you the position of <strong>" . htmlspecialchars($offered_role) . "</strong> at $siteName.</p>
    <p><strong>Salary:</strong> ₹ " . number_format($offered_salary, 2) . " per month.<br>
    <strong>Joining Date:</strong> " . date('d-m-Y', strtotime($joining_date)) . "</p>
    <p>" . nl2br(htmlspecialchars($message_text)) . "</p>
    <p>To accept this offer, please click the link below and complete the joining process:</p>
    <p style='text-align:center;'><a href='$accept_link' style='background:#2f6db3; color:white; padding:10px 20px; text-decoration:none; border-radius:30px;'>Accept Offer</a></p>
    <p><strong>This link expires on " . date('d-m-Y H:i', strtotime($expires)) . ".</strong></p>
    <hr>
    <p>Digitally Signed By: <strong>" . htmlspecialchars($admin_name) . "</strong><br>Signature ID: $signature_id</p>
    <p>© $siteName – All Rights Reserved</p>
</div>
</body>
</html>";

// Plain text version
$emailBodyText = "Offer of Employment\n\n";
$emailBodyText .= "Date: $letter_date\n";
$emailBodyText .= "Dear {$employee['name']},\n\n";
$emailBodyText .= "We are pleased to offer you the position of $offered_role at $siteName.\n";
$emailBodyText .= "Salary: ₹ " . number_format($offered_salary, 2) . " per month.\n";
$emailBodyText .= "Joining Date: " . date('d-m-Y', strtotime($joining_date)) . "\n\n";
$emailBodyText .= "$message_text\n\n";
$emailBodyText .= "To accept this offer, please visit the following link:\n$accept_link\n";
$emailBodyText .= "This link expires on " . date('d-m-Y H:i', strtotime($expires)) . ".\n\n";
$emailBodyText .= "Digitally Signed By: $admin_name (Signature ID: $signature_id)\n";
$emailBodyText .= "© $siteName – All Rights Reserved\n";

// --- Start transaction ---
$pdo->beginTransaction();
try {
    $insert = $pdo->prepare("
        INSERT INTO job_offers 
        (employee_id, token, offered_role, offered_salary, joining_date, message, created_by, signature_id, created_at, expires_at, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'pending')
    ");
    $insert->execute([$employee_id, $token, $offered_role, $offered_salary, $joining_date, $message_text, $admin_name, $signature_id, $expires]);

    // --- Send email using PHPMailer ---
    $mail = new PHPMailer(true);
    $mail->CharSet = 'UTF-8';
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USER;
    $mail->Password = SMTP_PASS;
    $mail->SMTPSecure = SMTP_SECURE;
    $mail->Port = SMTP_PORT;
    $mail->setFrom(FROM_EMAIL, FROM_NAME);
    $mail->addAddress($employee['personal_email']);
    if (!empty($employee['company_email'])) {
        $mail->addAddress($employee['company_email']);
    }
    if (defined('CC_EMAIL') && CC_EMAIL) {
        $mail->addCC(CC_EMAIL);
    }
    $mail->isHTML(true);
    $mail->Subject = "Offer Letter – $offered_role at $siteName";
    $mail->Body = $emailBodyHTML;
    $mail->AltBody = $emailBodyText;
    $mail->send();

    $pdo->commit();
    $_SESSION['message'] = "Offer letter sent successfully to {$employee['name']}.";
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Offer letter failed for employee $employee_id: " . $e->getMessage());
    $_SESSION['error'] = "Failed to send offer letter. Please check email configuration or contact admin. Error: " . $e->getMessage();
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Database error in send_offer: " . $e->getMessage());
    $_SESSION['error'] = "Database error – could not create offer record.";
}

// Redirect back to employee management page
header('Location: employee.php');
exit;