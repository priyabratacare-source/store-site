<?php
session_start();
require_once 'db.php';

$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $stmt->execute();
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (PDOException $e) {}

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE remember_token = ? AND token_expires > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        if ($user && ($user['username'] === 'admin' || $user['email'] === 'admin@codebihin.in')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            header('Location: dashboard.php');
            exit;
        } else {
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }
    } catch (PDOException $e) {}
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    if ($identifier && $password) {
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("SELECT id, username, email, password_hash FROM users WHERE email = ? OR username = ?");
            $stmt->execute([$identifier, $identifier]);
            $user = $stmt->fetch();
            if ($user && password_verify($password, $user['password_hash'])) {
                if ($user['username'] === 'admin' || $user['email'] === 'admin@codebihin.in') {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    if ($remember) {
                        $token = bin2hex(random_bytes(32));
                        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
                        $pdo->prepare("UPDATE users SET remember_token = ?, token_expires = ? WHERE id = ?")
                            ->execute([$token, $expires, $user['id']]);
                        setcookie('remember_token', $token, time() + 30*86400, '/', '', true, true);
                    }
                    session_regenerate_id(true);
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $error = 'Access denied. Only administrator can log in.';
                }
            } else {
                $error = 'Invalid credentials.';
            }
        } catch (PDOException $e) {
            $error = 'System error.';
        }
    } else {
        $error = 'Please fill all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($siteName) ?> · Sign in</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
        body{display:flex;height:100vh;width:100%;overflow:hidden;}
        .left{width:36%;background:rgba(12,25,38,0.94);backdrop-filter:blur(14px);color:#fff;padding:48px 44px;display:flex;flex-direction:column;justify-content:center;border-right:1px solid rgba(255,255,255,0.08);}
        @media (max-width:880px){.left{width:45%;padding:36px 28px;}}
        @media (max-width:700px){body{flex-direction:column;}.left{width:100%;height:60%;}.right{width:100%;height:40%;}}
        .logo{display:flex;align-items:center;gap:14px;margin-bottom:48px;}
        .logo-img{height:52px;}
        .logo span{font-size:32px;font-weight:800;background:linear-gradient(125deg,#FFF,#c7e2ff);background-clip:text;color:transparent;}
        h3{font-size:26px;font-weight:700;margin-bottom:28px;border-left:4px solid #f9b233;padding-left:18px;}
        .input-wrapper{margin-bottom:20px;}
        label{font-size:13px;font-weight:600;display:block;color:#eef4ff;margin-bottom:6px;}
        input{width:100%;padding:13px 16px;border-radius:20px;border:1px solid #3d5e7e;background:rgba(20,35,55,0.8);color:#fff;outline:none;}
        input:focus{border-color:#f9b233;box-shadow:0 0 0 3px rgba(249,178,51,0.25);}
        .pass-wrapper{position:relative;}
        .pass-wrapper i{position:absolute;right:16px;top:50%;transform:translateY(-50%);cursor:pointer;}
        .options{display:flex;justify-content:space-between;align-items:center;margin:22px 0 32px;font-size:13px;}
        .options a{color:#9bc0ff;text-decoration:none;}
        .options a:hover{color:#f9b233;}
        button{width:100%;padding:14px;background:linear-gradient(100deg,#2f6db3,#1e5290);border:none;border-radius:44px;color:white;font-weight:700;cursor:pointer;}
        button:hover{transform:translateY(-2px);}
        .message{margin-bottom:20px;padding:12px;border-radius:20px;text-align:center;}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;color:#ffcfcf;}
        .right{width:64%;position:relative;background-size:cover;background-position:center;transition:background-image 0.9s;}
        .right::after{content:"";position:absolute;inset:0;background:linear-gradient(125deg,rgba(0,0,0,0.2),rgba(0,0,0,0.45));}
        .overlay-text{position:absolute;bottom:28px;right:28px;color:white;z-index:3;backdrop-filter:blur(12px);background:rgba(0,0,0,0.5);padding:12px 26px;border-radius:44px;text-align:right;}
        .image-status{position:absolute;bottom:18px;left:20px;font-size:11px;background:rgba(0,0,0,0.55);padding:6px 14px;border-radius:40px;color:#eef2ff;}
    </style>
</head>
<body>
<div class="left">
    <div class="logo"><img class="logo-img" src="https://admin.codebihin.in/logo.png" alt="<?= htmlspecialchars($siteName) ?>"><span><?= htmlspecialchars($siteName) ?></span></div>
    <h3>Access dashboard</h3>
    <?php if($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
        <div class="input-wrapper"><label>Email or username</label><input type="text" name="identifier" required autocomplete="username"></div>
        <div class="input-wrapper"><label>Password</label><div class="pass-wrapper"><input type="password" name="password" id="password" required><i class="fa-regular fa-eye" id="togglePassword"></i></div></div>
        <div class="options"><label><input type="checkbox" name="remember"> Remember me</label><a href="forgot.php">Forgot password?</a></div>
        <button type="submit"><i class="fa-solid fa-right-to-bracket"></i> Sign in</button>
    </form>
</div>
<div class="right" id="dynamicBgRight">
    <div class="overlay-text"><h2><?= htmlspecialchars($siteName) ?></h2><p>secure platform · © 2026</p></div>
    <div class="image-status"><i class="fa-regular fa-images"></i> <span id="refreshCounter">dynamic background</span></div>
</div>
<script>
    let counter=0, interval;
    function updateBg(){ const img=new Image(); img.onload=()=>{ document.getElementById('dynamicBgRight').style.backgroundImage=`url('${img.src}')`; document.getElementById('refreshCounter').innerText=`⟳ fresh #${++counter}`; }; img.src=`https://picsum.photos/1920/1080?random=${Date.now()}`; }
    updateBg(); interval=setInterval(updateBg,7000);
    document.getElementById('togglePassword')?.addEventListener('click',function(){ let p=document.getElementById('password'); p.type=p.type==='password'?'text':'password'; this.classList.toggle('fa-eye-slash'); });
    window.addEventListener('beforeunload',()=>clearInterval(interval));
</script>
</body>
</html>