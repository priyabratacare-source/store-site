<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (Exception $e) {
    // fallback
}

$error = '';
$message = '';
$notice = ['id' => 0, 'notice_number' => '', 'title' => '', 'notice_date' => date('Y-m-d'), 'content' => '', 'status' => 'unlisted', 'scheduled_date' => '', 'is_signed' => 0];

function generateNoticeNumber($pdo, $year = null) {
    if (!$year) $year = date('y');
    $prefix = "CB/$year/";
    $stmt = $pdo->prepare("SELECT notice_number FROM notices WHERE notice_number LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$prefix . '%']);
    $last = $stmt->fetchColumn();
    if ($last) {
        $parts = explode('/', $last);
        $seq = (int)end($parts);
        $newSeq = str_pad($seq + 1, 3, '0', STR_PAD_LEFT);
    } else {
        $newSeq = '001';
    }
    return $prefix . $newSeq;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $notice_date = $_POST['notice_date'] ?? date('Y-m-d');
    $content = trim($_POST['content'] ?? '');
    $status = $_POST['status'] ?? 'unlisted';
    $scheduled_date = !empty($_POST['scheduled_date']) ? $_POST['scheduled_date'] : null;

    if (!$title || !$content) {
        $error = "Title and content required.";
    } else {
        try {
            $pdo = getDBConnection();
            if ($id > 0) {
                $upd = $pdo->prepare("UPDATE notices SET title=?, notice_date=?, content=?, status=?, scheduled_date=? WHERE id=?");
                $upd->execute([$title, $notice_date, $content, $status, $scheduled_date, $id]);
                $message = "Notice updated successfully.";
            } else {
                $notice_number = generateNoticeNumber($pdo, date('y'));
                $ins = $pdo->prepare("INSERT INTO notices (notice_number, title, notice_date, content, status, scheduled_date) VALUES (?,?,?,?,?,?)");
                $ins->execute([$notice_number, $title, $notice_date, $content, $status, $scheduled_date]);
                $id = $pdo->lastInsertId();
                $message = "Notice created. Number: $notice_number";
            }
            header("Location: create_notice.php?id=$id&msg=" . urlencode($message));
            exit;
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT * FROM notices WHERE id=?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if ($data) $notice = $data;
        else $error = "Notice not found.";
    } catch (PDOException $e) {
        $error = "DB error.";
    }
}
if (isset($_GET['msg'])) $message = $_GET['msg'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($siteName) ?> · <?= $notice['id'] ? 'Edit' : 'New' ?> Notice</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }
        body {
            background: #0f172a;
            display: flex;
        }
        /* Sidebar is already fixed by menu.php */
        .main {
            flex: 1;
            margin-left: 280px;   /* Fixed sidebar width */
            padding: 28px 36px;
            transition: margin-left 0.2s ease;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }
        .welcome h1 {
            font-size: 28px;
            color: #ffffff;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
            background: rgba(255,255,255,0.05);
            padding: 8px 20px;
            border-radius: 48px;
            backdrop-filter: blur(4px);
        }
        .user-avatar {
            background: #2f6db3;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
        }
        .user-info .name {
            font-weight: 600;
            color: white;
        }
        .logout-btn {
            background: rgba(231,76,60,0.2);
            padding: 8px 16px;
            border-radius: 40px;
            color: #ffaaa5;
            text-decoration: none;
        }
        .logout-btn:hover {
            background: rgba(231,76,60,0.4);
            color: white;
        }
        .form-container {
            background: rgba(20,35,55,0.7);
            backdrop-filter: blur(8px);
            padding: 32px;
            border-radius: 28px;
            max-width: 800px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .form-group {
            margin-bottom: 24px;
        }
        label {
            display: block;
            color: #cbd5e6;
            margin-bottom: 8px;
            font-weight: 500;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 16px;
            color: white;
            font-size: 14px;
        }
        textarea {
            min-height: 150px;
        }
        .btn-primary {
            background: #f9b233;
            border: none;
            padding: 12px 28px;
            border-radius: 40px;
            color: #0f172a;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-primary:hover {
            background: #ffc55a;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.1);
            padding: 12px 28px;
            border-radius: 40px;
            color: #cbd5e6;
            text-decoration: none;
            transition: 0.2s;
        }
        .btn-secondary:hover {
            background: rgba(255,255,255,0.2);
        }
        .btn-preview {
            background: #2ecc71;
            border: none;
            padding: 12px 28px;
            border-radius: 40px;
            color: #0f172a;
            font-weight: bold;
            cursor: pointer;
            margin-right: 10px;
            transition: 0.2s;
        }
        .btn-preview:hover {
            background: #27ae60;
            transform: translateY(-2px);
        }
        .message {
            padding: 12px 20px;
            border-radius: 20px;
            margin-bottom: 20px;
        }
        .success {
            background: rgba(46,204,113,0.2);
            border-left: 4px solid #2ecc71;
            color: #c8f0e1;
        }
        .error {
            background: rgba(231,76,60,0.2);
            border-left: 4px solid #e74c3c;
            color: #ffcfcf;
        }
        .signed-info {
            background: rgba(52,152,219,0.2);
            padding: 16px;
            border-radius: 20px;
            margin-top: 20px;
            border-left: 3px solid #3498db;
        }
        .button-group {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        @media (max-width: 768px) {
            .main {
                margin-left: 80px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome">
            <h1><?= $notice['id'] ? 'Edit Notice' : 'Create Notice' ?></h1>
        </div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?></div>
            <div class="user-info">
                <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="message success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST" id="noticeForm">
            <input type="hidden" name="id" value="<?= $notice['id'] ?>">
            <div class="form-group">
                <label>Notice Number</label>
                <input type="text" value="<?= $notice['id'] ? htmlspecialchars($notice['notice_number']) : 'Auto-generated (CB/YY/XXX)' ?>" disabled style="opacity:0.7">
            </div>
            <div class="form-group">
                <label>Title *</label>
                <input type="text" name="title" value="<?= htmlspecialchars($notice['title']) ?>" required>
            </div>
            <div class="form-group">
                <label>Notice Date</label>
                <input type="date" name="notice_date" value="<?= $notice['notice_date'] ?>">
            </div>
            <div class="form-group">
                <label>Content *</label>
                <textarea name="content" required><?= htmlspecialchars($notice['content']) ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="published" <?= $notice['status'] == 'published' ? 'selected' : '' ?>>Published</option>
                    <option value="scheduled" <?= $notice['status'] == 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
                    <option value="unlisted" <?= $notice['status'] == 'unlisted' ? 'selected' : '' ?>>Unlisted</option>
                </select>
            </div>
            <div class="form-group" id="scheduledGroup" style="display: <?= $notice['status'] == 'scheduled' ? 'block' : 'none' ?>">
                <label>Scheduled Date & Time (IST)</label>
                <input type="datetime-local" name="scheduled_date" value="<?= $notice['scheduled_date'] ? date('Y-m-d\TH:i', strtotime($notice['scheduled_date'])) : '' ?>">
            </div>
            <div class="button-group">
                <button type="button" class="btn-preview" onclick="previewCurrent()"><i class="fas fa-eye"></i> Preview</button>
                <button type="submit" class="btn-primary"><i class="fas fa-save"></i> <?= $notice['id'] ? 'Update' : 'Create' ?> Notice</button>
                <a href="notices.php" class="btn-secondary">Cancel</a>
            </div>
        </form>

        <?php if ($notice['id'] && $notice['is_signed']): ?>
        <div class="signed-info">
            <i class="fas fa-certificate"></i> This notice is digitally signed.<br>
            Signature ID: <?= htmlspecialchars($notice['signature_id']) ?><br>
            Signed by: <?= htmlspecialchars($notice['signed_by']) ?> (<?= htmlspecialchars($notice['signed_email']) ?>)<br>
            Signed at: <?= date('d-m-Y h:i:s A', strtotime($notice['signed_at'])) ?> IST
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Preview Modal -->
<div id="previewModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:white; border-radius:24px; width:90%; max-width:800px; max-height:90%; overflow:auto; padding:30px; position:relative;">
        <button onclick="closePreview()" style="position:absolute; top:15px; right:20px; background:#e74c3c; color:white; border:none; border-radius:50%; width:36px; height:36px; cursor:pointer;">✕</button>
        <div id="previewContent"></div>
    </div>
</div>

<script>
function closePreview() {
    document.getElementById('previewModal').style.display = 'none';
}

function previewCurrent() {
    let title = document.querySelector('input[name="title"]').value;
    let content = document.querySelector('textarea[name="content"]').value;
    let noticeDate = document.querySelector('input[name="notice_date"]').value;
    let status = document.querySelector('select[name="status"]').value;
    if (!title || !content) {
        alert("Please fill title and content before preview.");
        return;
    }
    let noticeNumber = <?= $notice['id'] ? json_encode($notice['notice_number']) : "'[Auto-generated]'" ?>;
    let isSigned = <?= $notice['is_signed'] ? 'true' : 'false' ?>;
    let signedBy = <?= json_encode($notice['signed_by']) ?>;
    let signedEmail = <?= json_encode($notice['signed_email']) ?>;
    let signedAt = <?= json_encode($notice['signed_at'] ? date('d-m-Y h:i:s A', strtotime($notice['signed_at'])) : null) ?>;
    let signatureId = <?= json_encode($notice['signature_id']) ?>;

    let html = `<h1 style="color:#1e293b; border-bottom:2px solid #e2e8f0; padding-bottom:10px;">${escapeHtml(title)}</h1>
                <div style="display:flex; justify-content:space-between; margin:15px 0; color:#475569;">
                  <div><strong>Notice No.:</strong> ${escapeHtml(noticeNumber)}</div>
                  <div><strong>Date:</strong> ${noticeDate}</div>
                  <div><strong>Status:</strong> <span class="badge badge-${status}">${status}</span></div>
                </div>`;
    if (isSigned && signedBy) {
        html += `<div style="background:#e6f7e6; padding:12px 16px; border-radius:12px; margin:15px 0; display:flex; align-items:center; gap:12px; border-left:4px solid #2ecc71;">
                    <i class="fas fa-check-circle" style="color:#2ecc71; font-size:28px;"></i>
                    <div>
                        <strong style="color:#2c3e50; font-size:16px;">Digitally Signed</strong><br>
                        <span style="font-size:14px;">Issuer: ${escapeHtml(signedBy)}<br>
                        Email: ${escapeHtml(signedEmail)}<br>
                        Signed on: ${signedAt}<br>
                        Signature ID: ${escapeHtml(signatureId)}</span>
                    </div>
                 </div>`;
    }
    html += `<hr style="margin:20px 0">
             <div style="font-size:16px; line-height:1.6; color:#0f172a;">${escapeHtml(content).replace(/\n/g, '<br>')}</div>`;
    document.getElementById('previewContent').innerHTML = html;
    document.getElementById('previewModal').style.display = 'flex';
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

document.querySelector('select[name="status"]').addEventListener('change', function() {
    document.getElementById('scheduledGroup').style.display = this.value === 'scheduled' ? 'block' : 'none';
});
</script>
</body>
</html>