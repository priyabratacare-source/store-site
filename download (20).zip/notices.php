<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

// Optional: permission check for notices (admin only)
// If you want only users with 'notices.php' permission to access, uncomment below
/*
if (!function_exists('userHasPermission')) {
    function userHasPermission($pdo, $userId, $permissionFile) {
        $sql = "SELECT COUNT(*) FROM user_roles ur
                JOIN role_permissions rp ON ur.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE ur.user_id = ? AND p.file_name = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId, $permissionFile]);
        return $stmt->fetchColumn() > 0;
    }
}
$pdo = getDBConnection();
if (!userHasPermission($pdo, $_SESSION['user_id'], 'notices.php')) {
    die("Access denied: you do not have permission to view notices.");
}
*/

$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (Exception $e) {
    error_log("Notices: Could not fetch site name - " . $e->getMessage());
}

$message = '';
$error = '';

// Delete notice
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $pdo = getDBConnection();
        $del = $pdo->prepare("DELETE FROM notices WHERE id = ?");
        $del->execute([$id]);
        $message = "Notice deleted.";
    } catch (PDOException $e) {
        $error = "Delete failed.";
    }
    header("Location: notices.php?msg=" . urlencode($message) . "&err=" . urlencode($error));
    exit;
}

// Sign notice
if (isset($_GET['sign'])) {
    $id = (int)$_GET['sign'];
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT is_signed FROM notices WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetchColumn()) {
            $error = "Already signed.";
        } else {
            $sigId = 'SIG-' . strtoupper(uniqid());
            $update = $pdo->prepare("UPDATE notices SET is_signed=1, signature_id=?, signed_by=?, signed_email=?, signed_at=NOW() WHERE id=?");
            $update->execute([$sigId, $_SESSION['username'], $_SESSION['email'], $id]);
            $message = "Signed! ID: $sigId";
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
    header("Location: notices.php?msg=" . urlencode($message) . "&err=" . urlencode($error));
    exit;
}

if (isset($_GET['msg'])) $message = $_GET['msg'];
if (isset($_GET['err'])) $error = $_GET['err'];

// Fetch notices
$notices = [];
try {
    $pdo = getDBConnection();
    $notices = $pdo->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();
} catch (PDOException $e) {
    $error = "DB error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($siteName) ?> · Notices</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }
        body {
            background: #0f172a;
            display: flex;
        }
        /* Main content – offset by fixed sidebar */
        .main {
            flex: 1;
            margin-left: 280px;
            padding: 28px 36px;
            overflow-y: auto;
            transition: margin-left 0.2s ease;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }
        .welcome h1 {
            font-size: 28px;
            color: #ffffff;
            font-weight: 600;
        }
        .welcome p {
            color: #94a3b8;
            margin-top: 6px;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
            background: rgba(255,255,255,0.05);
            padding: 8px 20px;
            border-radius: 48px;
            backdrop-filter: blur(4px);
        }
        .user-avatar {
            background: #2f6db3;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
            color: white;
        }
        .user-info .name {
            font-weight: 600;
            color: white;
        }
        .user-info .email {
            font-size: 12px;
            color: #94a3b8;
        }
        .logout-btn {
            background: rgba(231,76,60,0.2);
            border: none;
            padding: 8px 16px;
            border-radius: 40px;
            color: #ffaaa5;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .logout-btn:hover {
            background: rgba(231,76,60,0.4);
            color: white;
        }
        .btn-primary {
            background: #2f6db3;
            padding: 10px 20px;
            border-radius: 40px;
            color: white;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        .btn-primary:hover {
            background: #1e4d82;
            transform: translateY(-2px);
        }
        table {
            width: 100%;
            background: rgba(20,35,55,0.5);
            border-radius: 24px;
            border-collapse: collapse;
            overflow: hidden;
        }
        th, td {
            padding: 14px 20px;
            text-align: left;
            color: #e2e8f0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        th {
            background: rgba(0,0,0,0.3);
            font-weight: 600;
        }
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
        }
        .badge-published {
            background: rgba(46,204,113,0.2);
            color: #2ecc71;
        }
        .badge-scheduled {
            background: rgba(241,196,15,0.2);
            color: #f1c40f;
        }
        .badge-unlisted {
            background: rgba(149,165,166,0.2);
            color: #bdc3c7;
        }
        .action-icons a, .action-icons button {
            background: none;
            border: none;
            color: #94a3b8;
            margin-right: 12px;
            cursor: pointer;
            font-size: 16px;
        }
        .action-icons a:hover {
            color: #f9b233;
        }
        .message {
            padding: 12px;
            border-radius: 20px;
            margin-bottom: 20px;
        }
        .success {
            background: rgba(46,204,113,0.2);
            border-left: 4px solid #2ecc71;
            color: #c8f0e1;
        }
        .error {
            background: rgba(231,76,60,0.2);
            border-left: 4px solid #e74c3c;
            color: #ffcfcf;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .main {
                margin-left: 80px;
                padding: 20px;
            }
            th, td {
                padding: 10px;
                font-size: 13px;
            }
        }
    </style>
</head>
<body>

<?php include 'menu.php'; ?>

<div class="main">
    <div class="top-bar">
        <div class="welcome">
            <h1>Notice Board</h1>
            <p>Create, sign & manage notices</p>
        </div>
        <div class="user-menu">
            <div class="user-avatar">
                <?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?>
            </div>
            <div class="user-info">
                <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></div>
                <div class="email"><?= htmlspecialchars($_SESSION['email'] ?? '') ?></div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="message success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div style="margin-bottom: 20px; text-align: right">
        <a href="create_notice.php" class="btn-primary"><i class="fas fa-plus"></i> New Notice</a>
    </div>

    <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Notice No.</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Signed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($notices) > 0): ?>
                    <?php foreach ($notices as $n): ?>
                        <tr>
                            <td><?= $n['id'] ?></td>
                            <td><?= htmlspecialchars($n['notice_number']) ?></td>
                            <td><?= htmlspecialchars($n['title']) ?></td>
                            <td><?= date('d-m-Y', strtotime($n['notice_date'])) ?></td>
                            <td><span class="badge badge-<?= $n['status'] ?>"><?= ucfirst($n['status']) ?></span></td>
                            <td><?= $n['is_signed'] ? '<i class="fas fa-certificate" style="color:#3498db"></i> Signed' : 'Unsigned' ?></td>
                            <td class="action-icons">
                                <a href="create_notice.php?id=<?= $n['id'] ?>"><i class="fas fa-edit"></i></a>
                                <?php if (!$n['is_signed']): ?>
                                    <a href="#" onclick="confirmSign(<?= $n['id'] ?>, '<?= addslashes($n['title']) ?>')"><i class="fas fa-signature" style="color:#f9b233"></i></a>
                                <?php endif; ?>
                                <a href="#" onclick="confirmDelete(<?= $n['id'] ?>)"><i class="fas fa-trash-alt"></i></a>
                                <a href="#" onclick="previewNotice(<?= $n['id'] ?>)"><i class="fas fa-eye" style="color:#2ecc71"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">No notices found. Click "New Notice" to create one.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Preview Modal -->
<div id="previewModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:white; border-radius:24px; width:90%; max-width:800px; max-height:90%; overflow:auto; padding:30px; position:relative;">
        <button onclick="closePreview()" style="position:absolute; top:15px; right:20px; background:#e74c3c; color:white; border:none; border-radius:50%; width:36px; height:36px; cursor:pointer;">✕</button>
        <div id="previewContent"></div>
    </div>
</div>

<script>
function confirmDelete(id) {
    if (confirm('Delete this notice?')) {
        location.href = 'notices.php?delete=' + id;
    }
}

function confirmSign(id, title) {
    if (confirm(`Sign notice "${title}"? This action is irreversible.`)) {
        location.href = 'notices.php?sign=' + id;
    }
}

function closePreview() {
    document.getElementById('previewModal').style.display = 'none';
}

function previewNotice(id) {
    fetch('get_notice.php?id=' + id)
        .then(res => res.json())
        .then(data => {
            if (data.error) alert(data.error);
            else {
                let html = `<h1 style="color:#1e293b;">${escapeHtml(data.title)}</h1>
                           <p><strong>No.:</strong> ${escapeHtml(data.notice_number)} | <strong>Date:</strong> ${data.notice_date} | <strong>Status:</strong> ${data.status}</p>`;
                if (data.is_signed) {
                    html += `<div style="background:#e6f7e6; padding:10px; margin:15px 0; border-left:4px solid #2ecc71;">
                                <i class="fas fa-check-circle" style="color:#2ecc71;"></i> <strong>Digitally Signed</strong><br>
                                Issuer: ${escapeHtml(data.signed_by)}<br>
                                Email: ${escapeHtml(data.signed_email)}<br>
                                Signed on: ${data.signed_at}<br>
                                Signature ID: ${escapeHtml(data.signature_id)}
                             </div>`;
                }
                html += `<hr>${data.content}`;
                document.getElementById('previewContent').innerHTML = html;
                document.getElementById('previewModal').style.display = 'flex';
            }
        })
        .catch(err => alert('Preview error: ' + err));
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}
</script>
</body>
</html>