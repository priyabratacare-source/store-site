<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';

// Fetch site name
$siteName = 'CodeBihin';
try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (PDOException $e) {
    $siteName = 'CodeBihin';
}

$error = '';
$success = '';

$empId = (int)($_GET['id'] ?? 0);
if (!$empId) {
    die('No employee selected.');
}

// Fetch employee details
$stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$stmt->execute([$empId]);
$employee = $stmt->fetch();
if (!$employee) {
    die('Employee not found.');
}
if ($employee['resign'] == 1) {
    die('This employee is already fired/resigned.');
}

// Handle termination form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_fire'])) {
    $reason = trim($_POST['termination_reason']);
    if (empty($reason)) {
        $error = 'Please provide a termination reason.';
    } else {
        try {
            $pdo->beginTransaction();

            // Generate signature ID: DDMMYY + 3 random chars
            $sigId = date('dmy') . substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 3);

            // Update employee: mark as resigned, record details
            $update = $pdo->prepare("
                UPDATE Employee 
                SET resign = 1, 
                    resign_date = CURDATE(), 
                    termination_reason = ?, 
                    termination_by = ?, 
                    termination_signature_id = ?,
                    terminated_at = NOW(),
                    blocked = 1  -- ensure they cannot log in
                WHERE id = ?
            ");
            $update->execute([$reason, $admin_name, $sigId, $empId]);

            // Optional: Insert into termination_log table (create if needed)
            // We'll skip for now, but you can add later.

            $pdo->commit();

            // ---------- Build Termination Letter ----------
            $letter_date = date('d F Y');
            $employee_name = $employee['name'];
            $employee_id_no = $employee['id_no'];
            $employee_company_email = $employee['company_email'];
            $employee_personal_email = $employee['personal_email'];

            $emailBody = "
            <!DOCTYPE html>
            <html>
            <head><meta charset='UTF-8'><title>Termination of Employment</title></head>
            <body style='font-family: Arial, sans-serif; background:#f4f4f4; padding:20px;'>
            <div style='max-width:650px; margin:auto; background:#fff; border-radius:12px; padding:30px; box-shadow:0 0 10px rgba(0,0,0,0.1);'>
                <div style='text-align:center;'>
                    <img src='https://admin.codebihin.in/logo.png' alt='{$siteName}' style='width:100px;'>
                    <h2>OFFICIAL TERMINATION LETTER</h2>
                </div>
                <p>Date: {$letter_date}</p>
                <p>To: <strong>{$employee_name}</strong></p>
                <p>Employee ID: <strong>{$employee_id_no}</strong></p>
                <hr>
                <p>Dear {$employee_name},</p>
                <p>After a thorough review of your conduct and performance, the management has decided to terminate your employment with <strong>{$siteName}</strong>, effective immediately.</p>
                <p><strong>Reason for termination:</strong><br> {$reason}</p>
                <p>As a result of this decision:</p>
                <ul>
                    <li>Your access to all company systems, including your official email (<strong>{$employee_company_email}</strong>) and internal portals, has been permanently revoked.</li>
                    <li>Your personal email (<strong>{$employee_personal_email}</strong>) will no longer receive any official communications.</li>
                    <li>You are hereby instructed to cease all activities on behalf of the company.</li>
                    <li>You will not be able to log in to any company‑associated platforms.</li>
                </ul>
                <p>All your data and access rights have been removed from our systems in compliance with data protection policies.</p>
                <p>This letter serves as the official confirmation of your termination. Please return any company property in your possession at the earliest.</p>
                <div style='background:#f8fafc; padding:15px; border-radius:12px; margin-top:20px;'>
                    <p><strong>Digitally Signed</strong></p>
                    <p><strong>Signature ID:</strong> {$sigId}<br>
                    <strong>Issued By:</strong> {$admin_name}<br>
                    <strong>Portal:</strong> {$siteName} HR Management</p>
                    <p>This is a system‑generated document and does not require a physical signature.</p>
                </div>
                <hr>
                <p>Thank you for your service. We wish you the best in your future endeavors.</p>
                <p>Sincerely,<br><strong>Team {$siteName}</strong></p>
                <div style='text-align:center; font-size:12px; color:#64748b; margin-top:30px;'>
                    &copy; " . date('Y') . " {$siteName} – All Rights Reserved
                </div>
            </div>
            </body>
            </html>";

            // Send email
            $mail = new PHPMailer(true);
            $mail->CharSet = 'UTF-8';
            $mail->isSMTP();
            $mail->Host = 'smtp.zoho.in';
            $mail->SMTPAuth = true;
            $mail->Username = 'info@codebihin.in';
            $mail->Password = '5PJxDcP4K8Tc';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('info@codebihin.in', $siteName);
            $mail->addAddress($employee['personal_email']);
            $mail->addAddress($employee['company_email']);
            $mail->addCC('admin@codebihin.in');
            $mail->addCC('owner@codebihin.in');
            $mail->isHTML(true);
            $mail->Subject = "Termination of Employment – " . $employee['name'];
            $mail->Body = $emailBody;
            $mail->AltBody = strip_tags($emailBody);
            $mail->send();

            $success = "Employee terminated successfully. Email sent to employee and admin copies.";
            header("Location: employee.php?msg=" . urlencode($success));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Email sending failed: " . $mail->ErrorInfo;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Terminate Employee · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
        body{background:#0f172a;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:40px 20px;}
        .card{background:rgba(20,35,55,0.9);border-radius:32px;padding:32px;max-width:600px;width:100%;border:1px solid rgba(255,255,255,0.1);}
        h2{color:#f9b233;border-left:4px solid #f9b233;padding-left:18px;margin-bottom:20px;}
        .info-panel{background:rgba(0,0,0,0.3);border-radius:20px;padding:16px;margin-bottom:25px;color:#cbd5e6;}
        label{display:block;color:#e2e8f0;margin:12px 0 6px;}
        textarea{width:100%;padding:12px;background:rgba(0,0,0,0.4);border:1px solid #3d5e7e;border-radius:16px;color:white;min-height:100px;}
        .btn-group{display:flex;gap:14px;margin-top:25px;}
        .btn{padding:12px 24px;border:none;border-radius:40px;font-weight:600;cursor:pointer;}
        .btn-danger{background:#e74c3c;color:white;}
        .btn-secondary{background:#475569;color:white;}
        .message{padding:14px;border-radius:20px;margin-bottom:20px;}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;color:#ffcfcf;}
        .warning{background:rgba(243,156,18,0.2);border-left:4px solid #f39c12;color:#ffe6b3;margin-bottom:20px;padding:14px;}
    </style>
</head>
<body>
<div class="card">
    <h2><i class="fas fa-fire"></i> Terminate Employee</h2>
    <?php if($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="warning">
        <i class="fas fa-exclamation-triangle"></i> <strong>Warning:</strong> This action is irreversible. The employee will be marked as terminated, all access will be revoked, and an official termination letter will be sent.
    </div>
    <div class="info-panel">
        <p><strong>Employee:</strong> <?= htmlspecialchars($employee['name']) ?></p>
        <p><strong>Employee ID:</strong> <?= htmlspecialchars($employee['id_no']) ?></p>
        <p><strong>Company Email:</strong> <?= htmlspecialchars($employee['company_email']) ?></p>
        <p><strong>Personal Email:</strong> <?= htmlspecialchars($employee['personal_email']) ?></p>
        <p><strong>Current Role:</strong> <?= htmlspecialchars($employee['role']) ?></p>
    </div>
    <form method="POST">
        <label><i class="fas fa-pen-alt"></i> Termination Reason *</label>
        <textarea name="termination_reason" placeholder="Provide detailed reason for termination..." required></textarea>
        <div class="btn-group">
            <button type="submit" name="confirm_fire" class="btn btn-danger"><i class="fas fa-fire"></i> Terminate & Send Letter</button>
            <a href="employee.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
</body>
</html>