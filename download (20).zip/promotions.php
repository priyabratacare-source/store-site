<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/db.php';
$pdo = getDBConnection();

$siteName = 'CodeBihin';
try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (PDOException $e) {}

$message = $_GET['msg'] ?? '';

// Fetch all promotion offers
$offers = $pdo->query("
    SELECT po.*, e.name AS employee_name, e.id_no, e.role AS current_role
    FROM promotion_offers po 
    JOIN Employee e ON po.employee_id = e.id 
    ORDER BY po.created_at DESC
")->fetchAll();

// Fetch promotion logs
$logs = $pdo->query("
    SELECT * FROM promotions_log 
    ORDER BY created_at DESC 
    LIMIT 50
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promotions · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', system-ui, sans-serif; }
        body { background: #0f172a; min-height: 100vh; display: flex; }
        .main { flex: 1; margin-left: 280px; padding: 28px 36px; }
        
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
        .top-bar h1 { color: #fff; font-size: 24px; }
        .top-bar p { color: #94a3b8; font-size: 13px; margin-top: 4px; }
        .user-menu { display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,0.05); padding: 8px 18px; border-radius: 40px; }
        .user-avatar { background: #2f6db3; width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #fff; font-size: 16px; }
        .user-menu .uname { color: #fff; font-weight: 600; font-size: 13px; }
        .logout-btn { background: rgba(231,76,60,0.2); padding: 7px 14px; border-radius: 30px; color: #ffaaa5; text-decoration: none; font-size: 12px; display: flex; align-items: center; gap: 6px; transition: 0.2s; }
        .logout-btn:hover { background: rgba(231,76,60,0.4); color: #fff; }
        
        .alert { padding: 12px 18px; border-radius: 12px; margin-bottom: 16px; font-size: 13px; display: flex; align-items: center; gap: 8px; }
        .alert-success { background: rgba(46,204,113,0.15); border-left: 3px solid #2ecc71; color: #a3e4bc; }
        
        .card { background: rgba(20,35,55,0.7); backdrop-filter: blur(8px); border-radius: 16px; padding: 20px; border: 1px solid rgba(255,255,255,0.06); margin-bottom: 20px; }
        .card-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px; }
        h3 { color: #fff; border-left: 4px solid #f9b233; padding-left: 14px; font-size: 17px; }
        
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px 14px; text-align: left; color: #e2e8f0; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 13px; white-space: nowrap; }
        th { background: rgba(0,0,0,0.3); color: #94a3b8; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; font-weight: 600; }
        tr:hover { background: rgba(255,255,255,0.02); }
        tr.terminated { opacity: 0.5; }
        
        .badge { padding: 4px 10px; border-radius: 14px; font-size: 11px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }
        .badge-success { background: rgba(46,204,113,0.15); color: #2ecc71; }
        .badge-danger { background: rgba(231,76,60,0.15); color: #e74c3c; }
        .badge-warning { background: rgba(249,178,51,0.15); color: #f9b233; }
        .badge-info { background: rgba(52,152,219,0.15); color: #3498db; }
        .badge-muted { background: rgba(255,255,255,0.05); color: #64748b; }
        
        .btn { padding: 8px 16px; border-radius: 16px; border: none; cursor: pointer; font-size: 12px; font-weight: 600; color: #fff; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; transition: 0.2s; }
        .btn-success { background: #27ae60; }
        .btn-success:hover { background: #1e8449; transform: translateY(-1px); }
        
        .empty-state { text-align: center; padding: 50px; color: #94a3b8; }
        .empty-state i { font-size: 40px; margin-bottom: 12px; opacity: 0.4; display: block; }
        .empty-state p { font-size: 14px; }
        
        .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat-box { background: rgba(20,35,55,0.7); border-radius: 14px; padding: 16px; text-align: center; border: 1px solid rgba(255,255,255,0.06); }
        .stat-box .num { font-size: 26px; font-weight: 700; color: #fff; }
        .stat-box .lbl { font-size: 11px; color: #94a3b8; margin-top: 4px; }
        
        @media (max-width: 768px) { .main { margin-left: 75px; padding: 16px; } }
    </style>
</head>
<body>
    <?php include __DIR__ . '/menu.php'; ?>

    <div class="main">
        <!-- Top Bar -->
        <div class="top-bar">
            <div>
                <h1><i class="fas fa-chart-line"></i> Promotions & Demotions</h1>
                <p>Manage employee promotion and demotion offers</p>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?></div>
                <span class="uname"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
            </div>
        </div>

        <!-- Success Message -->
        <?php if ($message): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <!-- Stats -->
        <?php
        $pendingCount = count(array_filter($offers, fn($o) => $o['status'] === 'pending'));
        $acceptedCount = count(array_filter($offers, fn($o) => $o['status'] === 'accepted'));
        $promotionCount = count(array_filter($offers, fn($o) => $o['type'] === 'promotion'));
        $demotionCount = count(array_filter($offers, fn($o) => $o['type'] === 'demotion'));
        ?>
        <div class="stats-row">
            <div class="stat-box">
                <div class="num"><?= count($offers) ?></div>
                <div class="lbl">Total Offers</div>
            </div>
            <div class="stat-box">
                <div class="num" style="color:#f9b233;"><?= $pendingCount ?></div>
                <div class="lbl">Pending</div>
            </div>
            <div class="stat-box">
                <div class="num" style="color:#2ecc71;"><?= $acceptedCount ?></div>
                <div class="lbl">Accepted</div>
            </div>
            <div class="stat-box">
                <div class="num" style="color:#2ecc71;"><?= $promotionCount ?></div>
                <div class="lbl">Promotions</div>
            </div>
            <div class="stat-box">
                <div class="num" style="color:#e74c3c;"><?= $demotionCount ?></div>
                <div class="lbl">Demotions</div>
            </div>
        </div>

        <!-- Offers Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-paper-plane"></i> All Offers</h3>
                <a href="promotion_create.php" class="btn btn-success"><i class="fas fa-plus"></i> New Offer</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>Type</th>
                            <th>Current Role</th>
                            <th>New Role</th>
                            <th>New Salary</th>
                            <th>Status</th>
                            <th>Effective</th>
                            <th>Created</th>
                            <th>Expires</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; foreach ($offers as $o): 
                            $statusClass = $o['status'] === 'accepted' ? 'badge-success' : ($o['status'] === 'expired' ? 'badge-muted' : 'badge-warning');
                            $typeClass = $o['type'] === 'promotion' ? 'badge-success' : 'badge-danger';
                            $isExpired = strtotime($o['expires_at']) < time() && $o['status'] === 'pending';
                            if ($isExpired) $statusClass = 'badge-muted';
                        ?>
                        <tr class="<?= ($o['status'] === 'expired' || $isExpired) ? 'terminated' : '' ?>">
                            <td><?= $count++ ?></td>
                            <td>
                                <strong><?= htmlspecialchars($o['employee_name']) ?></strong><br>
                                <small style="color:#94a3b8;"><?= htmlspecialchars($o['id_no']) ?></small>
                            </td>
                            <td><span class="badge <?= $typeClass ?>"><?= $o['type'] === 'promotion' ? '🎉' : '⚠️' ?> <?= ucfirst($o['type']) ?></span></td>
                            <td style="color:#94a3b8;"><?= htmlspecialchars($o['current_role']) ?></td>
                            <td style="color:#f9b233;font-weight:600;"><?= htmlspecialchars($o['new_role']) ?></td>
                            <td>₹ <?= number_format($o['new_salary'], 2) ?></td>
                            <td><span class="badge <?= $statusClass ?>"><?= $isExpired ? 'Expired' : ucfirst($o['status']) ?></span></td>
                            <td><?= date('d M Y', strtotime($o['effective_date'])) ?></td>
                            <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                            <td><?= date('d M Y', strtotime($o['expires_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($offers)): ?>
                            <tr>
                                <td colspan="10">
                                    <div class="empty-state">
                                        <i class="fas fa-inbox"></i>
                                        <p>No promotion offers created yet.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- History Table -->
        <div class="card">
            <h3 style="margin-bottom:16px;"><i class="fas fa-history"></i> Promotion History</h3>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>Type</th>
                            <th>Old Role</th>
                            <th>New Role</th>
                            <th>Old Salary</th>
                            <th>New Salary</th>
                            <th>Effective</th>
                            <th>Done By</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; foreach ($logs as $log): 
                            $typeClass = $log['type'] === 'promotion' ? 'badge-success' : 'badge-danger';
                        ?>
                        <tr>
                            <td><?= $count++ ?></td>
                            <td><strong><?= htmlspecialchars($log['employee_name']) ?></strong></td>
                            <td><span class="badge <?= $typeClass ?>"><?= ucfirst($log['type']) ?></span></td>
                            <td style="color:#94a3b8;"><?= htmlspecialchars($log['old_role']) ?></td>
                            <td style="color:#f9b233;font-weight:600;"><?= htmlspecialchars($log['new_role']) ?></td>
                            <td>₹ <?= number_format($log['old_salary'], 2) ?></td>
                            <td>₹ <?= number_format($log['new_salary'], 2) ?></td>
                            <td><?= date('d M Y', strtotime($log['effective_date'])) ?></td>
                            <td><?= htmlspecialchars($log['done_by']) ?></td>
                            <td><?= date('d M Y', strtotime($log['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="10">
                                    <div class="empty-state">
                                        <i class="fas fa-history"></i>
                                        <p>No promotion history yet.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>