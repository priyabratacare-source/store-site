<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>CodeBihin · Password recovery</title>
  <!-- Font Awesome 6 (free) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', system-ui, 'Inter', -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
    }

    body {
      display: flex;
      height: 100vh;
      width: 100%;
      overflow: hidden;
    }

    /* ---------- LEFT PANEL · glassmorphic reset form ---------- */
    .left {
      width: 36%;
      background: rgba(12, 25, 38, 0.94);
      backdrop-filter: blur(14px);
      color: #fff;
      padding: 48px 44px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      box-shadow: 8px 0 32px rgba(0, 0, 0, 0.4);
      z-index: 10;
      transition: all 0.2s;
      border-right: 1px solid rgba(255, 255, 255, 0.08);
    }

    @media (max-width: 880px) {
      .left { width: 45%; padding: 36px 28px; }
    }

    @media (max-width: 700px) {
      body { flex-direction: column; }
      .left { width: 100%; height: 58%; backdrop-filter: blur(16px); padding: 32px 28px; }
      .right { width: 100%; height: 42%; min-height: 260px; }
    }

    /* brand: official logo + text */
    .logo {
      display: flex;
      align-items: center;
      gap: 14px;
      margin-bottom: 36px;
      flex-wrap: wrap;
    }
    .logo-img {
      height: 52px;
      width: auto;
      max-width: 180px;
      object-fit: contain;
      filter: drop-shadow(0 2px 6px rgba(0,0,0,0.2));
    }
    .logo span {
      font-size: 32px;
      font-weight: 800;
      background: linear-gradient(125deg, #FFFFFF, #c7e2ff);
      background-clip: text;
      -webkit-background-clip: text;
      color: transparent;
      letter-spacing: -0.5px;
    }

    h3 {
      font-size: 26px;
      font-weight: 700;
      margin-bottom: 18px;
      border-left: 4px solid #f9b233;
      padding-left: 18px;
    }

    .info-text {
      font-size: 14px;
      color: #cbdbe6;
      line-height: 1.5;
      margin-bottom: 32px;
      background: rgba(0, 0, 0, 0.25);
      padding: 12px 18px;
      border-radius: 24px;
      backdrop-filter: blur(4px);
    }

    label {
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 6px;
      display: block;
      letter-spacing: 0.3px;
      color: #eef4ff;
    }

    .input-wrapper {
      margin-bottom: 28px;
    }

    input {
      width: 100%;
      padding: 13px 16px;
      border-radius: 20px;
      border: 1px solid #3d5e7e;
      background: rgba(20, 35, 55, 0.8);
      color: #ffffff;
      font-size: 15px;
      outline: none;
      transition: all 0.2s;
    }

    input:focus {
      border-color: #f9b233;
      box-shadow: 0 0 0 3px rgba(249, 178, 51, 0.25);
      background: #142637;
    }

    input::placeholder {
      color: #88a9cc;
      font-weight: 400;
    }

    button {
      width: 100%;
      padding: 14px;
      background: linear-gradient(100deg, #2f6db3, #1e5290);
      border: none;
      border-radius: 44px;
      color: white;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      transition: all 0.25s;
      box-shadow: 0 6px 14px rgba(0, 0, 0, 0.3);
      margin-top: 12px;
    }
    button i { font-size: 18px; }
    button:hover {
      background: linear-gradient(100deg, #1f5cb0, #154877);
      transform: translateY(-2px);
      box-shadow: 0 12px 24px rgba(0, 0, 0, 0.4);
    }
    button:active { transform: translateY(1px); }
    button:disabled {
      opacity: 0.7;
      transform: none;
      cursor: not-allowed;
    }

    .back-link {
      margin-top: 32px;
      text-align: center;
    }
    .back-link a {
      color: #9bc0ff;
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: 0.2s;
      padding: 6px 14px;
      border-radius: 40px;
      background: rgba(255,255,255,0.03);
    }
    .back-link a:hover {
      color: #f9b233;
      gap: 12px;
      background: rgba(249, 178, 51, 0.12);
    }

    /* error styling */
    .input-error {
      border-color: #ff8a7a !important;
      background: rgba(255, 80, 60, 0.12) !important;
    }

    /* ---------- RIGHT PANEL · auto‑changing background (Lorem Picsum) ---------- */
    .right {
      width: 64%;
      position: relative;
      background-size: cover;
      background-position: center center;
      transition: background-image 0.9s ease-in-out;
      overflow: hidden;
      box-shadow: inset 0 0 0 1px rgba(255,255,255,0.05);
    }

    .right::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(125deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.45) 100%);
      pointer-events: none;
      z-index: 1;
    }

    .overlay-text {
      position: absolute;
      bottom: 28px;
      right: 28px;
      color: white;
      text-align: right;
      z-index: 3;
      backdrop-filter: blur(12px);
      background: rgba(0, 0, 0, 0.5);
      padding: 12px 26px;
      border-radius: 44px;
      border: 1px solid rgba(255,245,200,0.3);
    }
    .overlay-text h2 {
      font-size: 26px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .overlay-text p {
      font-size: 12px;
      opacity: 0.85;
    }

    .image-status {
      position: absolute;
      bottom: 18px;
      left: 20px;
      font-size: 11px;
      background: rgba(0,0,0,0.55);
      backdrop-filter: blur(8px);
      padding: 6px 14px;
      border-radius: 40px;
      color: #eef2ff;
      z-index: 3;
      font-family: monospace;
      letter-spacing: 0.3px;
      pointer-events: none;
    }

    /* toast notification */
    .toast-msg {
      position: fixed;
      bottom: 28px;
      left: 28px;
      background: rgba(10, 25, 40, 0.96);
      backdrop-filter: blur(14px);
      padding: 12px 26px;
      border-radius: 48px;
      color: white;
      font-weight: 500;
      font-size: 14px;
      z-index: 9999;
      border-left: 5px solid #3b82f6;
      box-shadow: 0 8px 24px rgba(0,0,0,0.5);
      animation: fadeSlideUp 0.25s ease;
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    @keyframes fadeSlideUp {
      from { opacity: 0; transform: translateY(12px);}
      to { opacity: 1; transform: translateY(0);}
    }

    @media (max-width: 520px) {
      .left { padding: 28px 20px; }
      .logo-img { height: 40px; }
      .logo span { font-size: 26px; }
      h3 { font-size: 22px; }
      .overlay-text { padding: 8px 18px; }
      .overlay-text h2 { font-size: 18px; }
    }
  </style>
</head>
<body>

<div class="left">
  <div class="logo">
    <!-- Official CodeBihin logo from admin domain -->
    <img class="logo-img" src="https://admin.codebihin.in/logo.png" alt="CodeBihin official logo" onerror="this.onerror=null; this.src='https://placehold.co/200x60/0b1b2b/f9b233?text=CodeBihin';">
    <span>CodeBihin</span>
  </div>
  
  <h3>Reset password</h3>
  <div class="info-text">
    <i class="fa-regular fa-envelope" style="margin-right: 8px;"></i> 
    Enter the email address associated with your account. We’ll send you a secure link to create a new password.
  </div>

  <div class="input-wrapper">
    <label>Registered email address <span style="color:#f9b233">*</span></label>
    <input type="email" id="resetEmail" placeholder="you@codebihin.com" autocomplete="email" aria-label="Email for password recovery">
  </div>

  <button id="sendResetBtn">
    <i class="fa-regular fa-paper-plane"></i> Send reset link
  </button>

  <div class="back-link">
    <a href="/login" id="backToLoginBtn">
      <i class="fa-solid fa-arrow-left"></i> Back to login page
    </a>
  </div>
</div>

<div class="right" id="dynamicBgRight">
  <div class="overlay-text">
    <h2>CodeBihin</h2>
    <p>© 2026 — secure credential recovery</p>
  </div>
  <div class="image-status" id="imgStatus">
    <i class="fa-regular fa-images"></i> <span id="refreshCounter">dynamic wallpaper</span>
  </div>
</div>

<script>
  // ============================================================
  // 1. AUTO‑CHANGING BACKGROUND (Lorem Picsum · fresh every 7 seconds)
  //    No demo content, just visual refresh.
  // ============================================================
  let bgInterval;
  let wallpaperCounter = 0;

  function getFreshPicsumUrl() {
    // Full HD + unique seed to avoid caching
    const seed = Date.now() + Math.floor(Math.random() * 100000);
    return `https://picsum.photos/1920/1080?random=${seed}&_t=${seed}`;
  }

  function updateBackgroundImage() {
    const bgDiv = document.getElementById('dynamicBgRight');
    if (!bgDiv) return;
    const imageUrl = getFreshPicsumUrl();
    const preloader = new Image();
    preloader.onload = function() {
      bgDiv.style.backgroundImage = `url('${imageUrl}')`;
      bgDiv.style.backgroundSize = 'cover';
      bgDiv.style.backgroundPosition = 'center center';
      wallpaperCounter++;
      const statusSpan = document.getElementById('refreshCounter');
      if (statusSpan) {
        statusSpan.innerHTML = `⟳ wallpaper #${wallpaperCounter}`;
      }
    };
    preloader.onerror = function() {
      // graceful fallback: keep existing or set gradient
      if (wallpaperCounter === 0) {
        bgDiv.style.background = 'linear-gradient(135deg, #102b38, #04131f)';
      }
      const statusSpan = document.getElementById('refreshCounter');
      if (statusSpan) statusSpan.innerHTML = `live background active`;
    };
    preloader.src = imageUrl;
  }

  function startWallpaperRotation() {
    if (bgInterval) clearInterval(bgInterval);
    updateBackgroundImage();
    bgInterval = setInterval(() => {
      updateBackgroundImage();
    }, 7000);
  }

  // ============================================================
  // 2. TOAST & UI helpers (production style)
  // ============================================================
  let activeToastTimeout = null;

  function showToast(message, isError = false) {
    const existingToast = document.querySelector('.toast-msg');
    if (existingToast) existingToast.remove();
    if (activeToastTimeout) clearTimeout(activeToastTimeout);
    
    const toast = document.createElement('div');
    toast.className = 'toast-msg';
    const icon = isError ? '<i class="fa-solid fa-circle-exclamation"></i>' : '<i class="fa-regular fa-bell"></i>';
    toast.innerHTML = `${icon} <span>${message}</span>`;
    if (isError) {
      toast.style.borderLeftColor = '#ff8a7a';
      toast.style.background = 'rgba(140, 30, 30, 0.96)';
    } else {
      toast.style.borderLeftColor = '#f9b233';
      toast.style.background = 'rgba(18, 55, 85, 0.96)';
    }
    document.body.appendChild(toast);
    activeToastTimeout = setTimeout(() => {
      if (toast && toast.remove) toast.remove();
    }, 4500);
  }

  function setEmailError(hasError) {
    const emailInput = document.getElementById('resetEmail');
    if (hasError) {
      emailInput.classList.add('input-error');
    } else {
      emailInput.classList.remove('input-error');
    }
  }

  function isValidEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email.trim());
  }

  // ============================================================
  // 3. PASSWORD RESET REQUEST (real API integration ready)
  //    POST to /api/password-reset (relative endpoint)
  //    No demo messages, follows security best practices.
  // ============================================================
  let isSubmitting = false;

  async function handleSendReset(e) {
    if (e) e.preventDefault();
    
    const emailInput = document.getElementById('resetEmail');
    const rawEmail = emailInput.value;
    const trimmedEmail = rawEmail.trim();
    
    setEmailError(false);
    
    if (!trimmedEmail) {
      setEmailError(true);
      showToast("Please enter your email address", true);
      emailInput.focus();
      return;
    }
    
    if (!isValidEmail(trimmedEmail)) {
      setEmailError(true);
      showToast("Invalid email format. Use name@domain.com", true);
      emailInput.focus();
      return;
    }
    
    if (isSubmitting) return;
    isSubmitting = true;
    const submitBtn = document.getElementById('sendResetBtn');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-pulse"></i> Sending ...';
    
    try {
      // Production‑ready fetch call to your backend
      const response = await fetch('/api/password-reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ email: trimmedEmail })
      });
      
      const data = await response.json().catch(() => ({}));
      
      if (response.ok) {
        // Standard secure message: do not reveal if email exists
        showToast("If an account exists with that email, you will receive a password reset link.", false);
        setEmailError(false);
        emailInput.value = '';  // optional: clear for privacy, but UX decision
      } else {
        // Still show generic error to avoid user enumeration
        showToast("Unable to process request. Please try again later.", true);
      }
    } catch (networkError) {
      console.warn("Reset request failed:", networkError);
      showToast("Network error. Please check your connection and try again.", true);
    } finally {
      isSubmitting = false;
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  }

  // ============================================================
  // 4. BACK TO LOGIN (natural navigation)
  // ============================================================
  // The link already points to "/login", no extra preventDefault needed.
  // We keep minimal UX: just let the browser navigate.
  // However, to avoid accidental double handling we don't override.

  // ============================================================
  // 5. LIVE VALIDATION (clean UX)
  // ============================================================
  function setupLiveValidation() {
    const emailField = document.getElementById('resetEmail');
    if (!emailField) return;
    emailField.addEventListener('input', function() {
      if (emailField.classList.contains('input-error')) {
        emailField.classList.remove('input-error');
      }
    });
    emailField.addEventListener('blur', function() {
      const val = emailField.value.trim();
      if (val !== "" && !isValidEmail(val)) {
        setEmailError(true);
        // subtle tip without aggressive toast spam
      } else if (val !== "" && isValidEmail(val)) {
        setEmailError(false);
      }
    });
  }

  // ============================================================
  // 6. INITIALIZATION
  // ============================================================
  document.addEventListener('DOMContentLoaded', () => {
    startWallpaperRotation();
    
    const resetButton = document.getElementById('sendResetBtn');
    if (resetButton) resetButton.addEventListener('click', handleSendReset);
    
    const emailInputElem = document.getElementById('resetEmail');
    if (emailInputElem) {
      emailInputElem.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleSendReset(e);
        }
      });
    }
    
    setupLiveValidation();
    
    // Ensure background initial style
    const bgDiv = document.getElementById('dynamicBgRight');
    if (bgDiv && !bgDiv.style.backgroundImage) {
      bgDiv.style.background = 'linear-gradient(135deg, #102b38, #04131f)';
    }
  });
  
  window.addEventListener('beforeunload', () => {
    if (bgInterval) clearInterval(bgInterval);
    if (activeToastTimeout) clearTimeout(activeToastTimeout);
  });
</script>
</body>
</html>