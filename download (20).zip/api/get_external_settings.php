<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../db.php';   // adjust path if needed

$response = ['success' => false, 'error' => 'Unknown error'];

try {
    // Get API key from header
    $headers = getallheaders();
    $apiKey = $headers['X-API-Key'] ?? '';
    if (empty($apiKey)) {
        throw new Exception('Missing API key', 401);
    }

    $pdo = getDBConnection();
    
    // Find website by api_secret
    $stmt = $pdo->prepare("SELECT id, website_name, website_url, verified, status FROM managed_websites WHERE api_secret = ?");
    $stmt->execute([$apiKey]);
    $website = $stmt->fetch();
    if (!$website) {
        throw new Exception('Invalid API key', 403);
    }
    if ($website['status'] !== 'active' || !$website['verified']) {
        throw new Exception('Website not active or not verified', 403);
    }
    
    $websiteId = $website['id'];
    
    // Fetch global settings (ext_*)
    $global = [];
    $stmt = $pdo->query("SELECT option_name, option_value FROM settings WHERE option_name LIKE 'ext_%'");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $key = str_replace('ext_', '', $row['option_name']);
        $global[$key] = $row['option_value'];
    }
    
    // Fetch website-specific overrides
    $overrides = [];
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM website_settings WHERE website_id = ?");
    $stmt->execute([$websiteId]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $overrides[$row['setting_key']] = $row['setting_value'];
    }
    
    // Merge (website overrides global)
    $settings = array_merge($global, $overrides);
    
    $response = [
        'success' => true,
        'website' => [
            'id' => $website['id'],
            'name' => $website['website_name'],
            'url' => $website['website_url']
        ],
        'settings' => $settings,
        'timestamp' => date('c')
    ];
    
} catch (Exception $e) {
    $code = $e->getCode() ?: 500;
    http_response_code($code);
    $response['error'] = $e->getMessage();
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error';
}

echo json_encode($response);
?>