<?php
// config.php - All sensitive credentials (keep outside document root)

// Database settings (InfinityFree)
define('DB_HOST', 'sql204.infinityfree.com');
define('DB_NAME', 'if0_41037048_admin');
define('DB_USER', 'if0_41037048');
define('DB_PASS', 'TWPT4BP1WW');   // Replace with your actual password

// SMTP Settings (for PHPMailer – Zoho example)
define('SMTP_HOST', 'smtp.zoho.in');
define('SMTP_USER', 'info@codebihin.in');
define('SMTP_PASS', '5PJxDcP4K8Tc'); // Replace with real password
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');        // 'ssl' for port 465

// Email addresses
define('FROM_EMAIL', 'info@codebihin.in');
define('FROM_NAME', 'CodeBihin');
define('CC_EMAIL', 'admin@codebihin.in');   // Set to '' if not needed

// Application URL (no trailing slash)
define('APP_URL', 'https://admin.codebihin.in');

// Site name (fallback)
define('SITE_NAME', 'CodeBihin');
?>