<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';

$pdo = getDBConnection();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name']);
    $admin_email = trim($_POST['admin_email']);

    $stmt = $pdo->prepare("
        INSERT INTO settings (option_name, option_value)
        VALUES ('site_name', ?)
        ON DUPLICATE KEY UPDATE option_value = ?
    ");
    $stmt->execute([$site_name, $site_name]);

    $stmt2 = $pdo->prepare("
        INSERT INTO settings (option_name, option_value)
        VALUES ('admin_email', ?)
        ON DUPLICATE KEY UPDATE option_value = ?
    ");
    $stmt2->execute([$admin_email, $admin_email]);

    $message = '<div class="success-message">✅ Settings saved successfully</div>';
}

/* Fetch values safely */
$site_name = $pdo->query("SELECT option_value FROM settings WHERE option_name='site_name'")->fetchColumn() ?? '';
$admin_email = $pdo->query("SELECT option_value FROM settings WHERE option_name='admin_email'")->fetchColumn() ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Settings · CodeBihin</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: #0f172a;
    font-family: 'Segoe UI', system-ui;
    display: flex;
}

/* MAIN FIX (IMPORTANT) */
.main {
    margin-left: 280px;
    width: 100%;
    padding: 30px;
    animation: fadeIn 0.4s ease;
}

/* ANIMATION */
@keyframes fadeIn {
    from {opacity:0; transform:translateY(10px);}
    to {opacity:1; transform:translateY(0);}
}

/* TOP BAR */
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.welcome h1 {
    color: white;
    font-size: 26px;
}
.welcome p {
    color: #94a3b8;
}

/* USER */
.user-menu {
    display: flex;
    align-items: center;
    gap: 15px;
    background: rgba(255,255,255,0.05);
    padding: 8px 18px;
    border-radius: 40px;
}

.user-avatar {
    width: 40px;
    height: 40px;
    background: #2f6db3;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.user-info .name {
    color: white;
    font-weight: 600;
}
.user-info .email {
    font-size: 12px;
    color: #94a3b8;
}

.logout-btn {
    background: rgba(231,76,60,0.2);
    padding: 8px 14px;
    border-radius: 30px;
    color: #ffaaa5;
    text-decoration: none;
}
.logout-btn:hover {
    background: rgba(231,76,60,0.4);
    color: white;
}

/* FORM */
.settings-form {
    background: rgba(20,35,55,0.7);
    padding: 25px;
    border-radius: 20px;
    max-width: 600px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    color: #cbd5e1;
    margin-bottom: 6px;
    display: block;
}

.form-control {
    width: 100%;
    padding: 12px;
    border-radius: 12px;
    border: none;
    background: rgba(0,0,0,0.3);
    color: white;
}

.form-control:focus {
    outline: 2px solid #f9b233;
}

.btn-primary {
    background: #f9b233;
    padding: 12px 20px;
    border-radius: 30px;
    border: none;
    cursor: pointer;
    font-weight: bold;
}

.btn-primary:hover {
    background: #ffc55a;
}

.success-message {
    background: #2e7d32;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 15px;
    color: white;
}

/* MOBILE */
@media(max-width:768px){
    .main {
        margin-left: 80px;
        padding: 20px;
    }

    .top-bar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
}
</style>
</head>

<body>

<!-- MENU -->
<?php include 'menu.php'; ?>

<div class="main">

    <div class="top-bar">
        <div class="welcome">
            <h1>Settings</h1>
            <p>Manage your system</p>
        </div>

        <div class="user-menu">
            <div class="user-avatar">
                <?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)); ?>
            </div>
            <div class="user-info">
                <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></div>
                <div class="email"><?= htmlspecialchars($_SESSION['email'] ?? ''); ?></div>
            </div>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>

    <?= $message; ?>

    <form method="POST" class="settings-form">
        <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="site_name" class="form-control"
                   value="<?= htmlspecialchars($site_name); ?>" required>
        </div>

        <div class="form-group">
            <label>Admin Email</label>
            <input type="email" name="admin_email" class="form-control"
                   value="<?= htmlspecialchars($admin_email); ?>" required>
        </div>

        <button class="btn-primary">
            <i class="fas fa-save"></i> Save Changes
        </button>
    </form>

</div>

</body>
</html>