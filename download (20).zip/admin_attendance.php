<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
require_once 'db.php';
$pdo = getDBConnection();

$siteName = 'CodeBihin';
try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name='site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch(PDOException $e) {}

// ==================== HANDLE HOLIDAY ACTIONS ====================
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_holiday') {
        $holidayDate = $_POST['holiday_date'] ?? '';
        $holidayName = trim($_POST['holiday_name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        
        if (empty($holidayDate) || empty($holidayName)) {
            $error = 'Please fill all required fields.';
        } else {
            try {
                $insStmt = $pdo->prepare("INSERT INTO holidays (holiday_date, holiday_name, description, created_by) VALUES (?, ?, ?, ?)");
                $insStmt->execute([$holidayDate, $holidayName, $description, $_SESSION['username'] ?? 'Admin']);
                $message = 'Holiday added successfully.';
            } catch (PDOException $e) {
                $error = 'Holiday already exists for this date.';
            }
        }
    } elseif ($action === 'delete_holiday') {
        $holidayId = (int)$_POST['holiday_id'];
        $delStmt = $pdo->prepare("DELETE FROM holidays WHERE id = ?");
        $delStmt->execute([$holidayId]);
        $message = 'Holiday deleted.';
    } elseif ($action === 'update_weekoff') {
        $weekOffDays = implode(',', $_POST['weekoff_days'] ?? []);
        $pdo->prepare("UPDATE settings SET option_value = ? WHERE option_name = 'week_off_days'")->execute([$weekOffDays]);
        $message = 'Week off days updated.';
    }
}

// ==================== FETCH DATA ====================
// Get week off days
$weekOffDays = ['sunday', 'monday'];
try {
    $woStmt = $pdo->query("SELECT option_value FROM settings WHERE option_name='week_off_days'");
    if ($woRow = $woStmt->fetch()) {
        $weekOffDays = explode(',', $woRow['option_value']);
    }
} catch(PDOException $e) {}

// Get holidays
$holidays = $pdo->query("SELECT * FROM holidays ORDER BY holiday_date ASC")->fetchAll();

// Get employee attendance summary (current month)
$month = date('m');
$year = date('Y');
$attendanceSummary = $pdo->query("
    SELECT e.id, e.name, e.id_no, e.role,
           SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days,
           COUNT(DISTINCT CASE WHEN a.attendance_date IS NOT NULL THEN a.attendance_date END) as total_marked,
           (SELECT COUNT(*) FROM holidays WHERE MONTH(holiday_date) = '$month' AND YEAR(holiday_date) = '$year') as holidays_count
    FROM Employee e
    LEFT JOIN attendance a ON e.id = a.employee_id AND MONTH(a.attendance_date) = '$month' AND YEAR(a.attendance_date) = '$year'
    WHERE e.resign = 0 AND e.blocked = 0
    GROUP BY e.id
    ORDER BY present_days DESC
")->fetchAll();

// Calculate working days
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$workingDays = 0;
for ($d = 1; $d <= $daysInMonth; $d++) {
    $date = "$year-$month-" . str_pad($d, 2, '0', STR_PAD_LEFT);
    $dayName = strtolower(date('l', strtotime($date)));
    $holStmt = $pdo->prepare("SELECT COUNT(*) FROM holidays WHERE holiday_date = ?");
    $holStmt->execute([$date]);
    $isHoliday = $holStmt->fetchColumn() > 0;
    if (!in_array($dayName, $weekOffDays) && !$isHoliday) {
        $workingDays++;
    }
}

// Search functionality
$searchTerm = $_GET['search'] ?? '';
if ($searchTerm) {
    $attendanceSummary = array_filter($attendanceSummary, function($emp) use ($searchTerm) {
        return stripos($emp['name'], $searchTerm) !== false || 
               stripos($emp['id_no'], $searchTerm) !== false ||
               stripos($emp['role'], $searchTerm) !== false;
    });
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Attendance Management · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}
        body{background:#0f172a;min-height:100vh;display:flex;}
        .main{flex:1;margin-left:280px;padding:28px 36px;animation:fadeIn 0.5s ease;}
        @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
        
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px;flex-wrap:wrap;gap:16px;}
        .welcome h1{font-size:28px;color:#fff;font-weight:600;}
        .welcome p{color:#94a3b8;margin-top:6px;}
        .user-menu{display:flex;align-items:center;gap:20px;background:rgba(255,255,255,0.05);padding:8px 20px;border-radius:48px;}
        .user-avatar{background:#2f6db3;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;color:#fff;}
        .logout-btn{background:rgba(231,76,60,0.2);padding:8px 16px;border-radius:40px;color:#ffaaa5;text-decoration:none;display:inline-flex;align-items:center;gap:8px;}
        
        .tabs{display:flex;gap:8px;margin-bottom:24px;}
        .tab{padding:10px 20px;border-radius:20px;cursor:pointer;color:#94a3b8;font-weight:500;transition:0.2s;background:transparent;border:1px solid transparent;}
        .tab:hover{color:#f9b233;}
        .tab.active{background:rgba(249,178,51,0.15);color:#f9b233;border-color:rgba(249,178,51,0.3);}
        
        .card{background:rgba(20,35,55,0.7);backdrop-filter:blur(8px);border-radius:20px;padding:24px;border:1px solid rgba(255,255,255,0.08);margin-bottom:20px;}
        h2{color:#fff;border-left:4px solid #f9b233;padding-left:16px;margin-bottom:20px;}
        
        .alert{padding:14px 20px;border-radius:16px;margin-bottom:20px;}
        .alert-success{background:rgba(46,204,113,0.15);border-left:4px solid #2ecc71;color:#c8f0e1;}
        .alert-error{background:rgba(231,76,60,0.15);border-left:4px solid #e74c3c;color:#ffcfcf;}
        
        table{width:100%;border-collapse:collapse;}
        th,td{padding:12px;text-align:left;color:#e2e8f0;border-bottom:1px solid rgba(255,255,255,0.05);}
        th{background:rgba(0,0,0,0.3);font-weight:600;color:#f9b233;}
        tr:hover{background:rgba(255,255,255,0.03);}
        
        .btn{background:#2f6db3;border:none;padding:8px 16px;border-radius:20px;color:#fff;cursor:pointer;transition:0.2s;display:inline-flex;align-items:center;gap:8px;}
        .btn:hover{background:#1e4d82;}
        .btn-danger{background:#e74c3c;}
        .btn-danger:hover{background:#c0392b;}
        .btn-success{background:#27ae60;}
        
        .search-box{display:flex;gap:10px;margin-bottom:20px;}
        .search-box input{flex:1;padding:10px 16px;border-radius:20px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.4);color:#fff;outline:none;}
        .search-box input:focus{border-color:#f9b233;}
        
        .progress-bar{height:8px;background:rgba(255,255,255,0.1);border-radius:10px;overflow:hidden;margin-top:4px;}
        .progress-fill{height:100%;border-radius:10px;transition:width 0.5s;}
        .progress-high{background:#2ecc71;}
        .progress-medium{background:#f39c12;}
        .progress-low{background:#e74c3c;}
        
        .badge{padding:4px 10px;border-radius:15px;font-size:11px;font-weight:600;}
        .badge-present{background:rgba(46,204,113,0.2);color:#2ecc71;}
        .badge-absent{background:rgba(231,76,60,0.2);color:#e74c3c;}
        
        .modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:1000;justify-content:center;align-items:center;}
        .modal-content{background:#0f1a24;border-radius:20px;padding:24px;width:90%;max-width:500px;border:1px solid rgba(255,255,255,0.1);}
        .modal-content h3{color:#fff;margin-bottom:15px;}
        .modal-content input,.modal-content textarea{width:100%;padding:10px;margin:10px 0;border-radius:12px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.4);color:#fff;}
        
        @media (max-width:768px){.main{margin-left:80px;padding:20px;}}
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome"><h1><i class="fas fa-calendar-check"></i> Attendance Management</h1><p>Manage attendance, holidays & week off settings</p></div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)) ?></div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
        </div>
    </div>

    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- TABS -->
    <div class="tabs">
        <button class="tab active" onclick="showTab('summary')">📊 Attendance Summary</button>
        <button class="tab" onclick="showTab('holidays')">🏖️ Holiday Management</button>
        <button class="tab" onclick="showTab('weekoff')">⚙️ Week Off Settings</button>
    </div>

    <!-- SUMMARY TAB -->
    <div id="tab-summary" class="tab-content">
        <div class="card">
            <h2>Monthly Attendance (<?= date('F Y') ?>)</h2>
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
                <div class="search-box" style="flex:1;min-width:250px;">
                    <input type="text" id="searchInput" placeholder="Search employee by name, ID or role..." value="<?= htmlspecialchars($searchTerm) ?>" onkeyup="filterTable()">
                </div>
                <div style="color:#94a3b8;font-size:14px;">Working Days: <strong style="color:#f9b233;"><?= $workingDays ?></strong></div>
            </div>
            <div style="overflow-x:auto;margin-top:20px;">
                <table id="attendanceTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>ID No.</th>
                            <th>Role</th>
                            <th>Present</th>
                            <th>Absent</th>
                            <th>Attendance %</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rank = 1; foreach ($attendanceSummary as $emp): 
                            $absentDays = $workingDays - $emp['present_days'];
                            $percentage = $workingDays > 0 ? round(($emp['present_days'] / $workingDays) * 100, 1) : 0;
                            $progressClass = $percentage >= 90 ? 'progress-high' : ($percentage >= 75 ? 'progress-medium' : 'progress-low');
                        ?>
                        <tr>
                            <td><?= $rank++ ?></td>
                            <td><strong><?= htmlspecialchars($emp['name']) ?></strong></td>
                            <td><?= htmlspecialchars($emp['id_no'] ?? '-') ?></td>
                            <td><span class="badge" style="background:rgba(249,178,51,0.15);color:#f9b233;"><?= htmlspecialchars($emp['role']) ?></span></td>
                            <td><span class="badge badge-present"><?= $emp['present_days'] ?> days</span></td>
                            <td><span class="badge badge-absent"><?= $absentDays ?> days</span></td>
                            <td>
                                <strong style="color:<?= $percentage >= 90 ? '#2ecc71' : ($percentage >= 75 ? '#f39c12' : '#e74c3c') ?>"><?= $percentage ?>%</strong>
                                <div class="progress-bar"><div class="progress-fill <?= $progressClass ?>" style="width:<?= $percentage ?>%;"></div></div>
                            </td>
                            <td><a href="admin_employee_attendance.php?id=<?= $emp['id'] ?>" class="btn" style="font-size:12px;"><i class="fas fa-eye"></i> View</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- HOLIDAYS TAB -->
    <div id="tab-holidays" class="tab-content" style="display:none;">
        <div class="card">
            <h2>Holiday List</h2>
            <button class="btn btn-success" onclick="openHolidayModal()"><i class="fas fa-plus"></i> Add Holiday</button>
            <div style="overflow-x:auto;margin-top:20px;">
                <table>
                    <thead><tr><th>Date</th><th>Holiday Name</th><th>Description</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($holidays as $h): ?>
                        <tr>
                            <td><?= date('d F Y', strtotime($h['holiday_date'])) ?> (<?= date('l', strtotime($h['holiday_date'])) ?>)</td>
                            <td><strong><?= htmlspecialchars($h['holiday_name']) ?></strong></td>
                            <td><?= htmlspecialchars($h['description'] ?? '-') ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete_holiday">
                                    <input type="hidden" name="holiday_id" value="<?= $h['id'] ?>">
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this holiday?')"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- WEEK OFF TAB -->
    <div id="tab-weekoff" class="tab-content" style="display:none;">
        <div class="card">
            <h2>Week Off Day Settings</h2>
            <form method="POST">
                <input type="hidden" name="action" value="update_weekoff">
                <div style="display:flex;gap:20px;flex-wrap:wrap;">
                    <?php 
                    $allDays = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
                    foreach ($allDays as $day): ?>
                    <label style="color:#e2e8f0;display:flex;align-items:center;gap:8px;padding:10px 16px;background:rgba(255,255,255,0.03);border-radius:12px;">
                        <input type="checkbox" name="weekoff_days[]" value="<?= $day ?>" <?= in_array($day, $weekOffDays) ? 'checked' : '' ?>>
                        <?= ucfirst($day) ?>
                    </label>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn" style="margin-top:20px;"><i class="fas fa-save"></i> Save Settings</button>
            </form>
        </div>
    </div>
</div>

<!-- HOLIDAY MODAL -->
<div id="holidayModal" class="modal">
    <div class="modal-content">
        <h3>Add Holiday</h3>
        <form method="POST">
            <input type="hidden" name="action" value="add_holiday">
            <label style="color:#94a3b8;">Date *</label>
            <input type="date" name="holiday_date" required>
            <label style="color:#94a3b8;">Holiday Name *</label>
            <input type="text" name="holiday_name" placeholder="e.g., Republic Day" required>
            <label style="color:#94a3b8;">Description</label>
            <textarea name="description" rows="3" placeholder="Optional description..."></textarea>
            <div style="display:flex;gap:10px;margin-top:15px;">
                <button type="submit" class="btn btn-success">Save</button>
                <button type="button" class="btn btn-danger" onclick="closeHolidayModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showTab(tab) {
    document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + tab).style.display = 'block';
    event.target.classList.add('active');
}

function openHolidayModal() { document.getElementById('holidayModal').style.display = 'flex'; }
function closeHolidayModal() { document.getElementById('holidayModal').style.display = 'none'; }
window.onclick = function(e) { if (e.target === document.getElementById('holidayModal')) closeHolidayModal(); }

function filterTable() {
    const input = document.getElementById('searchInput');
    const filter = input.value.toUpperCase();
    const table = document.getElementById('attendanceTable');
    const tr = table.getElementsByTagName('tr');
    for (let i = 1; i < tr.length; i++) {
        const td = tr[i].getElementsByTagName('td');
        let show = false;
        for (let j = 0; j < td.length; j++) {
            if (td[j] && td[j].textContent.toUpperCase().indexOf(filter) > -1) { show = true; break; }
        }
        tr[i].style.display = show ? '' : 'none';
    }
}
</script>
</body>
</html>