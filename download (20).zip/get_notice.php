<?php
/**
 * get_notice.php - AJAX endpoint to fetch a single notice for preview.
 * Returns JSON data.
 */

session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid or missing ID']);
    exit;
}

$id = (int)$_GET['id'];

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM notices WHERE id = ?");
    $stmt->execute([$id]);
    $notice = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$notice) {
        http_response_code(404);
        echo json_encode(['error' => 'Notice not found']);
        exit;
    }

    // Prepare safe output
    $response = [
        'title' => htmlspecialchars($notice['title']),
        'notice_number' => htmlspecialchars($notice['notice_number']),
        'notice_date' => date('d-m-Y', strtotime($notice['notice_date'])),
        'content' => nl2br(htmlspecialchars($notice['content'])),
        'status' => $notice['status'],
        'is_signed' => (bool)$notice['is_signed'],
        'signed_by' => htmlspecialchars($notice['signed_by']),
        'signed_email' => htmlspecialchars($notice['signed_email']),
        'signed_at' => $notice['signed_at'] ? date('d-m-Y h:i:s A', strtotime($notice['signed_at'])) : null,
        'signature_id' => htmlspecialchars($notice['signature_id'])
    ];

    header('Content-Type: application/json');
    echo json_encode($response);

} catch (PDOException $e) {
    error_log("get_notice.php PDO error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
} catch (Exception $e) {
    error_log("get_notice.php general error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Server error']);
}
?>