<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
require_once 'db.php';

$pdo = getDBConnection();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $emp_id = (int)$_POST['emp_id'];
    $admin_name = $_SESSION['username'] ?? 'Admin';

    if ($action === 'block') {
        $pdo->prepare("UPDATE Employee SET blocked = 1, blocked_by = ? WHERE id = ?")->execute([$admin_name, $emp_id]);
        $message = "Employee blocked.";
    } elseif ($action === 'unblock') {
        $pdo->prepare("UPDATE Employee SET blocked = 0, blocked_by = NULL, unauthorized_attempts = 0 WHERE id = ?")->execute([$emp_id]);
        $message = "Employee unblocked.";
    } elseif ($action === 'suspend') {
        $days = (int)$_POST['days'];
        $pdo->prepare("UPDATE Employee SET suspended = 1, suspension_days = ? WHERE id = ?")->execute([$days, $emp_id]);
        $message = "Employee suspended for $days days.";
    } elseif ($action === 'unsuspend') {
        $pdo->prepare("UPDATE Employee SET suspended = 0, suspension_days = NULL WHERE id = ?")->execute([$emp_id]);
        $message = "Employee unsuspended.";
    }
}

$employees = $pdo->query("SELECT id, name, username, company_email, role, blocked, suspended, suspension_days FROM Employee ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Management · CodeBihin</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}

body{
  background:#0f172a;
}

/* ✅ FIXED SIDEBAR */
.sidebar{
  width:250px;
  position:fixed;
  top:0;
  left:0;
  height:100%;
  background:#0b1b2b;
  z-index:1000;
}

/* ✅ FIXED MAIN CONTENT */
.main{
  margin-left:250px;
  min-height:100vh;
  padding:28px 36px;
}

/* UI DESIGN */
.top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px;flex-wrap:wrap;gap:16px;}
.welcome h1{font-size:28px;color:#ffffff;font-weight:600;}
.welcome p{color:#94a3b8;margin-top:6px;}

.user-menu{display:flex;align-items:center;gap:20px;background:rgba(255,255,255,0.05);padding:8px 20px;border-radius:48px;}
.user-avatar{background:#2f6db3;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:18px;color:white;}

.user-info{text-align:right;}
.user-info .name{font-weight:600;color:white;}
.user-info .email{font-size:12px;color:#94a3b8;}

.logout-btn{background:rgba(231,76,60,0.2);border:none;padding:8px 16px;border-radius:40px;color:#ffaaa5;text-decoration:none;font-size:14px;display:flex;align-items:center;gap:8px;}
.logout-btn:hover{background:rgba(231,76,60,0.4);color:white;}

.card{background:rgba(20,35,55,0.7);border-radius:28px;padding:24px;border:1px solid rgba(255,255,255,0.08);}
h2{margin-bottom:20px;color:white;font-size:24px;border-left:4px solid #f9b233;padding-left:16px;}

table{width:100%;border-collapse:collapse;}
th,td{padding:12px;color:#e2e8f0;border-bottom:1px solid rgba(255,255,255,0.05);}
th{background:rgba(0,0,0,0.3);}

.btn{padding:6px 12px;border:none;border-radius:20px;font-size:12px;cursor:pointer;}
.btn-block{background:#e74c3c;color:white;}
.btn-unblock{background:#27ae60;color:white;}
.btn-suspend{background:#f39c12;color:white;}
.btn-unsuspend{background:#3498db;color:white;}

input[type="number"]{width:70px;padding:5px;margin-right:5px;border-radius:12px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.4);color:white;}

.message{padding:12px 20px;border-radius:20px;margin-bottom:20px;}
.success{background:rgba(46,204,113,0.2);border-left:4px solid #2ecc71;color:#c8f0e1;}
.error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;color:#ffcfcf;}

@media (max-width:768px){
  .main{margin-left:0;padding:20px;}
  .sidebar{position:relative;width:100%;height:auto;}
}
</style>
</head>

<body>

<?php include 'menu.php'; ?>

<div class="main">
  
  <div class="top-bar">
    <div class="welcome">
      <h1>Employee Management</h1>
      <p>Block, suspend, or unblock employees</p>
    </div>

    <div class="user-menu">
      <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)); ?></div>
      <div class="user-info">
        <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></div>
        <div class="email"><?= htmlspecialchars($_SESSION['email'] ?? ''); ?></div>
      </div>
      <a href="logout.php" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i> Exit
      </a>
    </div>
  </div>

  <div class="card">
    
    <?php if ($message): ?>
      <div class="message success"><?= htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="message error"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <h2>Employees</h2>

    <div style="overflow-x:auto;">
      <table>
        <thead>
          <tr>
            <th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>

        <tbody>
        <?php foreach ($employees as $e): ?>
          <tr>
            <td><?= $e['id'] ?></td>
            <td><?= htmlspecialchars($e['name']) ?></td>
            <td><?= htmlspecialchars($e['username']) ?></td>
            <td><?= htmlspecialchars($e['company_email']) ?></td>
            <td><?= htmlspecialchars($e['role']) ?></td>

            <td>
              <?= $e['blocked'] ? '🔴 Blocked' : ($e['suspended'] ? "⏸ Suspended ({$e['suspension_days']} days)" : '🟢 Active') ?>
            </td>

            <td>
              <?php if (!$e['blocked'] && !$e['suspended']): ?>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="emp_id" value="<?= $e['id'] ?>">
                  <button name="action" value="block" class="btn btn-block">Block</button>
                  <input type="number" name="days" placeholder="Days" required>
                  <button name="action" value="suspend" class="btn btn-suspend">Suspend</button>
                </form>

              <?php elseif ($e['blocked']): ?>
                <form method="POST">
                  <input type="hidden" name="emp_id" value="<?= $e['id'] ?>">
                  <button name="action" value="unblock" class="btn btn-unblock">Unblock</button>
                </form>

              <?php elseif ($e['suspended']): ?>
                <form method="POST">
                  <input type="hidden" name="emp_id" value="<?= $e['id'] ?>">
                  <button name="action" value="unsuspend" class="btn btn-unsuspend">Unsuspend</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>

      </table>
    </div>

  </div>

</div>

</body>
</html>