<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
$pdo = getDBConnection();

$role_id = (int)($_GET['role_id'] ?? 0);
if (!$role_id) {
    die('No role specified.');
}

// Fetch role details
$role = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
$role->execute([$role_id]);
$role_data = $role->fetch();
if (!$role_data) {
    die('Role not found.');
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_permissions = $_POST['permissions'] ?? []; // Array of checked permission IDs

    try {
        $pdo->beginTransaction();

        // 1. Get currently assigned permissions for this role
        $current = $pdo->prepare("SELECT permission_id FROM role_permissions WHERE role_id = ?");
        $current->execute([$role_id]);
        $current_perms = $current->fetchAll(PDO::FETCH_COLUMN);

        // 2. Find permissions to DELETE (exist in DB but NOT in submitted form)
        $to_delete = array_diff($current_perms, $submitted_permissions);
        if (!empty($to_delete)) {
            $deleteStmt = $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ? AND permission_id = ?");
            foreach ($to_delete as $perm_id) {
                $deleteStmt->execute([$role_id, (int)$perm_id]);
            }
        }

        // 3. Find permissions to INSERT (exist in submitted form but NOT in DB)
        $to_insert = array_diff($submitted_permissions, $current_perms);
        if (!empty($to_insert)) {
            $insertStmt = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
            foreach ($to_insert as $perm_id) {
                $insertStmt->execute([$role_id, (int)$perm_id]);
            }
        }

        $pdo->commit();
        $message = 'Permissions updated successfully.';
        if (!empty($to_delete)) {
            $message .= ' Removed ' . count($to_delete) . ' old permission(s).';
        }
        if (!empty($to_insert)) {
            $message .= ' Added ' . count($to_insert) . ' new permission(s).';
        }
        if (empty($to_delete) && empty($to_insert)) {
            $message = 'No changes made.';
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = 'Failed to update permissions: ' . $e->getMessage();
    }
}

// Fetch all available permissions
$all_perms = $pdo->query("SELECT id, menu_name, file_name FROM permissions ORDER BY id")->fetchAll();

// Fetch currently assigned permissions for this role (after update)
$current = $pdo->prepare("SELECT permission_id FROM role_permissions WHERE role_id = ?");
$current->execute([$role_id]);
$current_perms = $current->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Permissions for <?= htmlspecialchars($role_data['role_name']) ?> · CodeBihin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        body {
            background: #0f172a;
            min-height: 100vh;
            display: flex;
        }
        .main {
            flex: 1;
            margin-left: 280px;
            padding: 28px 36px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }
        .welcome h1 {
            font-size: 28px;
            color: #ffffff;
            font-weight: 600;
        }
        .welcome p {
            color: #94a3b8;
            margin-top: 6px;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
            background: rgba(255, 255, 255, 0.05);
            padding: 8px 20px;
            border-radius: 48px;
            backdrop-filter: blur(4px);
        }
        .user-avatar {
            background: #2f6db3;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
            color: white;
        }
        .user-info .name {
            font-weight: 600;
            color: white;
        }
        .user-info .email {
            font-size: 12px;
            color: #94a3b8;
        }
        .logout-btn {
            background: rgba(231, 76, 60, 0.2);
            border: none;
            padding: 8px 16px;
            border-radius: 40px;
            color: #ffaaa5;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .logout-btn:hover {
            background: rgba(231, 76, 60, 0.4);
            color: white;
        }
        .card {
            background: rgba(20, 35, 55, 0.7);
            backdrop-filter: blur(8px);
            border-radius: 28px;
            padding: 24px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        h2 {
            margin-bottom: 20px;
            color: white;
            font-size: 24px;
            border-left: 4px solid #f9b233;
            padding-left: 16px;
        }
        .perm-list {
            list-style: none;
            margin: 20px 0;
        }
        .perm-list li {
            margin: 14px 0;
            color: #e2e8f0;
            padding: 10px 16px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            transition: background 0.2s;
        }
        .perm-list li:hover {
            background: rgba(255, 255, 255, 0.06);
        }
        .perm-list label {
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            width: 100%;
        }
        .perm-list input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #f9b233;
            cursor: pointer;
        }
        .perm-list strong {
            color: #f1f5f9;
        }
        .perm-list span.file-hint {
            color: #64748b;
            font-size: 13px;
            margin-left: 8px;
        }
        .btn {
            background: #2f6db3;
            border: none;
            padding: 10px 24px;
            border-radius: 30px;
            color: white;
            cursor: pointer;
            margin-right: 12px;
            font-weight: 500;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        .btn:hover {
            background: #1e4d82;
            transform: translateY(-1px);
        }
        .btn-save {
            background: #27ae60;
        }
        .btn-save:hover {
            background: #1e8449;
        }
        .back {
            background: #475569;
        }
        .back:hover {
            background: #334155;
        }
        .message,
        .error {
            padding: 14px 20px;
            border-radius: 16px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .message {
            background: rgba(46, 204, 113, 0.15);
            border-left: 4px solid #2ecc71;
            color: #c8f0e1;
        }
        .error {
            background: rgba(231, 76, 60, 0.15);
            border-left: 4px solid #e74c3c;
            color: #ffc9c9;
        }
        .stats {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .stat-badge {
            background: rgba(249, 178, 51, 0.15);
            color: #f9b233;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        @media (max-width: 768px) {
            .main {
                margin-left: 80px;
                padding: 20px;
            }
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>
    <div class="main">
        <div class="top-bar">
            <div class="welcome">
                <h1>Permissions for <?= htmlspecialchars($role_data['role_name']) ?></h1>
                <p>Check or uncheck pages this role can access</p>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></div>
                    <div class="email"><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
            </div>
        </div>

        <div class="card">
            <!-- Stats -->
            <div class="stats">
                <span class="stat-badge">
                    <i class="fas fa-shield-alt"></i> Total Permissions: <?= count($all_perms) ?>
                </span>
                <span class="stat-badge">
                    <i class="fas fa-check-circle"></i> Assigned: <?= count($current_perms) ?>
                </span>
            </div>

            <!-- Messages -->
            <?php if ($message): ?>
                <div class="message">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="error">
                    <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form method="POST" id="permissionForm">
                <h2><i class="fas fa-lock"></i> Available Pages</h2>
                <ul class="perm-list">
                    <?php foreach ($all_perms as $p): ?>
                        <li>
                            <label>
                                <input type="checkbox" 
                                       name="permissions[]" 
                                       value="<?= $p['id'] ?>" 
                                       <?= in_array($p['id'], $current_perms) ? 'checked' : '' ?>>
                                <strong><?= htmlspecialchars($p['menu_name']) ?></strong>
                                <span class="file-hint">— <?= htmlspecialchars($p['file_name']) ?></span>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <?php if (empty($all_perms)): ?>
                    <p style="color: #94a3b8; text-align: center; padding: 40px;">
                        <i class="fas fa-info-circle"></i> No permissions found in the database. Please add them first.
                    </p>
                <?php endif; ?>

                <div style="margin-top: 20px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                    <button type="submit" class="btn btn-save">
                        <i class="fas fa-save"></i> Save Permissions
                    </button>
                    <a href="role_management.php" class="btn back">
                        <i class="fas fa-arrow-left"></i> Back to Roles
                    </a>
                    <button type="button" class="btn" onclick="selectAll()" style="background: #6366f1;">
                        <i class="fas fa-check-double"></i> Select All
                    </button>
                    <button type="button" class="btn" onclick="deselectAll()" style="background: #94a3b8;">
                        <i class="fas fa-times"></i> Clear All
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function selectAll() {
            document.querySelectorAll('.perm-list input[type="checkbox"]').forEach(cb => cb.checked = true);
        }

        function deselectAll() {
            document.querySelectorAll('.perm-list input[type="checkbox"]').forEach(cb => cb.checked = false);
        }

        // Confirmation before save
        document.getElementById('permissionForm').addEventListener('submit', function(e) {
            const checked = document.querySelectorAll('.perm-list input[type="checkbox"]:checked').length;
            if (checked === 0) {
                const confirmClear = confirm(
                    'You have unchecked ALL permissions. This role will have NO access to any page.\n\nAre you sure?');
                if (!confirmClear) {
                    e.preventDefault();
                }
            }
        });
    </script>
</body>
</html>