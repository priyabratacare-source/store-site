<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

/* SETTINGS */
$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $siteName = $pdo->query("SELECT option_value FROM settings WHERE option_name='site_name'")
        ->fetchColumn() ?: 'CodeBihin';
} catch (Exception $e) {}

$message = $_GET['msg'] ?? '';
$error   = $_GET['err'] ?? '';

/* HELPERS */
function generateApiSecret() {
    return 'SEC-' . strtoupper(bin2hex(random_bytes(10)));
}
function generateVerificationToken() {
    return 'VERIFY-' . strtoupper(bin2hex(random_bytes(16)));
}

/* HANDLE ACTIONS */
if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['action'])) {

    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

    try {
        $pdo = getDBConnection();

        if ($action === 'add') {
            $name = trim($_POST['website_name']);
            $url  = trim($_POST['website_url']);

            if (!$name || !$url) throw new Exception("Name & URL required");

            $pdo->prepare("
                INSERT INTO managed_websites 
                (website_name, website_url, api_secret, verification_token, status) 
                VALUES (?,?,?,?, 'pending')
            ")->execute([
                $name,
                $url,
                generateApiSecret(),
                generateVerificationToken()
            ]);

            header("Location: websites.php?msg=Website added");
            exit;
        }

        elseif ($action === 'edit') {
            $pdo->prepare("
                UPDATE managed_websites 
                SET website_name=?, website_url=?, status=? 
                WHERE id=?
            ")->execute([
                $_POST['website_name'],
                $_POST['website_url'],
                $_POST['status'],
                $id
            ]);

            header("Location: websites.php?msg=Updated");
            exit;
        }

        elseif ($action === 'delete') {
            $pdo->prepare("DELETE FROM managed_websites WHERE id=?")->execute([$id]);
            header("Location: websites.php?msg=Deleted");
            exit;
        }

        elseif ($action === 'verify') {
            $web = $pdo->prepare("SELECT * FROM managed_websites WHERE id=?");
            $web->execute([$id]);
            $web = $web->fetch();

            $url = rtrim($web['website_url'], '/') . '/codebihin-verify.txt';

            $content = @file_get_contents($url);

            if ($content && trim($content) === $web['verification_token']) {
                $pdo->prepare("UPDATE managed_websites SET verified=1,status='active' WHERE id=?")
                    ->execute([$id]);

                header("Location: websites.php?msg=Verified");
            } else {
                header("Location: websites.php?err=Verification failed");
            }
            exit;
        }

        elseif ($action === 'regenerate_secret') {
            $pdo->prepare("UPDATE managed_websites SET api_secret=? WHERE id=?")
                ->execute([generateApiSecret(), $id]);

            header("Location: websites.php?msg=Secret updated");
            exit;
        }

    } catch (Exception $e) {
        header("Location: websites.php?err=" . urlencode($e->getMessage()));
        exit;
    }
}

/* FETCH */
$websites = getDBConnection()
    ->query("SELECT * FROM managed_websites ORDER BY id DESC")
    ->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($siteName) ?> · Websites</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    margin:0;
    background:#0f172a;
    font-family:Segoe UI;
    display:flex;
}

/* FIX */
.main{
    margin-left:280px;
    width:100%;
    padding:30px;
}

/* HEADER */
.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

h1{color:white;}
p{color:#94a3b8;}

/* CARD */
.card{
    background:#142337;
    padding:20px;
    border-radius:20px;
}

/* BUTTON */
.btn{
    background:#f9b233;
    padding:10px 18px;
    border:none;
    border-radius:25px;
    cursor:pointer;
}

/* TABLE */
table{
    width:100%;
    margin-top:15px;
    border-collapse:collapse;
}

th,td{
    padding:12px;
    color:#e2e8f0;
}

tr:nth-child(even){
    background:#ffffff05;
}

/* BADGE */
.badge{
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
}
.active{background:#2ecc71;}
.pending{background:#f1c40f;}
.suspended{background:#e74c3c;}

/* MODAL */
.modal{
    display:none;
    position:fixed;
    width:100%;
    height:100%;
    background:#0008;
    justify-content:center;
    align-items:center;
}

.modal-box{
    background:#0f1a24;
    padding:25px;
    border-radius:20px;
    width:350px;
    animation:fade 0.3s;
}

@keyframes fade{
    from{opacity:0;transform:scale(.9);}
    to{opacity:1;}
}

input,select{
    width:100%;
    padding:10px;
    margin-top:10px;
    border-radius:10px;
}

/* MESSAGE */
.msg{padding:10px;margin:10px 0;border-radius:10px;}
.success{background:#2ecc71;}
.error{background:#e74c3c;}

@media(max-width:768px){
    .main{margin-left:80px;}
}
</style>
</head>

<body>

<?php include 'menu.php'; ?>

<div class="main">

<div class="top-bar">
    <div>
        <h1>Managed Websites</h1>
        <p>Control external integrations</p>
    </div>
</div>

<button class="btn" onclick="openModal()">+ Add Website</button>

<?php if($message): ?><div class="msg success"><?= $message ?></div><?php endif; ?>
<?php if($error): ?><div class="msg error"><?= $error ?></div><?php endif; ?>

<div class="card">
<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Status</th>
<th>Actions</th>
</tr>

<?php foreach($websites as $w): ?>
<tr>
<td><?= $w['id'] ?></td>
<td><?= htmlspecialchars($w['website_name']) ?></td>
<td><span class="badge <?= $w['status'] ?>"><?= $w['status'] ?></span></td>
<td>
<button onclick='edit(<?= $w["id"] ?>,<?= json_encode($w["website_name"]) ?>,<?= json_encode($w["website_url"]) ?>,<?= json_encode($w["status"]) ?>)'>Edit</button>
<button onclick="go('delete',<?= $w['id'] ?>)">Del</button>
<button onclick="go('verify',<?= $w['id'] ?>)">Verify</button>
</td>
</tr>
<?php endforeach; ?>

</table>
</div>

</div>

<!-- MODAL -->
<div class="modal" id="modal">
<div class="modal-box">
<form method="POST">
<input type="hidden" name="action" id="action">
<input type="hidden" name="id" id="id">

<input name="website_name" id="name" placeholder="Name">
<input name="website_url" id="url" placeholder="URL">
<select name="status" id="status">
<option value="active">Active</option>
<option value="pending">Pending</option>
<option value="suspended">Suspended</option>
</select>

<button class="btn">Save</button>
<button type="button" onclick="closeModal()">Cancel</button>
</form>
</div>
</div>

<script>
function openModal(){
    modal.style.display='flex';
    action.value='add';
}
function edit(id,name,url,status){
    openModal();
    action.value='edit';
    document.getElementById('id').value=id;
    document.getElementById('name').value=name;
    document.getElementById('url').value=url;
    document.getElementById('status').value=status;
}
function closeModal(){modal.style.display='none';}
function go(a,id){ if(confirm('Confirm?')) location='websites.php?action='+a+'&id='+id;}
</script>

</body>
</html>