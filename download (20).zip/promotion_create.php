<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/db.php';
$pdo = getDBConnection();

$siteName = 'CodeBihin';

// Get employee ID from URL
$selectedEmployeeId = (int)($_GET['id'] ?? 0);

// Fetch employee if ID provided
$selectedEmployee = null;
if ($selectedEmployeeId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
    $stmt->execute([$selectedEmployeeId]);
    $selectedEmployee = $stmt->fetch();
}

// Fetch all active employees
$allEmployees = $pdo->query("SELECT id, name, id_no, role, salary FROM Employee WHERE resign = 0 AND blocked = 0 ORDER BY name")->fetchAll();

// Fetch all roles
$allRoles = $pdo->query("SELECT role_name FROM roles ORDER BY role_name")->fetchAll(PDO::FETCH_COLUMN);

// Handle form submit
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empId = (int)$_POST['employee_id'];
    $type = $_POST['type'] ?? 'promotion';
    $newRole = trim($_POST['new_role'] ?? '');
    $newSalary = floatval($_POST['new_salary'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $effectiveDate = $_POST['effective_date'] ?? date('Y-m-d');

    if ($empId <= 0) {
        $message = 'Please select an employee.';
        $messageType = 'error';
    } elseif (empty($newRole)) {
        $message = 'Please select a new role.';
        $messageType = 'error';
    } elseif ($newSalary <= 0) {
        $message = 'Please enter a valid salary.';
        $messageType = 'error';
    } elseif (empty($reason)) {
        $message = 'Please provide a reason.';
        $messageType = 'error';
    } else {
        try {
            $token = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
            $createdBy = $_SESSION['username'] ?? 'Admin';

            $stmt = $pdo->prepare("
                INSERT INTO promotion_offers 
                (employee_id, token, new_role, new_salary, effective_date, reason, type, created_by, created_at, expires_at, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'pending')
            ");
            $stmt->execute([$empId, $token, $newRole, $newSalary, $effectiveDate, $reason, $type, $createdBy, $expiresAt]);

            // Reload to show employee name
            $empStmt = $pdo->prepare("SELECT name FROM Employee WHERE id = ?");
            $empStmt->execute([$empId]);
            $empName = $empStmt->fetchColumn();

            $message = 'Offer created successfully for ' . $empName . '!';
            $messageType = 'success';
            
            // Reset form
            $selectedEmployeeId = 0;
            $selectedEmployee = null;

        } catch (PDOException $e) {
            $message = 'Database error: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}

// Reload employee if form submitted with one
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $empId > 0 && !$selectedEmployee) {
    $stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
    $stmt->execute([$empId]);
    $selectedEmployee = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Promotion · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', system-ui, sans-serif; }
        body { background: #0f172a; min-height: 100vh; display: flex; }
        .main { flex: 1; margin-left: 280px; padding: 28px 36px; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
        .top-bar h1 { color: #fff; font-size: 22px; }
        .user-menu { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.05); padding: 7px 16px; border-radius: 40px; }
        .user-avatar { background: #2f6db3; width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #fff; font-size: 15px; }
        .logout-btn { background: rgba(231,76,60,0.2); padding: 6px 14px; border-radius: 30px; color: #ffaaa5; text-decoration: none; font-size: 12px; }
        .logout-btn:hover { background: rgba(231,76,60,0.4); color: #fff; }
        
        .back-link { color: #94a3b8; text-decoration: none; font-size: 13px; display: inline-block; margin-bottom: 16px; }
        .back-link:hover { color: #f9b233; }
        
        .alert { padding: 12px 16px; border-radius: 12px; margin-bottom: 16px; font-size: 13px; }
        .alert-error { background: rgba(231,76,60,0.15); border-left: 3px solid #e74c3c; color: #f5b7b1; }
        .alert-success { background: rgba(46,204,113,0.15); border-left: 3px solid #2ecc71; color: #a3e4bc; }
        
        .card { background: rgba(20,35,55,0.8); border-radius: 18px; padding: 24px; border: 1px solid rgba(255,255,255,0.08); max-width: 650px; }
        h2 { color: #f9b233; border-left: 4px solid #f9b233; padding-left: 14px; margin-bottom: 20px; font-size: 18px; }
        
        .info-box { background: rgba(0,0,0,0.3); border-radius: 10px; padding: 12px 16px; margin-bottom: 16px; }
        .info-box p { color: #cbd5e6; font-size: 13px; margin: 4px 0; }
        .info-box strong { color: #f9b233; }
        
        label { display: block; color: #cbd5e6; margin: 14px 0 5px; font-size: 13px; font-weight: 500; }
        select, input, textarea { width: 100%; padding: 10px 14px; background: rgba(0,0,0,0.4); border: 1px solid #3d5e7e; border-radius: 10px; color: #fff; font-size: 14px; outline: none; }
        select:focus, input:focus, textarea:focus { border-color: #f9b233; }
        select { cursor: pointer; }
        textarea { min-height: 80px; resize: vertical; }
        
        .btn-row { display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap; }
        .btn { padding: 10px 20px; border: none; border-radius: 20px; cursor: pointer; font-weight: 600; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; text-decoration: none; }
        .btn-primary { background: #f9b233; color: #0f172a; }
        .btn-primary:hover { background: #e0a00f; }
        .btn-secondary { background: #475569; color: #fff; }
        .btn-secondary:hover { background: #334155; }
        
        @media (max-width: 768px) { .main { margin-left: 75px; padding: 16px; } }
    </style>
</head>
<body>
    <?php include __DIR__ . '/menu.php'; ?>

    <div class="main">
        <div class="top-bar">
            <h1><i class="fas fa-chart-line"></i> Create Promotion / Demotion</h1>
            <div class="user-menu">
                <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?></div>
                <span style="color:#fff;font-size:13px;"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
            </div>
        </div>

        <a href="promotions.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Promotions</a>

        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <div class="card">
            <h2><i class="fas fa-paper-plane"></i> New Offer</h2>

            <form method="POST">
                <label>Select Employee *</label>
                <select name="employee_id" required>
                    <option value="">-- Choose Employee --</option>
                    <?php foreach ($allEmployees as $emp): ?>
                        <option value="<?= $emp['id'] ?>" <?= ($selectedEmployee && $selectedEmployee['id'] == $emp['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($emp['name']) ?> (<?= htmlspecialchars($emp['id_no']) ?>) - <?= htmlspecialchars($emp['role']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <?php if ($selectedEmployee): ?>
                <div class="info-box">
                    <p><strong>Employee:</strong> <?= htmlspecialchars($selectedEmployee['name']) ?></p>
                    <p><strong>Current Role:</strong> <?= htmlspecialchars($selectedEmployee['role']) ?></p>
                    <p><strong>Current Salary:</strong> ₹ <?= number_format($selectedEmployee['salary'], 2) ?></p>
                </div>
                <?php endif; ?>

                <label>Action Type *</label>
                <select name="type" required>
                    <option value="promotion">🎉 Promotion</option>
                    <option value="demotion">⚠️ Demotion</option>
                </select>

                <label>New Role *</label>
                <select name="new_role" required>
                    <option value="">-- Select New Role --</option>
                    <?php foreach ($allRoles as $role): ?>
                        <option value="<?= htmlspecialchars($role) ?>"><?= htmlspecialchars($role) ?></option>
                    <?php endforeach; ?>
                </select>

                <label>New Salary (₹) *</label>
                <input type="number" step="0.01" name="new_salary" value="<?= $selectedEmployee ? $selectedEmployee['salary'] : '' ?>" required>

                <label>Effective Date *</label>
                <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required>

                <label>Reason *</label>
                <textarea name="reason" placeholder="Enter reason for this action..." required></textarea>

                <div class="btn-row">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Create Offer</button>
                    <a href="promotions.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>