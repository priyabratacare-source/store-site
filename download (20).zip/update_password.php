<?php
require __DIR__ . '/db.php';

$pdo = getDBConnection();

// If token and password are present, update the account
if (isset($_POST['token']) && isset($_POST['password'])) {
    $token   = $_POST['token'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, reset_token = NULL WHERE reset_token = ?");
    $stmt->execute([$password, $token]);

    // Optionally check if any row was affected, but we redirect anyway
    // $success = $stmt->rowCount() > 0;
}

// Redirect to admin.codebihin.in no matter what
header("Location: https://admin.codebihin.in/");
exit;