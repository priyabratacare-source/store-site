<?php
/**
 * forgot.php - Password recovery page
 * 
 * Displays a form to request a password reset link.
 * Site name is dynamically loaded from the settings table.
 * No login required.
 */

// Start session for potential messages (optional)
session_start();

// Include database connection
require_once 'db.php';

// Fetch site name from database (fallback to 'CodeBihin')
$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $stmt->execute();
    $result = $stmt->fetchColumn();
    if ($result) {
        $siteName = $result;
    }
} catch (PDOException $e) {
    // Table might not exist – use fallback silently
    error_log("forgot.php: Could not fetch site name - " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title><?php echo htmlspecialchars($siteName); ?> · Password recovery</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', system-ui, 'Inter', -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
    }

    body {
      display: flex;
      height: 100vh;
      width: 100%;
      overflow: hidden;
    }

    .left {
      width: 36%;
      background: rgba(12, 25, 38, 0.94);
      backdrop-filter: blur(14px);
      color: #fff;
      padding: 48px 44px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      box-shadow: 8px 0 32px rgba(0, 0, 0, 0.4);
      z-index: 10;
      border-right: 1px solid rgba(255, 255, 255, 0.08);
    }

    @media (max-width: 880px) {
      .left { width: 45%; padding: 36px 28px; }
    }
    @media (max-width: 700px) {
      body { flex-direction: column; }
      .left { width: 100%; height: 60%; backdrop-filter: blur(16px); padding: 32px 28px; }
      .right { width: 100%; height: 40%; min-height: 260px; }
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 14px;
      margin-bottom: 36px;
      flex-wrap: wrap;
    }
    .logo-img {
      height: 52px;
      width: auto;
      max-width: 180px;
      object-fit: contain;
    }
    .logo span {
      font-size: 32px;
      font-weight: 800;
      background: linear-gradient(125deg, #FFFFFF, #c7e2ff);
      background-clip: text;
      -webkit-background-clip: text;
      color: transparent;
      letter-spacing: -0.5px;
    }

    h3 {
      font-size: 26px;
      font-weight: 700;
      margin-bottom: 18px;
      border-left: 4px solid #f9b233;
      padding-left: 18px;
    }

    .info-text {
      font-size: 14px;
      color: #cbdbe6;
      margin-bottom: 25px;
      line-height: 1.5;
    }

    label {
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 6px;
      display: block;
      color: #eef4ff;
    }

    input {
      width: 100%;
      padding: 13px 16px;
      border-radius: 20px;
      border: 1px solid #3d5e7e;
      background: rgba(20, 35, 55, 0.8);
      color: #ffffff;
      font-size: 15px;
      outline: none;
      transition: all 0.2s;
      margin-bottom: 18px;
    }

    input:focus {
      border-color: #f9b233;
      box-shadow: 0 0 0 3px rgba(249, 178, 51, 0.25);
      background: #142637;
    }

    button {
      width: 100%;
      padding: 14px;
      background: linear-gradient(100deg, #2f6db3, #1e5290);
      border: none;
      border-radius: 44px;
      color: white;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      transition: all 0.25s;
    }

    button:hover {
      background: linear-gradient(100deg, #1f5cb0, #154877);
      transform: translateY(-2px);
    }

    .back-link {
      margin-top: 30px;
      text-align: center;
      font-size: 14px;
    }

    .back-link a {
      color: #9bc0ff;
      text-decoration: none;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: color 0.2s;
    }

    .back-link a:hover {
      color: #f9b233;
      text-decoration: underline;
    }

    .right {
      width: 64%;
      position: relative;
      background-size: cover;
      background-position: center;
      transition: background-image 0.9s ease;
    }
    .right::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(125deg, rgba(0,0,0,0.2), rgba(0,0,0,0.45));
      pointer-events: none;
    }
    .overlay-text {
      position: absolute;
      bottom: 28px;
      right: 28px;
      color: white;
      text-align: right;
      z-index: 3;
      backdrop-filter: blur(12px);
      background: rgba(0,0,0,0.5);
      padding: 12px 26px;
      border-radius: 44px;
    }
    .overlay-text h2 {
      font-size: 26px;
      font-weight: 700;
    }
    .overlay-text p {
      font-size: 12px;
      opacity: 0.85;
    }
    .image-status {
      position: absolute;
      bottom: 18px;
      left: 20px;
      font-size: 11px;
      background: rgba(0,0,0,0.55);
      backdrop-filter: blur(8px);
      padding: 6px 14px;
      border-radius: 40px;
      color: #eef2ff;
    }

    @media (max-width: 520px) {
      .left { padding: 28px 20px; }
      .logo-img { height: 40px; }
      .logo span { font-size: 26px; }
      h3 { font-size: 22px; }
      .overlay-text { padding: 8px 18px; }
      .overlay-text h2 { font-size: 18px; }
    }
  </style>
</head>
<body>

<div class="left">
  <div class="logo">
    <img class="logo-img" src="https://admin.codebihin.in/logo.png" alt="<?php echo htmlspecialchars($siteName); ?>" onerror="this.src='https://placehold.co/200x60/0b1b2b/f9b233?text=<?php echo urlencode($siteName); ?>';">
    <span><?php echo htmlspecialchars($siteName); ?></span>
  </div>

  <h3>Reset Password</h3>

  <div class="info-text">
    Enter your email. We will send a reset link.
  </div>

  <form method="POST" action="send_email.php">
    <label>Email Address</label>
    <input type="email" name="email" required placeholder="you@<?php echo htmlspecialchars($siteName); ?>.in">

    <button type="submit">
      <i class="fa fa-paper-plane"></i> Send Reset Link
    </button>
  </form>

  <div class="back-link">
    <a href="index.php"><i class="fa-solid fa-arrow-left"></i> Back to sign in</a>
  </div>
</div>

<!-- Dynamic background, same as login page -->
<div class="right" id="dynamicBgRight">
  <div class="overlay-text">
    <h2><?php echo htmlspecialchars($siteName); ?></h2>
    <p>secure platform · © 2026</p>
  </div>
  <div class="image-status">
    <i class="fa-regular fa-images"></i> <span id="refreshCounter">dynamic background</span>
  </div>
</div>

<script>
  // Auto‑changing background (exactly like your login page)
  let bgInterval;
  let counter = 0;

  function getRandomImage() {
    return `https://picsum.photos/1920/1080?random=${Date.now()}`;
  }

  function updateBackground() {
    const bg = document.getElementById('dynamicBgRight');
    if (!bg) return;
    const img = new Image();
    img.onload = () => {
      bg.style.backgroundImage = `url('${img.src}')`;
      bg.style.backgroundSize = 'cover';
      const span = document.getElementById('refreshCounter');
      if (span) span.innerText = `⟳ fresh #${++counter}`;
    };
    img.src = getRandomImage();
  }

  // Start background cycling
  updateBackground();
  bgInterval = setInterval(updateBackground, 7000);

  // Clean up on page leave
  window.addEventListener('beforeunload', () => {
    if (bgInterval) clearInterval(bgInterval);
  });
</script>

</body>
</html>