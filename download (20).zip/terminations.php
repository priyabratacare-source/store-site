<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/db.php';
$pdo = getDBConnection();

$siteName = 'CodeBihin';

// ==================== HANDLE TERMINATION ACTIONS ====================
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'terminate') {
        $employeeId = (int)$_POST['employee_id'];
        $reason = trim($_POST['reason'] ?? '');
        $terminationDate = $_POST['termination_date'] ?? date('Y-m-d');
        
        if (empty($reason)) {
            $error = 'Please provide a termination reason.';
        } elseif (empty($employeeId)) {
            $error = 'Please select an employee.';
        } else {
            try {
                $stmt = $pdo->prepare("
                    UPDATE Employee 
                    SET resign = 1, 
                        resign_date = ?, 
                        termination_reason = ?, 
                        termination_by = ?, 
                        terminated_at = NOW(),
                        blocked = 1
                    WHERE id = ?
                ");
                $stmt->execute([
                    $terminationDate,
                    $reason,
                    $_SESSION['username'] ?? 'Admin',
                    $employeeId
                ]);
                $message = 'Employee terminated successfully.';
            } catch (PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
    elseif ($action === 'reinstate') {
        $employeeId = (int)$_POST['employee_id'];
        try {
            $stmt = $pdo->prepare("
                UPDATE Employee 
                SET resign = 0, 
                    resign_date = NULL, 
                    termination_reason = NULL, 
                    termination_by = NULL, 
                    terminated_at = NULL,
                    blocked = 0
                WHERE id = ?
            ");
            $stmt->execute([$employeeId]);
            $message = 'Employee reinstated successfully.';
        } catch (PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

// ==================== FETCH DATA ====================
$searchTerm = $_GET['search'] ?? '';
$filterStatus = $_GET['status'] ?? 'all';

$query = "SELECT * FROM Employee WHERE 1=1";
$params = [];

if ($filterStatus === 'terminated') {
    $query .= " AND resign = 1";
} elseif ($filterStatus === 'active') {
    $query .= " AND resign = 0 AND blocked = 0";
}

if ($searchTerm) {
    $query .= " AND (name LIKE ? OR id_no LIKE ? OR company_email LIKE ? OR role LIKE ?)";
    $searchParam = "%$searchTerm%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam]);
}

$query .= " ORDER BY resign ASC, terminated_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$employees = $stmt->fetchAll();

// Counts
$totalActive = $pdo->query("SELECT COUNT(*) FROM Employee WHERE resign = 0 AND blocked = 0")->fetchColumn();
$totalTerminated = $pdo->query("SELECT COUNT(*) FROM Employee WHERE resign = 1")->fetchColumn();

// Active employees for dropdown
$activeEmployees = $pdo->query("SELECT id, name, id_no, role FROM Employee WHERE resign = 0 AND blocked = 0 ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminations · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        body {
            background: #0f172a;
            min-height: 100vh;
            display: flex;
        }

        .main {
            flex: 1;
            margin-left: 280px;
            padding: 28px 36px;
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .welcome h1 {
            font-size: 28px;
            color: #ffffff;
            font-weight: 600;
        }

        .welcome p {
            color: #94a3b8;
            margin-top: 6px;
            font-size: 14px;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
            background: rgba(255, 255, 255, 0.05);
            padding: 8px 20px;
            border-radius: 48px;
            backdrop-filter: blur(4px);
        }

        .user-avatar {
            background: #2f6db3;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 17px;
            color: white;
        }

        .user-info .name {
            font-weight: 600;
            color: white;
            font-size: 14px;
        }

        .user-info .role {
            font-size: 11px;
            color: #94a3b8;
        }

        .logout-btn {
            background: rgba(231, 76, 60, 0.2);
            padding: 8px 16px;
            border-radius: 40px;
            color: #ffaaa5;
            text-decoration: none;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }

        .logout-btn:hover {
            background: rgba(231, 76, 60, 0.4);
            color: white;
        }

        /* ===== STATS ===== */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: rgba(20, 35, 55, 0.7);
            backdrop-filter: blur(8px);
            border-radius: 18px;
            padding: 22px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            gap: 16px;
            transition: 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            border-color: rgba(249, 178, 51, 0.2);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .stat-icon.green {
            background: rgba(46, 204, 113, 0.15);
            color: #2ecc71;
        }

        .stat-icon.red {
            background: rgba(231, 76, 60, 0.15);
            color: #e74c3c;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #fff;
        }

        .stat-label {
            font-size: 13px;
            color: #94a3b8;
        }

        /* ===== ALERTS ===== */
        .alert {
            padding: 14px 20px;
            border-radius: 16px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideUp 0.3s ease;
        }

        .alert-success {
            background: rgba(46, 204, 113, 0.15);
            border-left: 4px solid #2ecc71;
            color: #a3e4bc;
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.15);
            border-left: 4px solid #e74c3c;
            color: #f5b7b1;
        }

        /* ===== CARD ===== */
        .card {
            background: rgba(20, 35, 55, 0.7);
            backdrop-filter: blur(8px);
            border-radius: 20px;
            padding: 24px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 24px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 20px;
        }

        h2 {
            color: #fff;
            border-left: 4px solid #f9b233;
            padding-left: 16px;
            font-size: 20px;
        }

        h3 {
            color: #fff;
            border-left: 4px solid #f9b233;
            padding-left: 16px;
            margin-bottom: 20px;
            font-size: 18px;
        }

        /* ===== TOOLBAR ===== */
        .toolbar {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 8px 14px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .search-box input {
            background: transparent;
            border: none;
            color: #fff;
            outline: none;
            font-size: 13px;
            width: 200px;
        }

        .search-box input::placeholder {
            color: #64748b;
        }

        .search-box i {
            color: #64748b;
        }

        .filter-select {
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 13px;
            outline: none;
            cursor: pointer;
        }

        .filter-select:focus {
            border-color: #f9b233;
        }

        /* ===== BUTTONS ===== */
        .btn {
            padding: 10px 20px;
            border-radius: 14px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #fff;
            transition: all 0.2s;
            text-decoration: none;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #27ae60;
        }

        .btn-success:hover {
            background: #1e8449;
            transform: translateY(-2px);
        }

        .btn-warning {
            background: #f39c12;
        }

        .btn-warning:hover {
            background: #d68910;
            transform: translateY(-2px);
        }

        .btn-sm {
            padding: 6px 14px;
            font-size: 11px;
            border-radius: 10px;
        }

        /* ===== TABLE ===== */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px 16px;
            text-align: left;
            color: #e2e8f0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            font-size: 13px;
        }

        th {
            background: rgba(0, 0, 0, 0.3);
            font-weight: 600;
            color: #94a3b8;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.03);
        }

        tr.terminated {
            background: rgba(231, 76, 60, 0.05);
        }

        tr.terminated td {
            color: #94a3b8;
        }

        /* ===== BADGES ===== */
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .badge-active {
            background: rgba(46, 204, 113, 0.15);
            color: #2ecc71;
        }

        .badge-terminated {
            background: rgba(231, 76, 60, 0.15);
            color: #e74c3c;
        }

        .badge-role {
            background: rgba(249, 178, 51, 0.15);
            color: #f9b233;
        }

        /* ===== MODAL ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.8);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(6px);
            animation: fadeIn 0.2s ease;
        }

        .modal-overlay.show {
            display: flex;
        }

        .modal-box {
            background: #0f1a24;
            border-radius: 24px;
            padding: 30px;
            width: 92%;
            max-width: 520px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            animation: slideUp 0.3s ease;
        }

        .modal-box h3 {
            color: #fff;
            border: none;
            padding: 0;
            margin-bottom: 20px;
            font-size: 20px;
        }

        .modal-box label {
            display: block;
            color: #94a3b8;
            margin-bottom: 6px;
            font-size: 13px;
        }

        .modal-box input,
        .modal-box select,
        .modal-box textarea {
            width: 100%;
            padding: 10px 14px;
            margin-bottom: 16px;
            border-radius: 12px;
            border: 1px solid #3d5e7e;
            background: rgba(0, 0, 0, 0.4);
            color: #fff;
            font-size: 14px;
            outline: none;
        }

        .modal-box textarea {
            resize: vertical;
            min-height: 80px;
        }

        .modal-box input:focus,
        .modal-box select:focus,
        .modal-box textarea:focus {
            border-color: #f9b233;
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 8px;
            flex-wrap: wrap;
        }

        .employee-preview {
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .employee-preview .avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #2f6db3;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #fff;
            font-size: 16px;
        }

        .employee-preview .info strong {
            color: #fff;
            display: block;
        }

        .employee-preview .info span {
            color: #94a3b8;
            font-size: 12px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #94a3b8;
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.4;
        }

        @media (max-width: 768px) {
            .main {
                margin-left: 75px;
                padding: 20px;
            }

            .stats-row {
                grid-template-columns: 1fr 1fr;
            }

            .search-box input {
                width: 120px;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 10px 8px;
            }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/menu.php'; ?>

    <div class="main">
        <!-- ===== TOP BAR ===== -->
        <div class="top-bar">
            <div class="welcome">
                <h1><i class="fas fa-user-times"></i> Terminations</h1>
                <p>Manage employee terminations & reinstatements</p>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?></div>
                <div class="user-info">
                    <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></div>
                    <div class="role">Administrator</div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
            </div>
        </div>

        <!-- ===== ALERTS ===== -->
        <?php if ($message): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- ===== STATS ===== -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
                <div>
                    <div class="stat-value"><?= $totalActive ?></div>
                    <div class="stat-label">Active Employees</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-user-slash"></i></div>
                <div>
                    <div class="stat-value"><?= $totalTerminated ?></div>
                    <div class="stat-label">Terminated</div>
                </div>
            </div>
        </div>

        <!-- ===== EMPLOYEE LIST ===== -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> Employee List</h2>
                <div class="toolbar">
                    <form method="GET" class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" name="search" placeholder="Search employees..." value="<?= htmlspecialchars($searchTerm) ?>">
                        <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
                    </form>
                    <select class="filter-select" onchange="window.location.href='?status='+this.value+'&search=<?= urlencode($searchTerm) ?>'">
                        <option value="all" <?= $filterStatus == 'all' ? 'selected' : '' ?>>All Employees</option>
                        <option value="active" <?= $filterStatus == 'active' ? 'selected' : '' ?>>Active Only</option>
                        <option value="terminated" <?= $filterStatus == 'terminated' ? 'selected' : '' ?>>Terminated Only</option>
                    </select>
                    <button class="btn btn-danger" onclick="openTerminateModal()">
                        <i class="fas fa-user-times"></i> Terminate Employee
                    </button>
                </div>
            </div>

            <div class="table-wrapper">
                <?php if (count($employees) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>ID No.</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Termination Date</th>
                            <th>Reason</th>
                            <th>Terminated By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; foreach ($employees as $emp): 
                            $isTerminated = $emp['resign'] == 1;
                        ?>
                        <tr class="<?= $isTerminated ? 'terminated' : '' ?>">
                            <td><?= $count++ ?></td>
                            <td>
                                <strong><?= htmlspecialchars($emp['name']) ?></strong><br>
                                <small style="color:#94a3b8;"><?= htmlspecialchars($emp['company_email'] ?? $emp['personal_email']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($emp['id_no'] ?? '-') ?></td>
                            <td><span class="badge badge-role"><?= htmlspecialchars($emp['role']) ?></span></td>
                            <td>
                                <?php if ($isTerminated): ?>
                                    <span class="badge badge-terminated"><i class="fas fa-ban"></i> Terminated</span>
                                <?php else: ?>
                                    <span class="badge badge-active"><i class="fas fa-check-circle"></i> Active</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $emp['resign_date'] ? date('d M Y', strtotime($emp['resign_date'])) : '-' ?></td>
                            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($emp['termination_reason'] ?? '') ?>">
                                <?= htmlspecialchars($emp['termination_reason'] ?? '-') ?>
                            </td>
                            <td><?= htmlspecialchars($emp['termination_by'] ?? '-') ?></td>
                            <td>
                                <?php if ($isTerminated): ?>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Reinstate this employee?')">
                                        <input type="hidden" name="action" value="reinstate">
                                        <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                        <button type="submit" class="btn btn-success btn-sm">
                                            <i class="fas fa-undo"></i> Reinstate
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-danger btn-sm" onclick="openTerminateModal(<?= $emp['id'] ?>, '<?= addslashes($emp['name']) ?>', '<?= addslashes($emp['id_no']) ?>')">
                                        <i class="fas fa-user-times"></i> Terminate
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <p>No employees found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ===== TERMINATION MODAL ===== -->
    <div class="modal-overlay" id="terminateModal">
        <div class="modal-box">
            <h3><i class="fas fa-user-times"></i> Terminate Employee</h3>
            
            <form method="POST" id="terminateForm">
                <input type="hidden" name="action" value="terminate">
                <input type="hidden" name="employee_id" id="terminateEmployeeId">
                
                <label>Select Employee *</label>
                <select name="employee_id_select" id="employeeSelect" onchange="updateEmployeePreview()">
                    <option value="">-- Select Employee --</option>
                    <?php foreach ($activeEmployees as $emp): ?>
                        <option value="<?= $emp['id'] ?>" data-name="<?= htmlspecialchars($emp['name']) ?>" data-idno="<?= htmlspecialchars($emp['id_no']) ?>" data-role="<?= htmlspecialchars($emp['role']) ?>">
                            <?= htmlspecialchars($emp['name']) ?> (<?= htmlspecialchars($emp['id_no']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>

                <div class="employee-preview" id="employeePreview" style="display:none;">
                    <div class="avatar" id="previewAvatar">E</div>
                    <div class="info">
                        <strong id="previewName">-</strong>
                        <span id="previewDetails">-</span>
                    </div>
                </div>

                <label>Termination Date *</label>
                <input type="date" name="termination_date" value="<?= date('Y-m-d') ?>" required>

                <label>Reason for Termination *</label>
                <textarea name="reason" placeholder="Provide detailed reason for termination..." required></textarea>

                <div class="modal-actions">
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure? This will block the employee from logging in.')">
                        <i class="fas fa-check"></i> Confirm Termination
                    </button>
                    <button type="button" class="btn btn-warning" onclick="closeTerminateModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openTerminateModal(empId = null, empName = '', empIdNo = '') {
            document.getElementById('terminateModal').classList.add('show');
            
            if (empId) {
                document.getElementById('terminateEmployeeId').value = empId;
                document.getElementById('employeeSelect').value = empId;
                document.getElementById('employeePreview').style.display = 'flex';
                document.getElementById('previewName').textContent = empName;
                document.getElementById('previewDetails').textContent = 'ID: ' + empIdNo;
                document.getElementById('previewAvatar').textContent = empName.charAt(0).toUpperCase();
            } else {
                document.getElementById('employeeSelect').value = '';
                document.getElementById('employeePreview').style.display = 'none';
            }
        }

        function closeTerminateModal() {
            document.getElementById('terminateModal').classList.remove('show');
        }

        function updateEmployeePreview() {
            const select = document.getElementById('employeeSelect');
            const option = select.options[select.selectedIndex];
            
            if (select.value) {
                document.getElementById('terminateEmployeeId').value = select.value;
                document.getElementById('employeePreview').style.display = 'flex';
                document.getElementById('previewName').textContent = option.getAttribute('data-name');
                document.getElementById('previewDetails').textContent = 'ID: ' + option.getAttribute('data-idno') + ' | ' + option.getAttribute('data-role');
                document.getElementById('previewAvatar').textContent = option.getAttribute('data-name').charAt(0).toUpperCase();
            } else {
                document.getElementById('employeePreview').style.display = 'none';
            }
        }

        // Close modal on overlay click
        document.getElementById('terminateModal').addEventListener('click', function(e) {
            if (e.target === this) closeTerminateModal();
        });

        // Close on Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeTerminateModal();
        });
    </script>
</body>
</html>