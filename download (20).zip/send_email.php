<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . '/db.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';
require __DIR__ . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_POST['email'])) {
    header("Location: https://admin.codebihin.in/");
    exit;
}

$email = trim($_POST['email']);

// Basic email check (still redirects)
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: https://admin.codebihin.in/");
    exit;
}

// DB connection
$pdo = getDBConnection();

// Check user
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Always redirect – never reveal if the email exists or not
if (!$user) {
    header("Location: https://admin.codebihin.in/");
    exit;
}

// -------------------------------------------------------------------
// Generate token with EXPIRY (3 minutes = 180 seconds)
// Token structure: 48 hex random + 8 hex expiry timestamp
// -------------------------------------------------------------------
$randomPart = bin2hex(random_bytes(24));                // 48 chars
$expiryPart = str_pad(dechex(time() + 180), 8, '0', STR_PAD_LEFT); // 8 chars
$token = $randomPart . $expiryPart;

// Store the token (plain text, as per your DB)
$update = $pdo->prepare("UPDATE users SET reset_token = ? WHERE email = ?");
$update->execute([$token, $email]);

// Reset link
$link = "https://admin.codebihin.in/reset_password.php?token=" . urlencode($token);

// -------------------------------------------------------------------
// Email HTML (3 minutes validity, digitally signed)
// -------------------------------------------------------------------
$emailBody = "
<!DOCTYPE html>
<html>
<head>
<meta charset=\"UTF-8\">
<title>Password Reset Request</title>
</head>
<body style=\"margin:0; padding:0; font-family: Arial, sans-serif; background-color:#f4f4f4;\">
  <table align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"padding:20px;\">
    <tr>
      <td>
        <table align=\"center\" width=\"500\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#ffffff; border-radius:8px; padding:20px;\">
          <tr>
            <td align=\"center\">
              <img src=\"https://admin.codebihin.in/logo.png\" alt=\"CodeBihin Logo\" width=\"120\" style=\"margin-bottom:15px;\">
            </td>
          </tr>
          <tr>
            <td align=\"center\">
              <h2 style=\"color:#333;\">Password Reset Request</h2>
            </td>
          </tr>
          <tr>
            <td style=\"color:#555; font-size:14px; line-height:1.6;\">
              <p>Dear User,</p>
              <p>We received a request to reset your account password.</p>
              <p><strong>Email Address:</strong> {$email}</p>
              <p>Click the button below to reset your password:</p>
              <p style=\"text-align:center;\">
                <a href=\"{$link}\" 
                   style=\"background:#007bff; color:#ffffff; padding:10px 20px; text-decoration:none; border-radius:5px; display:inline-block;\">
                   Reset Password
                </a>
              </p>
              <p>This link is valid for <strong>3 minutes</strong> only. After that, it will expire for security reasons.</p>
              <p>If you did not request this, please ignore this email.</p>
              <br>
              <p>Thank You,</p>
              <p><strong>Digitally Signed By</strong><br>
              Team CodeBihin IT System<br>
              Password Recovery Service</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>";

// -------------------------------------------------------------------
// Send email with your SMTP credentials
// -------------------------------------------------------------------
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.zoho.in';
    $mail->SMTPAuth = true;
    $mail->Username = 'info@codebihin.in';
    $mail->Password = '5PJxDcP4K8Tc';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('info@codebihin.in', 'CodeBihin');
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = "Password Reset Request";
    $mail->Body = $emailBody;

    $mail->send();

} catch (Exception $e) {
    // Log the real error, but still redirect the user
    error_log("Password reset email failed for {$email}: " . $mail->ErrorInfo);
}

// Always redirect – success or failure
header("Location: https://admin.codebihin.in/");
exit;