<?php
echo "<h1>Test OK</h1>";
echo "PHP Version: " . phpversion() . "<br>";

require_once __DIR__ . '/db.php';
$pdo = getDBConnection();
echo "DB Connected: YES<br>";

// Check tables
try {
    $count = $pdo->query("SELECT COUNT(*) FROM roles")->fetchColumn();
    echo "Roles table: $count rows<br>";
} catch (Exception $e) {
    echo "Roles table ERROR: " . $e->getMessage() . "<br>";
}

try {
    $count = $pdo->query("SELECT COUNT(*) FROM Employee")->fetchColumn();
    echo "Employee table: $count rows<br>";
} catch (Exception $e) {
    echo "Employee table ERROR: " . $e->getMessage() . "<br>";
}

try {
    $count = $pdo->query("SELECT COUNT(*) FROM promotion_offers")->fetchColumn();
    echo "promotion_offers table: $count rows<br>";
} catch (Exception $e) {
    echo "promotion_offers table ERROR: " . $e->getMessage() . "<br>";
}

session_start();
echo "Session: " . (isset($_SESSION['user_id']) ? 'Logged in as ' . $_SESSION['user_id'] : 'NOT LOGGED IN') . "<br>";

echo "<hr><strong>All checks passed!</strong>";
?>