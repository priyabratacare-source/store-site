<?php
if (!function_exists('getDBConnection')) {
    require_once __DIR__ . '/db.php';
}

$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $stmt->execute();
    $result = $stmt->fetchColumn();
    if ($result) $siteName = $result;
} catch (PDOException $e) {
    error_log("menu.php: " . $e->getMessage());
}

$currentFile = basename($_SERVER['PHP_SELF']);
?>

<style>
.sidebar {
    width: 280px;
    height: 100vh;
    background: rgba(12,25,38,0.97);
    backdrop-filter: blur(8px);
    color: #fff;
    position: fixed;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    border-right: 1px solid rgba(255,255,255,0.08);
    z-index: 1000;
    overflow-y: auto;
    overflow-x: hidden;
}
.sidebar::-webkit-scrollbar {
    width: 4px;
}
.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.1);
    border-radius: 4px;
}
.sidebar-header {
    padding: 24px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    flex-shrink: 0;
}
.logo {
    display: flex;
    align-items: center;
    gap: 12px;
}
.logo-img {
    height: 42px;
    width: auto;
}
.logo span {
    font-size: 22px;
    font-weight: 800;
    background: linear-gradient(125deg, #FFF, #c7e2ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.nav {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 16px 12px;
}
.nav-section-title {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #64748b;
    padding: 12px 16px 4px;
    margin-top: 4px;
    font-weight: 700;
}
.nav-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 11px 16px;
    border-radius: 12px;
    color: #cbd5e6;
    text-decoration: none;
    font-weight: 500;
    font-size: 14px;
    transition: all 0.25s;
    position: relative;
}
.nav-item i {
    width: 20px;
    font-size: 16px;
    text-align: center;
    flex-shrink: 0;
}
.nav-item:hover {
    background: rgba(249,178,51,0.1);
    color: #f9b233;
    transform: translateX(4px);
}
.nav-item.active {
    background: rgba(47,109,179,0.25);
    color: #fff;
    border-left: 3px solid #f9b233;
    font-weight: 600;
}
.nav-item .badge {
    margin-left: auto;
    font-size: 10px;
    background: rgba(249,178,51,0.2);
    color: #f9b233;
    padding: 2px 8px;
    border-radius: 10px;
}
.nav-divider {
    border-top: 1px solid rgba(255,255,255,0.06);
    margin: 8px 0;
}
.nav-item.logout {
    color: #ffaaa5;
    margin-top: auto;
}
.nav-item.logout:hover {
    background: rgba(231,76,60,0.2);
    color: #ff6b6b;
    transform: translateX(4px);
}
.nav-item.logout.active {
    background: rgba(231,76,60,0.3);
    border-left-color: #e74c3c;
}

/* Mobile */
@media (max-width:768px) {
    .sidebar {
        width: 75px;
    }
    .logo span,
    .nav-item span,
    .nav-section-title,
    .nav-item .badge {
        display: none;
    }
    .nav-item {
        justify-content: center;
        padding: 12px;
    }
    .nav-item i {
        font-size: 18px;
    }
}
</style>

<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img class="logo-img" src="https://admin.codebihin.in/logo.png" alt="<?= htmlspecialchars($siteName) ?>" onerror="this.style.display='none';">
            <span><?= htmlspecialchars($siteName) ?></span>
        </div>
    </div>
    
    <div class="nav">
        
        <!-- ==================== DASHBOARD ==================== -->
        <div class="nav-section-title">Main</div>
        <a href="dashboard.php" class="nav-item <?= $currentFile == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>

        <!-- ==================== EMPLOYEE MANAGEMENT ==================== -->
        <div class="nav-section-title">Employees</div>
        <a href="employee_list.php" class="nav-item <?= in_array($currentFile, ['employee_list.php', 'employee_view.php', 'employee_edit.php']) ? 'active' : '' ?>">
            <i class="fas fa-users"></i>
            <span>All Employees</span>
        </a>
        <a href="add_employee.php" class="nav-item <?= $currentFile == 'add_employee.php' ? 'active' : '' ?>">
            <i class="fas fa-user-plus"></i>
            <span>Add Employee</span>
        </a>
        <a href="job_offers.php" class="nav-item <?= in_array($currentFile, ['job_offers.php', 'job_offer_create.php']) ? 'active' : '' ?>">
            <i class="fas fa-file-contract"></i>
            <span>Job Offers</span>
        </a>

        <!-- ==================== ATTENDANCE ==================== -->
        <div class="nav-section-title">Attendance</div>
        <a href="admin_attendance.php" class="nav-item <?= in_array($currentFile, ['admin_attendance.php', 'admin_employee_attendance.php']) ? 'active' : '' ?>">
            <i class="fas fa-calendar-check"></i>
            <span>Attendance</span>
        </a>

        <!-- ==================== HR & COMMUNICATION ==================== -->
        <div class="nav-section-title">HR & Communication</div>
        <a href="notices.php" class="nav-item <?= in_array($currentFile, ['notices.php', 'add_notice.php', 'edit_notice.php']) ? 'active' : '' ?>">
            <i class="fas fa-bullhorn"></i>
            <span>Notices</span>
        </a>
        <a href="promotions.php" class="nav-item <?= in_array($currentFile, ['promotions.php', 'promotion_create.php']) ? 'active' : '' ?>">
            <i class="fas fa-chart-line"></i>
            <span>Promotions</span>
        </a>
        <a href="terminations.php" class="nav-item <?= in_array($currentFile, ['terminations.php']) ? 'active' : '' ?>">
            <i class="fas fa-user-times"></i>
            <span>Terminations</span>
        </a>

        <!-- ==================== ACCESS CONTROL ==================== -->
        <div class="nav-section-title">Access Control</div>
        <a href="role_management.php" class="nav-item <?= in_array($currentFile, ['role_management.php', 'role_permissions_management.php']) ? 'active' : '' ?>">
            <i class="fas fa-user-shield"></i>
            <span>Roles & Permissions</span>
        </a>

        <!-- ==================== WEBSITES ==================== -->
        <div class="nav-section-title">Managed Websites</div>
        <a href="websites.php" class="nav-item <?= in_array($currentFile, ['websites.php']) ? 'active' : '' ?>">
            <i class="fas fa-globe"></i>
            <span>Websites</span>
        </a>

        <!-- ==================== SETTINGS ==================== -->
        <div class="nav-section-title">System</div>
        <a href="settings.php" class="nav-item <?= $currentFile == 'settings.php' ? 'active' : '' ?>">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
        <a href="audit_logs.php" class="nav-item <?= $currentFile == 'audit_logs.php' ? 'active' : '' ?>">
            <i class="fas fa-history"></i>
            <span>Audit Logs</span>
        </a>

        <div class="nav-divider"></div>
        
        <!-- ==================== LOGOUT ==================== -->
        <a href="logout.php" class="nav-item logout <?= $currentFile == 'logout.php' ? 'active' : '' ?>">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</div>