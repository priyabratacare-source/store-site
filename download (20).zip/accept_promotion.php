<?php
session_start();
require_once 'db.php';
$pdo = getDBConnection();

$error = '';
$success = '';

$token = $_GET['token'] ?? '';
if (!$token) {
    die('Invalid link.');
}

// Fetch offer
$stmt = $pdo->prepare("SELECT * FROM promotion_offers WHERE token = ? AND status = 'pending' AND expires_at > NOW()");
$stmt->execute([$token]);
$offer = $stmt->fetch();
if (!$offer) {
    die('This offer link is invalid or has expired.');
}

// Get employee details
$empStmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$empStmt->execute([$offer['employee_id']]);
$employee = $empStmt->fetch();
if (!$employee) {
    die('Employee not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $accept_terms = isset($_POST['accept_terms']);

    if (!$accept_terms) {
        $error = 'You must accept the terms and conditions.';
    } elseif (empty($password)) {
        $error = 'Please enter your password to confirm identity.';
    } else {
        // Verify password
        if (!password_verify($password, $employee['password'])) {
            $error = 'Incorrect password. Please try again.';
        } else {
            try {
                $pdo->beginTransaction();

                // Update employee role and salary
                $update = $pdo->prepare("UPDATE Employee SET role = ?, salary = ? WHERE id = ?");
                $update->execute([$offer['new_role'], $offer['new_salary'], $employee['id']]);

                // Generate signature ID
                $sigId = date('dmy') . substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 3);

                // Log into promotions_log
                $log = $pdo->prepare("
                    INSERT INTO promotions_log 
                    (employee_id, employee_name, type, old_role, new_role, old_salary, new_salary, reason, effective_date, signature_id, signed_by, accepted_at, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                ");
                $log->execute([
                    $employee['id'],
                    $employee['name'],
                    $offer['type'],
                    $employee['role'],
                    $offer['new_role'],
                    $employee['salary'],
                    $offer['new_salary'],
                    $offer['reason'],
                    $offer['effective_date'],
                    $sigId,
                    $employee['name']  // signed by employee
                ]);

                // Mark offer as accepted
                $pdo->prepare("UPDATE promotion_offers SET status = 'accepted' WHERE id = ?")->execute([$offer['id']]);

                $pdo->commit();

                $success = "Congratulations! Your role has been updated to {$offer['new_role']} with salary ₹" . number_format($offer['new_salary'], 2) . ". You can now log out and log back in to see new permissions.";
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accept Promotion/Demotion</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body{background:#0f172a;font-family:'Segoe UI',sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px;}
        .container{background:#fff;border-radius:24px;padding:35px;max-width:600px;width:100%;box-shadow:0 20px 35px rgba(0,0,0,0.2);}
        .header{text-align:center;margin-bottom:25px;}
        .header img{width:100px;}
        h2{color:#0f172a;border-left:4px solid #f9b233;padding-left:15px;margin-bottom:20px;}
        .offer-details{background:#f8fafc;padding:18px;border-radius:16px;margin:20px 0;}
        .offer-details p{margin:8px 0;}
        .terms{margin:20px 0;padding:15px;background:#fef9e6;border-radius:12px;}
        input[type="password"]{width:100%;padding:12px;border:1px solid #ccc;border-radius:12px;margin:10px 0;}
        .btn{background:#2f6db3;color:white;padding:12px 24px;border:none;border-radius:40px;font-weight:bold;cursor:pointer;width:100%;}
        .btn:hover{background:#1e4d82;}
        .error{color:#e74c3c;background:#fdeded;padding:12px;border-radius:12px;margin-bottom:15px;}
        .success{color:#27ae60;background:#e6f7e6;padding:12px;border-radius:12px;margin-bottom:15px;}
        .footer{text-align:center;margin-top:25px;font-size:12px;color:#64748b;}
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <img src="https://admin.codebihin.in/logo.png" alt="CodeBihin">
        <h2>Offer Acceptance</h2>
    </div>

    <?php if($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
        <div style="text-align:center; margin-top:20px;">
            <a href="index.php" style="background:#0f172a; color:white; padding:10px 20px; text-decoration:none; border-radius:30px;">Go to Login</a>
        </div>
    <?php else: ?>
        <?php if($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <div class="offer-details">
            <p><strong>Employee:</strong> <?= htmlspecialchars($employee['name']) ?></p>
            <p><strong>Current Role:</strong> <?= htmlspecialchars($employee['role']) ?></p>
            <p><strong>Offered Role:</strong> <?= htmlspecialchars($offer['new_role']) ?></p>
            <p><strong>Current Salary:</strong> ₹ <?= number_format($employee['salary'], 2) ?></p>
            <p><strong>New Salary:</strong> ₹ <?= number_format($offer['new_salary'], 2) ?></p>
            <p><strong>Effective Date:</strong> <?= date('d-m-Y', strtotime($offer['effective_date'])) ?></p>
            <p><strong>Reason:</strong> <?= nl2br(htmlspecialchars($offer['reason'])) ?></p>
        </div>

        <div class="terms">
            <label style="display:block; margin-bottom:10px;">
                <input type="checkbox" id="termsCheckbox"> I accept the new role and salary terms.
            </label>
            <p style="font-size:13px; margin-top:5px;">By accepting, you agree to the updated responsibilities and compensation structure.</p>
        </div>

        <form method="POST" id="acceptForm">
            <input type="password" name="password" placeholder="Enter your password to confirm identity" required>
            <input type="hidden" name="accept_terms" id="acceptTermsField" value="0">
            <button type="submit" class="btn">Confirm & Accept</button>
        </form>
        <div class="footer">
            This offer is valid until <?= date('d-m-Y H:i', strtotime($offer['expires_at'])) ?>.
        </div>
    <?php endif; ?>
</div>

<script>
    const checkbox = document.getElementById('termsCheckbox');
    const form = document.getElementById('acceptForm');
    const hiddenField = document.getElementById('acceptTermsField');
    form.addEventListener('submit', function(e) {
        if (!checkbox.checked) {
            e.preventDefault();
            alert('You must accept the terms and conditions.');
        } else {
            hiddenField.value = '1';
        }
    });
</script>
</body>
</html>