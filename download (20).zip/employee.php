<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';

$message = '';
$error = '';
$search = $_GET['search'] ?? '';

// Fetch roles for dropdown
$roles_list = $pdo->query("SELECT id, role_name FROM roles ORDER BY role_name")->fetchAll();

// ---------- HANDLE POST ACTIONS (ADD, EDIT, DELETE, BLOCK, SUSPEND) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ADD EMPLOYEE
    if ($action === 'add') {
        // ... (same as your existing add logic, keep it)
        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $personal_email = trim($_POST['personal_email'] ?? '');
        $company_email = trim($_POST['company_email'] ?? '');
        $id_no = trim($_POST['id_no'] ?? '');
        $date_of_joining = $_POST['date_of_joining'] ?? '';
        $image = trim($_POST['image'] ?? '');
        $gender = $_POST['gender'] ?? '';
        $blood_group = trim($_POST['blood_group'] ?? '');
        $document_name = trim($_POST['document_name'] ?? '');
        $document_number = trim($_POST['document_number'] ?? '');
        $document_verify_status = isset($_POST['document_verify_status']) ? 1 : 0;
        $role = trim($_POST['role'] ?? '');
        $salary = floatval($_POST['salary'] ?? 0);
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $mobile_number = trim($_POST['mobile_number'] ?? '');
        $experience = trim($_POST['experience'] ?? '');
        $biodata_file_url = trim($_POST['biodata_file_url'] ?? '');
        $internal_audit_report_url = trim($_POST['internal_audit_report_url'] ?? '');

        if (empty($name) || empty($username) || empty($personal_email) || empty($company_email) || empty($id_no) || empty($date_of_joining) || empty($role) || empty($salary) || empty($password)) {
            $error = 'Required fields missing.';
        } elseif (!filter_var($personal_email, FILTER_VALIDATE_EMAIL) || !filter_var($company_email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            try {
                $check = $pdo->prepare("SELECT id FROM Employee WHERE username = ? OR personal_email = ? OR company_email = ? OR id_no = ?");
                $check->execute([$username, $personal_email, $company_email, $id_no]);
                if ($check->fetch()) {
                    $error = 'Username, email(s), or ID number already exists.';
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $insert = $pdo->prepare("
                        INSERT INTO Employee 
                        (name, username, personal_email, company_email, id_no, date_of_joining, image, gender, blood_group,
                         document_name, document_number, document_verify_status, role, salary, password, mobile_number,
                         experience, biodata_file_url, internal_audit_report_url, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $insert->execute([$name, $username, $personal_email, $company_email, $id_no, $date_of_joining, $image,
                        $gender, $blood_group, $document_name, $document_number, $document_verify_status, $role, $salary,
                        $hash, $mobile_number, $experience, $biodata_file_url, $internal_audit_report_url]);
                    $message = 'Employee added successfully.';
                }
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }

    // EDIT EMPLOYEE (keep your existing edit logic)
    elseif ($action === 'edit') {
        // ... (keep your existing edit code)
        $empId = (int)($_POST['emp_id'] ?? 0);
        if ($empId <= 0) {
            $error = 'Invalid employee ID.';
        } else {
            $name = trim($_POST['name'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $personal_email = trim($_POST['personal_email'] ?? '');
            $company_email = trim($_POST['company_email'] ?? '');
            $id_no = trim($_POST['id_no'] ?? '');
            $date_of_joining = $_POST['date_of_joining'] ?? '';
            $image = trim($_POST['image'] ?? '');
            $gender = $_POST['gender'] ?? '';
            $blood_group = trim($_POST['blood_group'] ?? '');
            $document_name = trim($_POST['document_name'] ?? '');
            $document_number = trim($_POST['document_number'] ?? '');
            $document_verify_status = isset($_POST['document_verify_status']) ? 1 : 0;
            $role = trim($_POST['role'] ?? '');
            $salary = floatval($_POST['salary'] ?? 0);
            $mobile_number = trim($_POST['mobile_number'] ?? '');
            $experience = trim($_POST['experience'] ?? '');
            $biodata_file_url = trim($_POST['biodata_file_url'] ?? '');
            $internal_audit_report_url = trim($_POST['internal_audit_report_url'] ?? '');

            if (empty($name) || empty($username) || empty($personal_email) || empty($company_email) || empty($id_no) || empty($date_of_joining) || empty($role)) {
                $error = 'Required fields missing.';
            } else {
                try {
                    $check = $pdo->prepare("SELECT id FROM Employee WHERE (username = ? OR personal_email = ? OR company_email = ? OR id_no = ?) AND id != ?");
                    $check->execute([$username, $personal_email, $company_email, $id_no, $empId]);
                    if ($check->fetch()) {
                        $error = 'Username, email(s), or ID number already used by another employee.';
                    } else {
                        $update = $pdo->prepare("
                            UPDATE Employee SET 
                                name=?, username=?, personal_email=?, company_email=?, id_no=?, date_of_joining=?, image=?,
                                gender=?, blood_group=?, document_name=?, document_number=?, document_verify_status=?,
                                role=?, salary=?, mobile_number=?, experience=?, biodata_file_url=?, internal_audit_report_url=?
                            WHERE id=?
                        ");
                        $update->execute([$name, $username, $personal_email, $company_email, $id_no, $date_of_joining, $image,
                            $gender, $blood_group, $document_name, $document_number, $document_verify_status,
                            $role, $salary, $mobile_number, $experience, $biodata_file_url, $internal_audit_report_url, $empId]);

                        $newPassword = $_POST['new_password'] ?? '';
                        if (!empty($newPassword)) {
                            $confirmNew = $_POST['confirm_new_password'] ?? '';
                            if ($newPassword === $confirmNew) {
                                $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                                $pwdUpdate = $pdo->prepare("UPDATE Employee SET password = ? WHERE id = ?");
                                $pwdUpdate->execute([$hash, $empId]);
                                $message = 'Employee updated and password changed.';
                            } else {
                                $error = 'New passwords do not match.';
                            }
                        } else {
                            $message = 'Employee updated successfully.';
                        }
                    }
                } catch (PDOException $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }

    // DELETE, BLOCK, SUSPEND, UNSUSPEND (keep your existing code)
    elseif ($action === 'delete') {
        $empId = (int)($_POST['emp_id'] ?? 0);
        if ($empId > 0) {
            try {
                $delete = $pdo->prepare("DELETE FROM Employee WHERE id = ?");
                $delete->execute([$empId]);
                $message = 'Employee deleted permanently.';
            } catch (PDOException $e) {
                $error = 'Cannot delete this employee (maybe foreign key constraint).';
            }
        } else {
            $error = 'Invalid employee ID.';
        }
    }
    elseif ($action === 'block') { $empId = (int)$_POST['emp_id']; $pdo->prepare("UPDATE Employee SET blocked = 1, blocked_by = ?, blocked_at = NOW() WHERE id = ?")->execute([$admin_name, $empId]); $message = 'Employee blocked.'; }
    elseif ($action === 'unblock') { $empId = (int)$_POST['emp_id']; $pdo->prepare("UPDATE Employee SET blocked = 0, blocked_by = NULL, blocked_at = NULL WHERE id = ?")->execute([$empId]); $message = 'Employee unblocked.'; }
    elseif ($action === 'suspend') { $empId = (int)$_POST['emp_id']; $days = (int)$_POST['suspend_days']; $until = date('Y-m-d', strtotime("+$days days")); $pdo->prepare("UPDATE Employee SET suspended = 1, suspension_days = ?, suspended_until = ?, suspended_by = ?, suspended_at = NOW() WHERE id = ?")->execute([$days, $until, $admin_name, $empId]); $message = "Employee suspended for $days days."; }
    elseif ($action === 'unsuspend') { $empId = (int)$_POST['emp_id']; $pdo->prepare("UPDATE Employee SET suspended = 0, suspension_days = NULL, suspended_until = NULL, suspended_by = NULL, suspended_at = NULL WHERE id = ?")->execute([$empId]); $message = 'Employee unsuspended.'; }
}

// Build search query
$sql = "SELECT id, name, username, company_email, role, resign, blocked, suspended, suspension_days, suspended_until FROM Employee WHERE 1=1";
$params = [];
if (!empty($search)) {
    $sql .= " AND (name LIKE ? OR username LIKE ? OR company_email LIKE ? OR personal_email LIKE ? OR id_no LIKE ? OR role LIKE ? OR mobile_number LIKE ?)";
    $like = "%$search%";
    $params = array_fill(0, 7, $like);
}
$sql .= " ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Management · CodeBihin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
        body{background:#0f172a;display:flex;}
        .main{flex:1;margin-left:280px;padding:28px 36px;}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px;flex-wrap:wrap;gap:16px;}
        .welcome h1{font-size:28px;color:#ffffff;}
        .user-menu{display:flex;align-items:center;gap:20px;background:rgba(255,255,255,0.05);padding:8px 20px;border-radius:48px;}
        .user-avatar{background:#2f6db3;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;color:white;}
        .logout-btn{background:rgba(231,76,60,0.2);padding:8px 16px;border-radius:40px;color:#ffaaa5;text-decoration:none;}
        .card{background:rgba(20,35,55,0.7);border-radius:28px;padding:24px;}
        h2{color:white;border-left:4px solid #f9b233;padding-left:16px;margin-bottom:20px;}
        .search-bar{display:flex;gap:12px;margin-bottom:20px;}
        .search-bar input{flex:1;padding:12px;border-radius:30px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.4);color:white;}
        .btn{background:#2f6db3;border:none;padding:8px 16px;border-radius:30px;color:white;cursor:pointer;margin:2px;font-size:12px;}
        .btn-primary{background:#f9b233;color:#0f172a;}
        .btn-danger{background:#e74c3c;}
        .btn-success{background:#27ae60;}
        .btn-warning{background:#f39c12;}
        .btn-info{background:#3498db;}
        table{width:100%;border-collapse:collapse;}
        th,td{padding:12px;color:#e2e8f0;border-bottom:1px solid rgba(255,255,255,0.05);}
        th{background:rgba(0,0,0,0.3);}
        .modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);justify-content:center;align-items:center;z-index:1000;}
        .modal-content{background:#0f1a24;padding:25px;border-radius:20px;width:90%;max-width:600px;max-height:80vh;overflow-y:auto;}
        .form-row{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:10px;}
        input,select,textarea{width:100%;padding:10px;background:rgba(0,0,0,0.4);border:1px solid #3d5e7e;border-radius:12px;color:white;}
        .message{padding:12px;border-radius:20px;margin-bottom:20px;}
        .success{background:rgba(46,204,113,0.2);border-left:4px solid #2ecc71;}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;}
        @media (max-width:768px){.main{margin-left:80px;padding:20px;}}
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome"><h1>Employee Management</h1></div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)) ?></div>
            <div class="user-info"><div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></div></div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    <div class="card">
        <h2>Employees</h2>
        <div class="search-bar">
            <form method="GET" style="flex:1; display:flex; gap:8px;">
                <input type="text" name="search" placeholder="Search by name, email, ID, role, phone..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn"><i class="fas fa-search"></i> Search</button>
                <?php if($search): ?><a href="employee.php" class="btn">Clear</a><?php endif; ?>
            </form>
            <button class="btn btn-primary" onclick="openAddModal()"><i class="fas fa-user-plus"></i> Add Employee</button>
        </div>
        <?php if($message): ?><div class="message success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <div style="overflow-x:auto;">
            <table>
                <thead><tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach($employees as $emp): 
                    $status = 'Active'; $class='';
                    if($emp['resign']) { $status='Fired'; $class='resigned'; }
                    elseif($emp['blocked']) { $status='Blocked'; $class='blocked'; }
                    elseif($emp['suspended']) { $status='Suspended'; $class='suspended'; }
                ?>
                    <tr class="<?= $class ?>">
                        <td><?= $emp['id'] ?></td>
                        <td><?= htmlspecialchars($emp['name']) ?></td>
                        <td><?= htmlspecialchars($emp['username']) ?></td>
                        <td><?= htmlspecialchars($emp['company_email']) ?></td>
                        <td><?= htmlspecialchars($emp['role']) ?></td>
                        <td><?= $status ?></td>
                        <td>
                            <button class="btn btn-success" onclick="openEditModal(<?= $emp['id'] ?>)"><i class="fas fa-edit"></i></button>
                            <?php if(!$emp['resign'] && !$emp['blocked'] && !$emp['suspended']): ?>
                                <button class="btn btn-warning" onclick="openBlockModal(<?= $emp['id'] ?>)"><i class="fas fa-ban"></i></button>
                                <button class="btn btn-info" onclick="openSuspendModal(<?= $emp['id'] ?>)"><i class="fas fa-hourglass-half"></i></button>
                            <?php elseif($emp['blocked']): ?>
                                <form method="POST" style="display:inline;"><input type="hidden" name="action" value="unblock"><input type="hidden" name="emp_id" value="<?= $emp['id'] ?>"><button class="btn btn-success"><i class="fas fa-check"></i></button></form>
                            <?php elseif($emp['suspended']): ?>
                                <form method="POST" style="display:inline;"><input type="hidden" name="action" value="unsuspend"><input type="hidden" name="emp_id" value="<?= $emp['id'] ?>"><button class="btn btn-success"><i class="fas fa-play"></i></button></form>
                            <?php endif; ?>
                            <?php if(!$emp['resign']): ?>
                                <a href="fired.php?id=<?= $emp['id'] ?>" class="btn btn-danger"><i class="fas fa-fire"></i></a>
                                <button class="btn btn-primary" onclick="openOfferModal(<?= $emp['id'] ?>, '<?= htmlspecialchars($emp['name']) ?>')"><i class="fas fa-envelope"></i> Offer</button>
                                <!-- NEW PROMOTION BUTTON -->
                                <a href="promotion.php?emp_id=<?= $emp['id'] ?>" class="btn btn-info"><i class="fas fa-arrow-up"></i> Promotion</a>
                            <?php endif; ?>
                            <button class="btn btn-danger" onclick="confirmDelete(<?= $emp['id'] ?>)"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Modal (same as before) -->
<div id="employeeModal" class="modal"><div class="modal-content"><span onclick="closeModal()" style="float:right;cursor:pointer;">&times;</span><h3 id="modalTitle">Add Employee</h3><form method="POST" id="employeeForm"><input type="hidden" name="action" id="formAction"><input type="hidden" name="emp_id" id="empId"><div class="form-row"><div><input type="text" name="name" id="name" placeholder="Full Name *" required></div><div><input type="text" name="username" id="username" placeholder="Username *" required></div></div><div class="form-row"><div><input type="email" name="personal_email" id="personal_email" placeholder="Personal Email *" required></div><div><input type="email" name="company_email" id="company_email" placeholder="Company Email *" required></div></div><div class="form-row"><div><input type="text" name="id_no" id="id_no" placeholder="ID Number *" required></div><div><input type="date" name="date_of_joining" id="date_of_joining" required></div></div><div class="form-row"><div><input type="text" name="image" id="image" placeholder="Profile Image URL"></div><div><select name="gender" id="gender"><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select></div><div><input type="text" name="blood_group" id="blood_group" placeholder="Blood Group"></div></div><div class="form-row"><div><input type="text" name="document_name" id="document_name" placeholder="Document Name"></div><div><input type="text" name="document_number" id="document_number" placeholder="Document Number"></div><div><label><input type="checkbox" name="document_verify_status" id="document_verify_status"> Verified</label></div></div><div class="form-row"><div><select name="role" id="role" required><option value="">Select Role</option><?php foreach($roles_list as $r): ?><option value="<?= htmlspecialchars($r['role_name']) ?>"><?= htmlspecialchars($r['role_name']) ?></option><?php endforeach; ?></select></div><div><input type="number" step="0.01" name="salary" id="salary" placeholder="Salary *" required></div></div><div class="form-row"><div><input type="text" name="mobile_number" id="mobile_number" placeholder="Mobile Number"></div><div><input type="text" name="experience" id="experience" placeholder="Experience"></div></div><div><input type="text" name="biodata_file_url" id="biodata_file_url" placeholder="Biodata URL"></div><div><input type="text" name="internal_audit_report_url" id="internal_audit_report_url" placeholder="Audit Report URL"></div><div id="addFields"><div class="form-row"><div><input type="password" name="password" id="password" placeholder="Password *"></div><div><input type="password" name="confirm_password" id="confirmPassword" placeholder="Confirm Password *"></div></div></div><div id="editFields" style="display:none;"><div class="form-row"><div><input type="password" name="new_password" id="newPassword" placeholder="New Password (optional)"></div><div><input type="password" name="confirm_new_password" id="confirmNewPassword" placeholder="Confirm New"></div></div></div><button type="submit" class="btn">Save</button><button type="button" class="btn btn-danger" onclick="closeModal()">Cancel</button></form></div></div>

<!-- Block Modal -->
<div id="blockModal" class="modal"><div class="modal-content"><h3>Block Employee</h3><form method="POST"><input type="hidden" name="action" value="block"><input type="hidden" name="emp_id" id="blockEmpId"><button type="submit" class="btn btn-danger">Yes, Block</button><button type="button" class="btn" onclick="closeBlockModal()">Cancel</button></form></div></div>

<!-- Suspend Modal -->
<div id="suspendModal" class="modal"><div class="modal-content"><h3>Suspend Employee</h3><form method="POST"><input type="hidden" name="action" value="suspend"><input type="hidden" name="emp_id" id="suspendEmpId"><input type="number" name="suspend_days" min="1" max="365" placeholder="Days" required><button type="submit" class="btn btn-warning">Suspend</button><button type="button" class="btn" onclick="closeSuspendModal()">Cancel</button></form></div></div>

<!-- Offer Letter Modal -->
<div id="offerModal" class="modal"><div class="modal-content"><h3>Send Offer Letter</h3><form method="POST" action="send_offer.php" target="_blank"><input type="hidden" name="employee_id" id="offerEmpId"><div class="form-group"><label>Employee Name</label><input type="text" id="offerEmpName" disabled style="opacity:0.7"></div><div class="form-group"><label>Offered Role *</label><select name="offered_role" required><?php foreach($roles_list as $r): ?><option value="<?= htmlspecialchars($r['role_name']) ?>"><?= htmlspecialchars($r['role_name']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Offered Salary (₹) *</label><input type="number" step="0.01" name="offered_salary" required></div><div class="form-group"><label>Joining Date *</label><input type="date" name="joining_date" value="<?= date('Y-m-d', strtotime('+15 days')) ?>" required></div><div class="form-group"><label>Additional Message (optional)</label><textarea name="message" rows="4" placeholder="Write a personal message..."></textarea></div><button type="submit" class="btn btn-primary">Send Offer Letter</button><button type="button" class="btn" onclick="closeOfferModal()">Cancel</button></form></div></div>

<form method="POST" id="deleteForm" style="display:none;"><input type="hidden" name="action" value="delete"><input type="hidden" name="emp_id" id="deleteEmpId"></form>

<script>
const modal = document.getElementById('employeeModal');
function openAddModal() { document.getElementById('modalTitle').innerText='Add Employee'; document.getElementById('formAction').value='add'; document.getElementById('empId').value=''; document.getElementById('employeeForm').reset(); document.getElementById('addFields').style.display='block'; document.getElementById('editFields').style.display='none'; modal.style.display='flex'; }
function openEditModal(id) { fetch(`get_employee.php?id=${id}`).then(r=>r.json()).then(d=>{if(d.success){ let e=d.employee; document.getElementById('name').value=e.name; document.getElementById('username').value=e.username; document.getElementById('personal_email').value=e.personal_email; document.getElementById('company_email').value=e.company_email; document.getElementById('id_no').value=e.id_no; document.getElementById('date_of_joining').value=e.date_of_joining; document.getElementById('image').value=e.image||''; document.getElementById('gender').value=e.gender||''; document.getElementById('blood_group').value=e.blood_group||''; document.getElementById('document_name').value=e.document_name||''; document.getElementById('document_number').value=e.document_number||''; document.getElementById('document_verify_status').checked=e.document_verify_status==1; let sel=document.getElementById('role'); for(let i=0;i<sel.options.length;i++) if(sel.options[i].value===e.role) sel.selectedIndex=i; document.getElementById('salary').value=e.salary; document.getElementById('mobile_number').value=e.mobile_number||''; document.getElementById('experience').value=e.experience||''; document.getElementById('biodata_file_url').value=e.biodata_file_url||''; document.getElementById('internal_audit_report_url').value=e.internal_audit_report_url||''; }}); document.getElementById('modalTitle').innerText='Edit Employee'; document.getElementById('formAction').value='edit'; document.getElementById('empId').value=id; document.getElementById('addFields').style.display='none'; document.getElementById('editFields').style.display='block'; modal.style.display='flex'; }
function closeModal() { modal.style.display='none'; }
function confirmDelete(id) { if(confirm('Permanently delete?')) { document.getElementById('deleteEmpId').value=id; document.getElementById('deleteForm').submit(); } }
function openBlockModal(id) { document.getElementById('blockEmpId').value=id; document.getElementById('blockModal').style.display='flex'; }
function closeBlockModal() { document.getElementById('blockModal').style.display='none'; }
function openSuspendModal(id) { document.getElementById('suspendEmpId').value=id; document.getElementById('suspendModal').style.display='flex'; }
function closeSuspendModal() { document.getElementById('suspendModal').style.display='none'; }
function openOfferModal(id, name) { document.getElementById('offerEmpId').value=id; document.getElementById('offerEmpName').value=name; document.getElementById('offerModal').style.display='flex'; }
function closeOfferModal() { document.getElementById('offerModal').style.display='none'; }
window.onclick = function(e) { if(e.target===modal) closeModal(); if(e.target===document.getElementById('blockModal')) closeBlockModal(); if(e.target===document.getElementById('suspendModal')) closeSuspendModal(); if(e.target===document.getElementById('offerModal')) closeOfferModal(); }
</script>
</body>
</html>
