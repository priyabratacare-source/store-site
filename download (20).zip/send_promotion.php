<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/db.php';

// Check if PHPMailer exists
$phpmailerExists = file_exists(__DIR__ . '/PHPMailer/src/PHPMailer.php');

$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';
$siteName = 'CodeBihin';

try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (PDOException $e) {}

$error = '';
$success = '';

// Get employee ID
$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: employee_list.php');
    exit;
}

// Fetch employee
$stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$stmt->execute([$id]);
$employee = $stmt->fetch();

if (!$employee) {
    header('Location: employee_list.php');
    exit;
}

// Fetch all roles
$roles = $pdo->query("SELECT role_name FROM roles ORDER BY role_name")->fetchAll(PDO::FETCH_COLUMN);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? 'promotion';
    $new_role = trim($_POST['new_role'] ?? '');
    $new_salary = floatval($_POST['new_salary'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $effective_date = $_POST['effective_date'] ?? date('Y-m-d');
    $send_email = isset($_POST['send_email']);

    // Validation
    if (empty($new_role) || $new_salary <= 0 || empty($reason)) {
        $error = 'Please fill all required fields.';
    } elseif ($new_role === $employee['role'] && $new_salary == $employee['salary']) {
        $error = 'New role/salary must be different from current.';
    } else {
        try {
            $pdo->beginTransaction();

            // Generate token
            $token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+7 days'));

            // Insert into promotion_offers
            $stmt = $pdo->prepare("
                INSERT INTO promotion_offers 
                (employee_id, token, new_role, new_salary, effective_date, reason, type, created_by, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");
            $stmt->execute([
                $employee['id'], $token, $new_role, $new_salary,
                $effective_date, $reason, $type, $admin_name, $expires_at
            ]);

            // Log in promotions_log
            $logStmt = $pdo->prepare("
                INSERT INTO promotions_log 
                (employee_id, employee_name, type, old_role, new_role, old_salary, new_salary, reason, effective_date, signature_id, signed_by, done_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $logStmt->execute([
                $employee['id'], $employee['name'], $type,
                $employee['role'], $new_role,
                $employee['salary'], $new_salary,
                $reason, $effective_date,
                uniqid('PROMO-'), $admin_name, $admin_name
            ]);

            // Send email if requested
            $emailSent = false;
            if ($send_email && $phpmailerExists) {
                try {
                    $accept_link = "https://admin.codebihin.in/accept_promotion.php?token=" . urlencode($token);
                    $letter_date = date('d F Y');

                    if ($type === 'promotion') {
                        $action_title = "PROMOTION OFFER";
                        $greeting = "We are pleased to offer you a promotion.";
                        $details = "You have been offered the position of <strong>{$new_role}</strong>.";
                        $salary_line = "Your new salary will be <strong>₹" . number_format($new_salary, 2) . "</strong> per month, effective from " . date('d F Y', strtotime($effective_date)) . ".";
                    } else {
                        $action_title = "DEMOTION NOTICE";
                        $greeting = "Following a review, your role has been revised.";
                        $details = "You are being offered the position of <strong>{$new_role}</strong>.";
                        $salary_line = "Your salary will be adjusted to <strong>₹" . number_format($new_salary, 2) . "</strong> per month, effective from " . date('d F Y', strtotime($effective_date)) . ".";
                    }

                    $emailBody = "
                    <!DOCTYPE html>
                    <html>
                    <head><meta charset='UTF-8'><title>{$action_title}</title></head>
                    <body style='font-family: Arial, sans-serif; background:#f4f4f4; padding:20px;'>
                    <div style='max-width:650px; margin:auto; background:#fff; border-radius:12px; padding:30px;'>
                        <div style='text-align:center;'>
                            <img src='https://admin.codebihin.in/logo.png' alt='{$siteName}' style='width:100px;'>
                            <h2 style='color:#2f6db3;'>{$action_title}</h2>
                        </div>
                        <p>Date: {$letter_date}</p>
                        <p>Dear <strong>{$employee['name']}</strong>,</p>
                        <p>{$greeting}</p>
                        <p>{$details}</p>
                        <p>{$salary_line}</p>
                        <p><strong>Reason:</strong> {$reason}</p>
                        <p>To accept this change, please click the button below:</p>
                        <p style='text-align:center;'>
                            <a href='{$accept_link}' style='background:#2f6db3; color:white; padding:12px 30px; text-decoration:none; border-radius:30px; font-weight:bold; display:inline-block;'>Accept Offer</a>
                        </p>
                        <p style='font-size:12px; color:#666;'><strong>⚠️ This link expires on " . date('d-m-Y H:i', strtotime($expires_at)) . ".</strong></p>
                        <hr>
                        <p style='font-size:12px; color:#999;'>If you did not expect this, please ignore this email or contact HR.</p>
                        <p>Thank You,<br><strong>Team {$siteName}</strong></p>
                    </div>
                    </body>
                    </html>";

                    require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
                    require_once __DIR__ . '/PHPMailer/src/SMTP.php';
                    require_once __DIR__ . '/PHPMailer/src/Exception.php';

                    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->isSMTP();
                    $mail->Host = 'smtp.zoho.in';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'info@codebihin.in';
                    $mail->Password = '5PJxDcP4K8Tc';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;
                    $mail->setFrom('info@codebihin.in', $siteName);
                    $mail->addAddress($employee['personal_email']);
                    if (!empty($employee['company_email'])) {
                        $mail->addAddress($employee['company_email']);
                    }
                    $mail->isHTML(true);
                    $mail->Subject = ucfirst($type) . " Offer – " . $employee['name'];
                    $mail->Body = $emailBody;
                    $mail->AltBody = strip_tags($emailBody);
                    $mail->send();
                    $emailSent = true;
                } catch (Exception $e) {
                    error_log("Email error: " . $e->getMessage());
                }
            }

            $pdo->commit();

            if ($send_email && $emailSent) {
                $success = "Offer sent successfully and email delivered to {$employee['name']}.";
            } elseif ($send_email && !$emailSent) {
                $success = "Offer created but email failed to send. Please notify employee manually.";
            } else {
                $success = "Offer created successfully for {$employee['name']}.";
            }

            header("Location: promotions.php?msg=" . urlencode($success));
            exit;

        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Offer · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        body {
            background: #0f172a;
            min-height: 100vh;
            display: flex;
        }

        .main {
            flex: 1;
            margin-left: 280px;
            padding: 28px 36px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        .card {
            background: rgba(20, 35, 55, 0.9);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 32px;
            max-width: 680px;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: 20px;
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .back-link {
            color: #94a3b8;
            text-decoration: none;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 16px;
            transition: 0.2s;
        }

        .back-link:hover {
            color: #f9b233;
        }

        h2 {
            color: #f9b233;
            border-left: 4px solid #f9b233;
            padding-left: 18px;
            margin-bottom: 20px;
            font-size: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-panel {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 16px;
            padding: 18px;
            margin-bottom: 24px;
            color: #cbd5e6;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }

        .info-panel .row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
        }

        .info-panel .row .label {
            color: #94a3b8;
        }

        .info-panel .row .value {
            color: #e2e8f0;
            font-weight: 500;
        }

        label {
            display: block;
            color: #e2e8f0;
            margin: 16px 0 6px;
            font-size: 13px;
            font-weight: 500;
        }

        input, select, textarea {
            width: 100%;
            padding: 11px 14px;
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid #3d5e7e;
            border-radius: 12px;
            color: white;
            font-size: 14px;
            outline: none;
            transition: 0.2s;
        }

        input:focus, select:focus, textarea:focus {
            border-color: #f9b233;
            box-shadow: 0 0 0 2px rgba(249, 178, 51, 0.1);
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 16px;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #f9b233;
            cursor: pointer;
        }

        .checkbox-group label {
            margin: 0;
            color: #cbd5e6;
            cursor: pointer;
            font-size: 13px;
        }

        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 30px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
            text-decoration: none;
        }

        .btn-primary {
            background: #f9b233;
            color: #0f172a;
        }

        .btn-primary:hover {
            background: #e0a00f;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #475569;
            color: white;
        }

        .btn-secondary:hover {
            background: #334155;
        }

        .message {
            padding: 14px 18px;
            border-radius: 16px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .error {
            background: rgba(231, 76, 60, 0.15);
            border-left: 4px solid #e74c3c;
            color: #ffcfcf;
        }

        .warning-box {
            background: rgba(243, 156, 18, 0.1);
            border: 1px solid rgba(243, 156, 18, 0.2);
            border-radius: 12px;
            padding: 12px 16px;
            margin-top: 16px;
            color: #f39c12;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        @media (max-width: 768px) {
            .main {
                margin-left: 75px;
                padding: 16px;
            }
            .card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/menu.php'; ?>

    <div class="main">
        <div class="card">
            <a href="promotions.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Promotions
            </a>

            <h2><i class="fas fa-chart-line"></i> Send Promotion / Demotion Offer</h2>

            <?php if ($error): ?>
                <div class="message error"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <!-- Employee Info -->
            <div class="info-panel">
                <div class="row">
                    <span class="label"><i class="fas fa-user"></i> Employee</span>
                    <span class="value"><?= htmlspecialchars($employee['name']) ?></span>
                </div>
                <div class="row">
                    <span class="label"><i class="fas fa-id-badge"></i> ID No.</span>
                    <span class="value"><?= htmlspecialchars($employee['id_no'] ?? 'N/A') ?></span>
                </div>
                <div class="row">
                    <span class="label"><i class="fas fa-briefcase"></i> Current Role</span>
                    <span class="value" style="color:#f9b233;"><?= htmlspecialchars($employee['role']) ?></span>
                </div>
                <div class="row">
                    <span class="label"><i class="fas fa-money-bill-wave"></i> Current Salary</span>
                    <span class="value">₹ <?= number_format($employee['salary'], 2) ?></span>
                </div>
            </div>

            <form method="POST">
                <!-- Action Type -->
                <label><i class="fas fa-exchange-alt"></i> Action Type *</label>
                <select name="type" required>
                    <option value="promotion">🎉 Promotion</option>
                    <option value="demotion">⚠️ Demotion</option>
                </select>

                <!-- New Role -->
                <label><i class="fas fa-briefcase"></i> New Role *</label>
                <select name="new_role" required>
                    <option value="">-- Select New Role --</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?= htmlspecialchars($role) ?>">
                            <?= htmlspecialchars($role) ?>
                            <?= $role == $employee['role'] ? '(Current)' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- New Salary -->
                <label><i class="fas fa-money-bill-wave"></i> New Salary (₹) *</label>
                <input type="number" step="0.01" name="new_salary" value="<?= htmlspecialchars($employee['salary']) ?>" placeholder="Enter new salary amount" required>

                <!-- Effective Date -->
                <label><i class="fas fa-calendar-alt"></i> Effective Date *</label>
                <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required>

                <!-- Reason -->
                <label><i class="fas fa-pen"></i> Reason *</label>
                <textarea name="reason" rows="3" placeholder="Provide reason for this promotion/demotion..." required></textarea>

                <!-- Send Email Checkbox -->
                <div class="checkbox-group">
                    <input type="checkbox" name="send_email" id="send_email" value="1" checked>
                    <label for="send_email"><i class="fas fa-envelope"></i> Send offer letter via email to employee</label>
                </div>

                <?php if (!$phpmailerExists): ?>
                    <div class="warning-box">
                        <i class="fas fa-exclamation-triangle"></i>
                        PHPMailer not found. Email will not be sent. Offer will still be created.
                    </div>
                <?php endif; ?>

                <!-- Buttons -->
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Send Offer
                    </button>
                    <a href="promotions.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>