<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$conn = mysqli_connect("sql204.infinityfree.com","your_db_user","your_db_pass","if0_41037048_admin");

$email = $_POST['email'];

// check email
$result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

if(mysqli_num_rows($result) > 0){

    $token = bin2hex(random_bytes(50));
    $expiry = date("Y-m-d H:i:s", strtotime("+10 minutes"));

    // update YOUR columns
    mysqli_query($conn, "UPDATE users SET reset_token='$token', reset_expires='$expiry' WHERE email='$email'");

    $reset_link = "https://codebihin.in/reset_password.php?token=$token";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.zoho.in';
        $mail->SMTPAuth = true;
        $mail->Username = 'info@codebihin.in';
        $mail->Password = 'YOUR_NEW_APP_PASSWORD';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('info@codebihin.in', 'CodeBihin');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Password Reset';
        $mail->Body = "
            <h3>Password Reset</h3>
            <p>Click below to reset your password:</p>
            <a href='$reset_link'>Reset Password</a>
            <p>Valid for 10 minutes</p>
        ";

        $mail->send();
        echo "Reset link sent!";
    } catch (Exception $e) {
        echo "Error: " . $mail->ErrorInfo;
    }

}else{
    echo "Email not found!";
}
?>