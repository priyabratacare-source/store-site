<?php
session_start();
if (!isset($_SESSION['user_id'])) { http_response_code(403); exit; }
require_once 'db.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { echo json_encode(['success'=>false]); exit; }
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
    $stmt->execute([$id]);
    $emp = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($emp) {
        unset($emp['password']); // remove sensitive
        echo json_encode(['success'=>true, 'employee'=>$emp]);
    } else {
        echo json_encode(['success'=>false]);
    }
} catch (PDOException $e) {
    echo json_encode(['success'=>false]);
}
?>