<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
$pdo = getDBConnection();

$logs = $pdo->query("
    SELECT a.*, e.name as employee_name, e.company_email 
    FROM audit_logs a
    JOIN Employee e ON a.employee_id = e.id
    ORDER BY a.created_at DESC
    LIMIT 200
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Audit Logs</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI',system-ui;
}

body{
    background:#0f172a;
    display:flex;
}

/* ✅ FIX MAIN ISSUE */
.main{
    margin-left:280px;
    width:100%;
    padding:30px;
}

/* HEADER */
.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.welcome h1{color:white;}
.welcome p{color:#94a3b8;}

/* USER */
.user-menu{
    display:flex;
    align-items:center;
    gap:15px;
    background:rgba(255,255,255,0.05);
    padding:8px 18px;
    border-radius:40px;
}

.user-avatar{
    width:40px;height:40px;
    border-radius:50%;
    background:#2f6db3;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-weight:bold;
}

/* CARD */
.card{
    background:#142337;
    padding:20px;
    border-radius:20px;
    overflow:hidden;
}

/* TABLE */
.table-wrap{
    overflow:auto;
    max-height:600px;
}

table{
    width:100%;
    border-collapse:collapse;
    min-width:900px;
}

th,td{
    padding:12px;
    color:#e2e8f0;
    font-size:14px;
}

th{
    position:sticky;
    top:0;
    background:#0f172a;
    z-index:2;
    text-transform:uppercase;
    font-size:12px;
}

tr:nth-child(even){
    background:rgba(255,255,255,0.03);
}

tr:hover{
    background:rgba(255,255,255,0.06);
}

/* TAG STYLE */
.badge{
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
}

.badge-login{background:#27ae60;}
.badge-delete{background:#e74c3c;}
.badge-update{background:#f39c12;}

/* MOBILE */
@media(max-width:768px){
    .main{
        margin-left:80px;
        padding:20px;
    }

    .top-bar{
        flex-direction:column;
        align-items:flex-start;
        gap:10px;
    }
}
</style>
</head>

<body>

<?php include 'menu.php'; ?>

<div class="main">

<div class="top-bar">
    <div class="welcome">
        <h1>Audit Logs</h1>
        <p>Track system activity</p>
    </div>

    <div class="user-menu">
        <div class="user-avatar">
            <?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)); ?>
        </div>
        <div>
            <div style="color:white;font-weight:600;">
                <?= htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
            </div>
            <div style="font-size:12px;color:#94a3b8;">
                <?= htmlspecialchars($_SESSION['email'] ?? ''); ?>
            </div>
        </div>
        <a href="logout.php" style="color:#ffaaa5;text-decoration:none;">
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </div>
</div>

<div class="card">
<h2 style="color:white;margin-bottom:15px;">System Logs</h2>

<div class="table-wrap">
<table>
<thead>
<tr>
<th>ID</th>
<th>Employee</th>
<th>Email</th>
<th>Action</th>
<th>Page</th>
<th>IP</th>
<th>Details</th>
<th>Time</th>
</tr>
</thead>

<tbody>
<?php foreach ($logs as $log): ?>
<tr>
<td><?= $log['id'] ?></td>
<td><?= htmlspecialchars($log['employee_name']) ?></td>
<td><?= htmlspecialchars($log['company_email']) ?></td>

<td>
<span class="badge 
<?=
    str_contains($log['action'],'login') ? 'badge-login' :
    (str_contains($log['action'],'delete') ? 'badge-delete' : 'badge-update')
?>">
<?= htmlspecialchars($log['action']) ?>
</span>
</td>

<td><?= htmlspecialchars($log['page']) ?></td>
<td><?= htmlspecialchars($log['ip_address']) ?></td>
<td><?= htmlspecialchars($log['details']) ?></td>
<td><?= $log['created_at'] ?></td>
</tr>
<?php endforeach; ?>
</tbody>

</table>
</div>

</div>
</div>

</body>
</html>