<?php
/**
 * db.php - Database connection for CodeBihin (InfinityFree)
 * 
 * Host: sql204.infinityfree.com
 * Database: if0_41037048_admin
 * Username: if0_41037048
 * Password: TWPT4BP1WW
 */

// Database credentials
define('DB_HOST', 'sql204.infinityfree.com');
define('DB_NAME', 'if0_41037048_admin');
define('DB_USER', 'if0_41037048');
define('DB_PASS', 'TWPT4BP1WW');

/**
 * Returns a PDO database connection instance.
 * 
 * @return PDO
 * @throws PDOException on connection error
 */
function getDBConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ];
        
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log error (optional) then rethrow or handle gracefully
            error_log("Database connection failed: " . $e->getMessage());
            throw new PDOException("Unable to connect to database. Please try again later.");
        }
    }
    
    return $pdo;
}

// Optional: Test connection immediately (uncomment only for debugging)
// try {
//     $db = getDBConnection();
//     echo "Connected successfully";
// } catch (Exception $e) {
//     echo "Connection error: " . $e->getMessage();
// }
?>