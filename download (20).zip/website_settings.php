<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

$id = (int)($_GET['id'] ?? $_POST['website_id'] ?? 0);
if (!$id) { header('Location: websites.php'); exit; }

$siteName = 'CodeBihin';
try {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (Exception $e) {}

$message = '';
$error = '';

// Get website info
$website = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM managed_websites WHERE id = ?");
    $stmt->execute([$id]);
    $website = $stmt->fetch();
    if (!$website) { header('Location: websites.php'); exit; }
} catch (PDOException $e) { $error = "Website not found."; }

// Helper to get a setting (global or website-specific)
function getWebsiteSetting($pdo, $websiteId, $key, $default = '') {
    $stmt = $pdo->prepare("SELECT setting_value FROM website_settings WHERE website_id = ? AND setting_key = ?");
    $stmt->execute([$websiteId, $key]);
    $val = $stmt->fetchColumn();
    if ($val !== false) return $val;
    // Fallback to global ext_ setting
    $stmt2 = $pdo->prepare("SELECT option_value FROM settings WHERE option_name = ?");
    $stmt2->execute(["ext_$key"]);
    return $stmt2->fetchColumn() ?: $default;
}

function saveWebsiteSetting($pdo, $websiteId, $key, $value) {
    $stmt = $pdo->prepare("INSERT INTO website_settings (website_id, setting_key, setting_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->execute([$websiteId, $key, $value, $value]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        saveWebsiteSetting($pdo, $id, 'maintenance', isset($_POST['maintenance']) ? '1' : '0');
        saveWebsiteSetting($pdo, $id, 'maintenance_message', trim($_POST['maintenance_message']));
        saveWebsiteSetting($pdo, $id, 'security_level', $_POST['security_level']);
        saveWebsiteSetting($pdo, $id, 'rate_limit', (int)$_POST['rate_limit']);
        saveWebsiteSetting($pdo, $id, 'allowed_ips', trim($_POST['allowed_ips']));
        saveWebsiteSetting($pdo, $id, 'allow_registration', isset($_POST['allow_registration']) ? '1' : '0');
        saveWebsiteSetting($pdo, $id, 'require_email_verification', isset($_POST['require_email_verification']) ? '1' : '0');
        saveWebsiteSetting($pdo, $id, 'require_2fa', isset($_POST['require_2fa']) ? '1' : '0');
        saveWebsiteSetting($pdo, $id, 'max_login_attempts', (int)$_POST['max_login_attempts']);
        saveWebsiteSetting($pdo, $id, 'session_timeout', (int)$_POST['session_timeout']);
        $message = "Settings saved for " . htmlspecialchars($website['website_name']);
    } catch (Exception $e) { $error = "Save failed: " . $e->getMessage(); }
}

// Load current values (prefer website-specific overrides)
$maintenance = getWebsiteSetting($pdo, $id, 'maintenance', '0');
$maintenance_message = getWebsiteSetting($pdo, $id, 'maintenance_message', 'Site under maintenance.');
$security_level = getWebsiteSetting($pdo, $id, 'security_level', 'medium');
$rate_limit = getWebsiteSetting($pdo, $id, 'rate_limit', '60');
$allowed_ips = getWebsiteSetting($pdo, $id, 'allowed_ips', '');
$allow_registration = getWebsiteSetting($pdo, $id, 'allow_registration', '1');
$require_email_verification = getWebsiteSetting($pdo, $id, 'require_email_verification', '1');
$require_2fa = getWebsiteSetting($pdo, $id, 'require_2fa', '0');
$max_login_attempts = getWebsiteSetting($pdo, $id, 'max_login_attempts', '5');
$session_timeout = getWebsiteSetting($pdo, $id, 'session_timeout', '7200');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($siteName) ?> · Website Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
        body{background:#0f172a;display:flex}
        .sidebar{width:280px;background:rgba(12,25,38,0.97);backdrop-filter:blur(8px);color:#fff;border-right:1px solid rgba(255,255,255,0.08)}
        .sidebar-header{padding:28px 24px;border-bottom:1px solid rgba(255,255,255,0.08)}
        .logo{display:flex;align-items:center;gap:12px}
        .logo-img{height:42px}
        .logo span{font-size:24px;font-weight:800;background:linear-gradient(125deg,#FFF,#c7e2ff);-webkit-background-clip:text;background-clip:text;color:transparent}
        .nav{flex:1;display:flex;flex-direction:column;gap:8px;padding:0 20px 20px}
        .nav-item{display:flex;align-items:center;gap:14px;padding:12px 16px;border-radius:16px;color:#cbd5e6;text-decoration:none;font-weight:500}
        .nav-item i{width:24px}
        .nav-item:hover,.nav-item.active{background:rgba(249,178,51,0.12);color:#f9b233}
        .main{flex:1;padding:28px 36px;overflow-y:auto}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px}
        .welcome h1{font-size:28px;color:#fff}
        .user-menu{display:flex;align-items:center;gap:20px;background:rgba(255,255,255,0.05);padding:8px 20px;border-radius:48px}
        .user-avatar{background:#2f6db3;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold}
        .logout-btn{background:rgba(231,76,60,0.2);padding:8px 16px;border-radius:40px;color:#ffaaa5;text-decoration:none}
        .form-container{background:rgba(20,35,55,0.7);backdrop-filter:blur(8px);border-radius:28px;padding:32px;margin-top:20px}
        .form-group{margin-bottom:24px}
        label{display:block;color:#cbd5e6;margin-bottom:8px}
        input,textarea,select{width:100%;padding:12px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:16px;color:white}
        .checkbox-group{display:flex;align-items:center;gap:12px;margin-top:8px}
        .btn-primary{background:#f9b233;border:none;padding:12px 28px;border-radius:40px;color:#0f172a;font-weight:bold;cursor:pointer}
        .message{padding:12px;border-radius:20px;margin-bottom:20px}
        .success{background:rgba(46,204,113,0.2);border-left:4px solid #2ecc71}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c}
        hr{margin:20px 0}
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome"><h1><?= htmlspecialchars($website['website_name']) ?> · Settings</h1><p>Override global settings for this website</p></div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'],0,1)) ?></div>
            <div class="user-info"><div class="name"><?= htmlspecialchars($_SESSION['username']) ?></div></div>
            <a href="logout.php" class="logout-btn">Exit</a>
        </div>
    </div>
    <?php if($message): ?><div class="message success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="form-container">
        <form method="POST">
            <input type="hidden" name="website_id" value="<?= $id ?>">
            <h3>Maintenance</h3>
            <div class="checkbox-group"><input type="checkbox" name="maintenance" value="1" <?= $maintenance == '1' ? 'checked' : '' ?>><label>Enable Maintenance Mode</label></div>
            <div class="form-group"><label>Maintenance Message</label><textarea name="maintenance_message"><?= htmlspecialchars($maintenance_message) ?></textarea></div>
            
            <hr>
            <h3>Security</h3>
            <div class="form-group"><label>Security Level</label><select name="security_level"><option value="low" <?= $security_level=='low'?'selected':'' ?>>Low</option><option value="medium" <?= $security_level=='medium'?'selected':'' ?>>Medium</option><option value="high" <?= $security_level=='high'?'selected':'' ?>>High</option></select></div>
            <div class="form-group"><label>Rate Limit (requests/minute)</label><input type="number" name="rate_limit" value="<?= $rate_limit ?>"></div>
            <div class="form-group"><label>Allowed IPs (comma separated)</label><input type="text" name="allowed_ips" value="<?= htmlspecialchars($allowed_ips) ?>"></div>
            
            <hr>
            <h3>Login Controls</h3>
            <div class="checkbox-group"><input type="checkbox" name="allow_registration" value="1" <?= $allow_registration=='1'?'checked':'' ?>><label>Allow Registration</label></div>
            <div class="checkbox-group"><input type="checkbox" name="require_email_verification" value="1" <?= $require_email_verification=='1'?'checked':'' ?>><label>Require Email Verification</label></div>
            <div class="checkbox-group"><input type="checkbox" name="require_2fa" value="1" <?= $require_2fa=='1'?'checked':'' ?>><label>Require 2FA</label></div>
            <div class="form-group"><label>Max Login Attempts</label><input type="number" name="max_login_attempts" value="<?= $max_login_attempts ?>"></div>
            <div class="form-group"><label>Session Timeout (seconds)</label><input type="number" name="session_timeout" value="<?= $session_timeout ?>"></div>
            
            <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Save Website Settings</button>
            <a href="websites.php" class="btn-primary" style="background:#6c757d;">Back</a>
        </form>
    </div>
</div>
</body>
</html>