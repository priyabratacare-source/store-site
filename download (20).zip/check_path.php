<?php
echo "<h3>Server Path Info</h3>";

echo "Current File Path:<br>";
echo __FILE__ . "<br><br>";

echo "Directory Path:<br>";
echo __DIR__ . "<br><br>";

echo "PHP Working Directory:<br>";
echo getcwd() . "<br><br>";

echo "<h3>Check PHPMailer Files</h3>";

$files = [
    'PHPMailer/src/PHPMailer.php',
    'PHPMailer/src/SMTP.php',
    'PHPMailer/src/Exception.php'
];

foreach ($files as $file) {
    if (file_exists(__DIR__ . '/' . $file)) {
        echo "✅ Found: $file<br>";
    } else {
        echo "❌ Missing: $file<br>";
    }
}
?>