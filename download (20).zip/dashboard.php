<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
require_once 'db.php';

$username = $_SESSION['username'] ?? 'Admin';
$email = $_SESSION['email'] ?? '';
$totalUsers = $activeSessions = 0;
try {
    $pdo = getDBConnection();
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $activeSessions = $pdo->query("SELECT COUNT(*) FROM users WHERE remember_token IS NOT NULL AND token_expires > NOW()")->fetchColumn();
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard · CodeBihin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
        body{background:#0f172a;display:flex;}
        .main{margin-left:280px;width:100%;padding:30px;animation:fadeIn 0.4s;}
        @keyframes fadeIn{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px;flex-wrap:wrap;gap:16px;}
        .welcome h1{color:white;font-size:26px;}
        .welcome p{color:#94a3b8;}
        .user-menu{display:flex;align-items:center;gap:15px;background:rgba(255,255,255,0.05);padding:8px 18px;border-radius:40px;}
        .user-avatar{width:40px;height:40px;background:#2f6db3;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;}
        .user-info .name{color:white;font-weight:600;}
        .user-info .email{font-size:12px;color:#94a3b8;}
        .logout-btn{background:rgba(231,76,60,0.2);padding:8px 14px;border-radius:30px;color:#ffaaa5;text-decoration:none;}
        .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;}
        .stat-card{background:rgba(20,35,55,0.7);border-radius:20px;padding:20px;transition:0.3s;}
        .stat-card:hover{transform:translateY(-5px);}
        .stat-icon{font-size:26px;color:#f9b233;margin-bottom:10px;}
        .stat-value{font-size:30px;color:white;font-weight:bold;}
        .stat-label{color:#94a3b8;}
        .section-title{color:white;margin-top:40px;margin-bottom:15px;}
        .activity{background:rgba(20,35,55,0.6);padding:20px;border-radius:15px;}
        .activity-item{padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);color:#cbd5e1;}
        @media(max-width:768px){.main{margin-left:80px;padding:20px;}}
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome"><h1>Welcome, <?= htmlspecialchars($username) ?></h1><p>System overview</p></div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($username,0,1)) ?></div>
            <div class="user-info"><div class="name"><?= htmlspecialchars($username) ?></div><div class="email"><?= htmlspecialchars($email) ?></div></div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-icon"><i class="fas fa-users"></i></div><div class="stat-value"><?= $totalUsers ?></div><div class="stat-label">Total Users</div></div>
        <div class="stat-card"><div class="stat-icon"><i class="fas fa-signal"></i></div><div class="stat-value"><?= $activeSessions ?></div><div class="stat-label">Active Sessions</div></div>
        <div class="stat-card"><div class="stat-icon"><i class="fas fa-calendar"></i></div><div class="stat-value"><?= date('d M Y') ?></div><div class="stat-label">Today</div></div>
    </div>
    <h3 class="section-title">Recent Activity</h3>
    <div class="activity"><div class="activity-item">✔ Login successful (<?= date('H:i') ?>)</div><div class="activity-item">✔ Backup completed</div><div class="activity-item">✔ System running</div></div>
</div>
</body>
</html>