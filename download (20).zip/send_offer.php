<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
require_once 'db.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';
$siteName = 'CodeBihin';
try { $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name='site_name'"); $siteName = $stmt->fetchColumn() ?: 'CodeBihin'; } catch(Exception $e) {}

$employee_id = (int)$_POST['employee_id'];
$offered_role = trim($_POST['offered_role']);
$offered_salary = floatval($_POST['offered_salary']);
$joining_date = $_POST['joining_date'];
$message_text = trim($_POST['message'] ?? '');

$emp = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$emp->execute([$employee_id]);
$employee = $emp->fetch();
if(!$employee) die('Employee not found.');

$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', strtotime('+7 days'));
$signature_id = date('dmy') . substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'),0,3);
$stmt = $pdo->prepare("INSERT INTO job_offers (employee_id, token, offered_role, offered_salary, joining_date, message, created_by, signature_id, created_at, expires_at) VALUES (?,?,?,?,?,?,?,?,NOW(),?)");
$stmt->execute([$employee_id, $token, $offered_role, $offered_salary, $joining_date, $message_text, $admin_name, $signature_id, $expires]);

$accept_link = "https://admin.codebihin.in/accept_offer.php?token=" . urlencode($token);
$letter_date = date('d F Y');

$emailBody = "
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'><title>Offer Letter</title></head>
<body style='font-family:Arial; background:#f4f4f4; padding:20px;'>
<div style='max-width:650px; margin:auto; background:#fff; border-radius:12px; padding:30px;'>
    <div style='text-align:center;'><img src='https://admin.codebihin.in/logo.png' width='100'><h2>Offer of Employment</h2></div>
    <p>Date: $letter_date</p>
    <p>Dear <strong>{$employee['name']}</strong>,</p>
    <p>We are pleased to offer you the position of <strong>$offered_role</strong> at $siteName.</p>
    <p><strong>Salary:</strong> ₹ " . number_format($offered_salary,2) . " per month.<br>
    <strong>Joining Date:</strong> " . date('d-m-Y', strtotime($joining_date)) . "</p>
    <p>$message_text</p>
    <p>To accept this offer, please click the link below and complete the joining process:</p>
    <p style='text-align:center;'><a href='$accept_link' style='background:#2f6db3; color:white; padding:10px 20px; text-decoration:none; border-radius:30px;'>Accept Offer</a></p>
    <p><strong>This link expires on " . date('d-m-Y H:i', strtotime($expires)) . ".</strong></p>
    <hr>
    <p>Digitally Signed By: <strong>$admin_name</strong><br>Signature ID: $signature_id</p>
    <p>© $siteName – All Rights Reserved</p>
</div>
</body>
</html>";

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->isSMTP();
$mail->Host = 'smtp.zoho.in';
$mail->SMTPAuth = true;
$mail->Username = 'info@codebihin.in';
$mail->Password = '5PJxDcP4K8Tc';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->setFrom('info@codebihin.in', $siteName);
$mail->addAddress($employee['personal_email']);
if(!empty($employee['company_email'])) $mail->addAddress($employee['company_email']);
$mail->addCC('admin@codebihin.in');
$mail->isHTML(true);
$mail->Subject = "Offer Letter – $offered_role at $siteName";
$mail->Body = $emailBody;
$mail->send();

header("Location: employee.php?msg=Offer+letter+sent+to+{$employee['name']}");
exit;