<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$pdo = getDBConnection();
$admin_name = $_SESSION['username'] ?? 'Admin';

$siteName = 'CodeBihin';
try {
    $stmt = $pdo->query("SELECT option_value FROM settings WHERE option_name = 'site_name'");
    $siteName = $stmt->fetchColumn() ?: 'CodeBihin';
} catch (PDOException $e) {
    $siteName = 'CodeBihin';
}

$error = '';
$success = '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) die('No employee selected.');

$stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$stmt->execute([$id]);
$employee = $stmt->fetch();
if (!$employee) die('Employee not found.');

$roles = $pdo->query("SELECT role_name FROM roles ORDER BY role_name")->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];
    $new_role = trim($_POST['new_role']);
    $new_salary = floatval($_POST['new_salary']);
    $reason = trim($_POST['reason']);
    $effective_date = $_POST['effective_date'] ?: date('Y-m-d');

    if (empty($new_role) || $new_salary <= 0 || empty($reason)) {
        $error = 'Please fill all required fields.';
    } elseif ($new_role === $employee['role']) {
        $error = 'New role must be different from current role.';
    } else {
        try {
            // Generate unique token
            $token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+7 days')); // link valid for 7 days

            // Insert offer into promotion_offers table
            $stmt = $pdo->prepare("
                INSERT INTO promotion_offers 
                (employee_id, token, new_role, new_salary, effective_date, reason, type, created_by, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");
            $stmt->execute([$employee['id'], $token, $new_role, $new_salary, $effective_date, $reason, $type, $admin_name, $expires_at]);

            $accept_link = "https://admin.codebihin.in/accept_promotion.php?token=" . urlencode($token);

            // Build email
            $letter_date = date('d F Y');
            if ($type === 'promotion') {
                $action_title = "PROMOTION OFFER";
                $greeting = "We are pleased to offer you a promotion.";
                $details = "You have been offered the position of <strong>{$new_role}</strong>.";
                $salary_line = "Your new salary will be <strong>₹" . number_format($new_salary, 2) . "</strong> per month, effective from {$effective_date}.";
            } else {
                $action_title = "DEMOTION NOTICE";
                $greeting = "Following a review, your role has been revised.";
                $details = "You are being offered the position of <strong>{$new_role}</strong>.";
                $salary_line = "Your salary will be adjusted to <strong>₹" . number_format($new_salary, 2) . "</strong> per month, effective from {$effective_date}.";
            }

            $emailBody = "
            <!DOCTYPE html>
            <html>
            <head><meta charset='UTF-8'><title>{$action_title}</title></head>
            <body style='font-family: Arial, sans-serif; background:#f4f4f4; padding:20px;'>
            <div style='max-width:650px; margin:auto; background:#fff; border-radius:12px; padding:30px;'>
                <div style='text-align:center;'>
                    <img src='https://admin.codebihin.in/logo.png' alt='{$siteName}' style='width:100px;'>
                    <h2>{$action_title}</h2>
                </div>
                <p>Date: {$letter_date}</p>
                <p>Dear <strong>{$employee['name']}</strong>,</p>
                <p>{$greeting}</p>
                <p>{$details}</p>
                <p>{$salary_line}</p>
                <p><strong>Reason:</strong> {$reason}</p>
                <p>To accept this change, please click the link below and verify your identity:</p>
                <p style='text-align:center;'>
                    <a href='{$accept_link}' style='background:#2f6db3; color:white; padding:10px 20px; text-decoration:none; border-radius:30px;'>Accept Offer</a>
                </p>
                <p><strong>This link expires on " . date('d-m-Y H:i', strtotime($expires_at)) . ".</strong></p>
                <hr>
                <p>If you did not expect this, please ignore this email.</p>
                <p>Thank You,<br><strong>Team {$siteName}</strong></p>
            </div>
            </body>
            </html>";

            $mail = new PHPMailer(true);
            $mail->CharSet = 'UTF-8';
            $mail->isSMTP();
            $mail->Host = 'smtp.zoho.in';
            $mail->SMTPAuth = true;
            $mail->Username = 'info@codebihin.in';
            $mail->Password = '5PJxDcP4K8Tc';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('info@codebihin.in', $siteName);
            $mail->addAddress($employee['personal_email']);
            $mail->addAddress($employee['company_email']);
            $mail->addCC('admin@codebihin.in');
            $mail->addCC('owner@codebihin.in');
            $mail->isHTML(true);
            $mail->Subject = ucfirst($type) . " Offer – " . $employee['name'];
            $mail->Body = $emailBody;
            $mail->AltBody = strip_tags($emailBody);
            $mail->send();

            $success = "Offer sent to {$employee['name']}. They must accept it via the link.";
            header("Location: employee.php?msg=" . urlencode($success));
            exit;

        } catch (Exception $e) {
            $error = "Email sending failed: " . $mail->ErrorInfo;
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Promotion/Demotion · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}
        body{background:#0f172a;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:40px 20px;}
        .card{background:rgba(20,35,55,0.9);border-radius:32px;padding:32px;max-width:650px;width:100%;border:1px solid rgba(255,255,255,0.1);}
        h2{color:#f9b233;border-left:4px solid #f9b233;padding-left:18px;margin-bottom:20px;}
        .info-panel{background:rgba(0,0,0,0.3);border-radius:20px;padding:16px;margin-bottom:25px;color:#cbd5e6;}
        label{display:block;color:#e2e8f0;margin:12px 0 6px;}
        input,select,textarea{width:100%;padding:12px;background:rgba(0,0,0,0.4);border:1px solid #3d5e7e;border-radius:16px;color:white;}
        .btn-group{display:flex;gap:14px;margin-top:25px;}
        .btn{padding:12px 24px;border:none;border-radius:40px;font-weight:600;cursor:pointer;}
        .btn-primary{background:#f9b233;color:#0f172a;}
        .btn-danger{background:#e74c3c;color:white;}
        .message{padding:14px;border-radius:20px;margin-bottom:20px;}
        .success{background:rgba(46,204,113,0.2);border-left:4px solid #2ecc71;color:#c8f0e1;}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;color:#ffcfcf;}
    </style>
</head>
<body>
<div class="card">
    <h2><i class="fas fa-chart-line"></i> Send Offer</h2>
    <?php if($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="info-panel">
        <p><strong>Employee:</strong> <?= htmlspecialchars($employee['name']) ?></p>
        <p><strong>Current Role:</strong> <?= htmlspecialchars($employee['role']) ?></p>
        <p><strong>Current Salary:</strong> ₹ <?= number_format($employee['salary'], 2) ?></p>
    </div>
    <form method="POST">
        <label>Action Type</label>
        <select name="type" required>
            <option value="promotion">🎉 Promotion</option>
            <option value="demotion">⚠️ Demotion</option>
        </select>
        <label>New Role</label>
        <select name="new_role" required>
            <option value="">-- Select --</option>
            <?php foreach ($roles as $role): ?>
                <option value="<?= htmlspecialchars($role) ?>" <?= $role == $employee['role'] ? 'disabled' : '' ?>><?= htmlspecialchars($role) ?></option>
            <?php endforeach; ?>
        </select>
        <label>New Salary (₹)</label>
        <input type="number" step="0.01" name="new_salary" value="<?= $employee['salary'] ?>" required>
        <label>Effective Date</label>
        <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required>
        <label>Reason</label>
        <textarea name="reason" rows="4" required></textarea>
        <div class="btn-group">
            <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Offer</button>
            <a href="employee.php" class="btn btn-danger">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>