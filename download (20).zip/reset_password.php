<?php
/**
 * reset_password.php
 *
 * Validates the reset token (with embedded expiry),
 * displays a modern form to set a new password.
 * Tokens expire after 3 minutes.
 */

require __DIR__ . '/db.php';

// ---------------------------------------------------------------------
// 1. Token validation (including expiry)
// ---------------------------------------------------------------------
if (!isset($_GET['token'])) {
    die("Invalid link");
}

$token = $_GET['token'];

// --- Basic token length check (48 hex from random + 8 hex expiry = 56 min) ---
if (strlen($token) < 56) {
    die("❌ Invalid or expired token");
}

// --- Extract the expiry timestamp embedded in the last 8 hex characters ---
$expiryHex   = substr($token, -8);          // last 8 chars
$expiryTime  = hexdec($expiryHex);          // convert to integer

// If the timestamp could not be decoded, or it's in the past → expired
if ($expiryTime == 0 || time() > $expiryTime) {
    die("⌛ This reset link has expired. Please request a new one.");
}

// --- Look up the token in the database ---
$pdo  = getDBConnection();
$stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token = ?");
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    die("❌ Invalid or expired token");
}

// ---------------------------------------------------------------------
// 2. Everything is valid – show the reset form
// ---------------------------------------------------------------------
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | CodeBihin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .reset-card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .reset-card img {
            width: 100px;
            margin-bottom: 1rem;
        }
        .reset-card h2 {
            color: #333;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        .form-group {
            margin-bottom: 1.2rem;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.3rem;
            color: #555;
            font-size: 0.9rem;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: border-color 0.2s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.1);
        }
        .submit-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: background 0.2s;
            margin-top: 0.5rem;
        }
        .submit-btn:hover {
            background: #0056b3;
        }
        .error-message {
            color: #dc3545;
            font-size: 0.85rem;
            margin-top: 0.3rem;
            display: none;
        }
        .brand-note {
            margin-top: 1.5rem;
            font-size: 0.8rem;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <img src="https://admin.codebihin.in/logo.png" alt="CodeBihin Logo">
        <h2>Reset Your Password</h2>

        <form method="POST" action="update_password.php" id="resetForm">
            <!-- Token sent back to update_password.php -->
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" id="password" name="password" placeholder="Enter new password" required>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter new password" required>
                <div class="error-message" id="matchError">Passwords do not match</div>
            </div>

            <button type="submit" class="submit-btn">Update Password</button>
        </form>

        <div class="brand-note">
            <strong>Digitally Signed By</strong><br>
            Team CodeBihin IT System<br>
            Password Recovery Service
        </div>
    </div>

    <script>
        const form = document.getElementById('resetForm');
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const matchError = document.getElementById('matchError');

        form.addEventListener('submit', function(e) {
            matchError.style.display = 'none';
            confirmPassword.style.borderColor = '#ddd';

            if (password.value !== confirmPassword.value) {
                e.preventDefault();
                matchError.style.display = 'block';
                confirmPassword.style.borderColor = '#dc3545';
                confirmPassword.focus();
            }
        });

        confirmPassword.addEventListener('input', function() {
            if (confirmPassword.value === '') {
                matchError.style.display = 'none';
                confirmPassword.style.borderColor = '#ddd';
                return;
            }
            if (password.value !== confirmPassword.value) {
                matchError.style.display = 'block';
                confirmPassword.style.borderColor = '#dc3545';
            } else {
                matchError.style.display = 'none';
                confirmPassword.style.borderColor = '#28a745';
            }
        });
    </script>
</body>
</html>