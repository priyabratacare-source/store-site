<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/db.php';
$pdo = getDBConnection();

$siteName = 'CodeBihin';

$employeeId = (int)($_GET['id'] ?? 0);
if (!$employeeId) {
    header('Location: admin_attendance.php');
    exit;
}

// Fetch employee
$stmt = $pdo->prepare("SELECT * FROM Employee WHERE id = ?");
$stmt->execute([$employeeId]);
$employee = $stmt->fetch();

if (!$employee) {
    echo '<script>alert("Employee not found."); window.location.href="admin_attendance.php";</script>';
    exit;
}

// Month/Year filters
$selectedMonth = $_GET['month'] ?? date('m');
$selectedYear = $_GET['year'] ?? date('Y');

// Week off days
$weekOffDays = ['sunday', 'monday'];
try {
    $woStmt = $pdo->prepare("SELECT option_value FROM settings WHERE option_name = ?");
    $woStmt->execute(['week_off_days']);
    $woRow = $woStmt->fetch();
    if ($woRow && !empty($woRow['option_value'])) {
        $weekOffDays = explode(',', $woRow['option_value']);
    }
} catch (PDOException $e) {}

// Holiday check function
function isHoliday($pdo, $date) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM holidays WHERE holiday_date = ?");
    $stmt->execute([$date]);
    return $stmt->fetchColumn() > 0;
}

// Handle POST actions
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $attDate = $_POST['attendance_date'] ?? '';
    $punchTime = $_POST['punch_time'] ?? '09:00';
    
    if ($action === 'mark_present') {
        $fullDateTime = $attDate . ' ' . $punchTime . ':00';
        $check = $pdo->prepare("SELECT id FROM attendance WHERE employee_id = ? AND attendance_date = ?");
        $check->execute([$employeeId, $attDate]);
        if ($check->fetch()) {
            $pdo->prepare("UPDATE attendance SET status='present', punch_time=?, ip_address='manual' WHERE employee_id=? AND attendance_date=?")
                ->execute([$fullDateTime, $employeeId, $attDate]);
        } else {
            $pdo->prepare("INSERT INTO attendance (employee_id, attendance_date, punch_time, status, ip_address) VALUES (?,?,?,'present','manual')")
                ->execute([$employeeId, $attDate, $fullDateTime]);
        }
        $message = 'Marked PRESENT for ' . date('d M Y', strtotime($attDate));
    }
    elseif ($action === 'mark_absent') {
        $check = $pdo->prepare("SELECT id FROM attendance WHERE employee_id = ? AND attendance_date = ?");
        $check->execute([$employeeId, $attDate]);
        if ($check->fetch()) {
            $pdo->prepare("UPDATE attendance SET status='absent', punch_time=NULL WHERE employee_id=? AND attendance_date=?")
                ->execute([$employeeId, $attDate]);
        } else {
            $pdo->prepare("INSERT INTO attendance (employee_id, attendance_date, punch_time, status, ip_address) VALUES (?,?,NULL,'absent','manual')")
                ->execute([$employeeId, $attDate]);
        }
        $message = 'Marked ABSENT for ' . date('d M Y', strtotime($attDate));
    }
    elseif ($action === 'remove') {
        $pdo->prepare("DELETE FROM attendance WHERE employee_id=? AND attendance_date=?")
            ->execute([$employeeId, $attDate]);
        $message = 'Removed record for ' . date('d M Y', strtotime($attDate));
    }
}

// Build month data
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $selectedMonth, $selectedYear);
$attendanceData = [];
$totalPresent = 0;
$totalAbsent = 0;
$totalLate = 0;
$workingDays = 0;

for ($d = 1; $d <= $daysInMonth; $d++) {
    $date = sprintf('%s-%s-%02d', $selectedYear, $selectedMonth, $d);
    $dayName = strtolower(date('l', strtotime($date)));
    
    $attStmt = $pdo->prepare("SELECT * FROM attendance WHERE employee_id=? AND attendance_date=?");
    $attStmt->execute([$employeeId, $date]);
    $att = $attStmt->fetch();
    
    $status = 'absent';
    $punchTime = null;
    $isLate = false;
    
    if (in_array($dayName, $weekOffDays)) {
        $status = 'weekend';
    } elseif (isHoliday($pdo, $date)) {
        $status = 'holiday';
    } elseif ($att) {
        $status = $att['status'];
        $punchTime = $att['punch_time'];
        if ($status === 'present') {
            $totalPresent++;
            $h = (int)date('H', strtotime($punchTime));
            $m = (int)date('i', strtotime($punchTime));
            if ($h > 10 || ($h == 10 && $m > 0)) {
                $isLate = true;
                $totalLate++;
            }
        } else {
            $totalAbsent++;
        }
    } else {
        $totalAbsent++;
    }
    
    if (!in_array($dayName, $weekOffDays) && !isHoliday($pdo, $date)) {
        $workingDays++;
    }
    
    $attendanceData[] = [
        'date' => $date,
        'day' => $d,
        'day_name' => substr($dayName, 0, 3),
        'status' => $status,
        'punch_time' => $punchTime,
        'is_late' => $isLate,
        'holiday_name' => null
    ];
}

$percentage = $workingDays > 0 ? round(($totalPresent / $workingDays) * 100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Attendance · <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}
        body{background:#0f172a;min-height:100vh;display:flex;}
        .main{flex:1;margin-left:280px;padding:28px 36px;}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:16px;}
        .top-bar h1{color:#fff;font-size:26px;}
        .top-bar p{color:#94a3b8;font-size:13px;}
        .user-menu{display:flex;align-items:center;gap:14px;background:rgba(255,255,255,0.05);padding:8px 18px;border-radius:40px;}
        .user-avatar{background:#2f6db3;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;color:#fff;font-size:16px;}
        .user-menu .name{color:#fff;font-weight:600;font-size:13px;}
        .logout-btn{background:rgba(231,76,60,0.2);padding:7px 14px;border-radius:30px;color:#ffaaa5;text-decoration:none;font-size:12px;display:flex;align-items:center;gap:6px;}
        .logout-btn:hover{background:rgba(231,76,60,0.4);color:#fff;}
        .back-link{color:#94a3b8;text-decoration:none;font-size:13px;margin-bottom:16px;display:inline-flex;align-items:center;gap:6px;}
        .back-link:hover{color:#f9b233;}
        .alert{padding:12px 18px;border-radius:12px;margin-bottom:16px;font-size:13px;}
        .alert-success{background:rgba(46,204,113,0.15);border-left:3px solid #2ecc71;color:#a3e4bc;}
        .profile-card{background:rgba(20,35,55,0.7);border-radius:16px;padding:20px;border:1px solid rgba(255,255,255,0.06);margin-bottom:16px;display:flex;gap:16px;align-items:center;flex-wrap:wrap;}
        .profile-avatar{width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#2f6db3,#f9b233);display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:bold;color:#fff;}
        .profile-info h3{color:#fff;font-size:18px;}
        .profile-info span{color:#94a3b8;font-size:12px;display:inline-flex;align-items:center;gap:5px;margin-right:12px;margin-top:4px;}
        .badge{padding:3px 10px;border-radius:12px;font-size:10px;font-weight:600;}
        .badge-role{background:rgba(249,178,51,0.15);color:#f9b233;}
        .stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:16px;}
        .stat-card{background:rgba(20,35,55,0.7);border-radius:14px;padding:16px;text-align:center;border:1px solid rgba(255,255,255,0.06);}
        .stat-card .val{font-size:26px;font-weight:700;color:#fff;}
        .stat-card .lbl{font-size:11px;color:#94a3b8;margin-top:2px;}
        .card{background:rgba(20,35,55,0.7);border-radius:16px;padding:20px;border:1px solid rgba(255,255,255,0.06);}
        .card h4{color:#fff;border-left:3px solid #f9b233;padding-left:12px;margin-bottom:16px;font-size:16px;}
        .month-nav{display:flex;gap:8px;align-items:center;margin-bottom:16px;}
        .month-nav select{padding:8px 12px;border-radius:8px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.3);color:#fff;font-size:13px;outline:none;}
        .cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;}
        .cal-hd{text-align:center;color:#64748b;font-size:10px;font-weight:700;text-transform:uppercase;padding:8px 2px;}
        .cal-day{aspect-ratio:1;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;transition:0.2s;border:2px solid transparent;font-size:13px;font-weight:600;}
        .cal-day:hover{transform:scale(1.1);z-index:2;box-shadow:0 4px 15px rgba(0,0,0,0.4);}
        .cal-day .tm{font-size:9px;margin-top:1px;}
        .cal-day .tg{font-size:9px;text-transform:uppercase;}
        .c-present{background:rgba(46,204,113,0.15);border-color:rgba(46,204,113,0.3);color:#2ecc71;}
        .c-absent{background:rgba(231,76,60,0.15);border-color:rgba(231,76,60,0.3);color:#e74c3c;}
        .c-late{background:rgba(243,156,18,0.15);border-color:rgba(243,156,18,0.3);color:#f39c12;}
        .c-holiday{background:rgba(241,196,15,0.1);color:#f1c40f;cursor:default;}
        .c-weekend{background:rgba(255,255,255,0.02);color:#555;cursor:default;}
        .c-today{border-color:#f9b233!important;}
        .legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:12px;font-size:11px;color:#94a3b8;}
        .legend span{display:flex;align-items:center;gap:5px;}
        .legend .dot{width:10px;height:10px;border-radius:3px;display:inline-block;}

        .modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.8);z-index:999;justify-content:center;align-items:center;}
        .modal-overlay.show{display:flex;}
        .modal-box{background:#0f1a24;border-radius:16px;padding:24px;width:90%;max-width:420px;border:1px solid rgba(255,255,255,0.08);}
        .modal-box h4{color:#fff;margin-bottom:4px;font-size:18px;}
        .modal-box .mdate{color:#f9b233;font-size:14px;margin-bottom:16px;}
        .modal-box label{display:block;color:#94a3b8;font-size:12px;margin-bottom:4px;}
        .modal-box input,.modal-box select{width:100%;padding:9px 12px;margin-bottom:12px;border-radius:8px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.3);color:#fff;font-size:13px;outline:none;}
        .modal-box input:focus,.modal-box select:focus{border-color:#f9b233;}
        .btn{padding:8px 16px;border-radius:16px;border:none;cursor:pointer;font-size:12px;font-weight:600;display:inline-flex;align-items:center;gap:5px;color:#fff;transition:0.2s;}
        .btn-green{background:#27ae60;}
        .btn-green:hover{background:#1e8449;}
        .btn-orange{background:#f39c12;}
        .btn-orange:hover{background:#d68910;}
        .btn-red{background:#e74c3c;}
        .btn-red:hover{background:#c0392b;}
        .btn-gray{background:#475569;}
        .btn-gray:hover{background:#334155;}
        .modal-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;}

        @media(max-width:768px){.main{margin-left:75px;padding:16px;}.cal-day{font-size:11px;}}
    </style>
</head>
<body>
<?php include __DIR__ . '/menu.php'; ?>

<div class="main">
    <div class="top-bar">
        <div>
            <h1><i class="fas fa-user-clock"></i> Employee Attendance</h1>
            <p>Manage attendance records</p>
        </div>
        <div class="user-menu">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A',0,1)) ?></div>
            <span class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></span>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
        </div>
    </div>

    <a href="admin_attendance.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Attendance Summary</a>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Profile -->
    <div class="profile-card">
        <div class="profile-avatar"><?= strtoupper(substr($employee['name'] ?? 'E',0,2)) ?></div>
        <div class="profile-info">
            <h3><?= htmlspecialchars($employee['name']) ?></h3>
            <span><i class="fas fa-id-badge"></i> <?= htmlspecialchars($employee['id_no'] ?? 'N/A') ?></span>
            <span class="badge badge-role"><?= htmlspecialchars($employee['role'] ?? 'Staff') ?></span>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card"><div class="val"><?= $totalPresent ?></div><div class="lbl">✅ Present</div></div>
        <div class="stat-card"><div class="val"><?= $totalAbsent ?></div><div class="lbl">❌ Absent</div></div>
        <div class="stat-card"><div class="val"><?= $percentage ?>%</div><div class="lbl">📊 Rate</div></div>
        <div class="stat-card"><div class="val"><?= $totalLate ?></div><div class="lbl">⏰ Late</div></div>
        <div class="stat-card"><div class="val"><?= $workingDays ?></div><div class="lbl">📅 Working Days</div></div>
    </div>

    <!-- Calendar -->
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
            <h4><?= date('F Y', strtotime("$selectedYear-$selectedMonth-01")) ?></h4>
            <form method="GET" class="month-nav">
                <input type="hidden" name="id" value="<?= $employeeId ?>">
                <select name="month" onchange="this.form.submit()">
                    <?php foreach (range(1,12) as $m): $v=str_pad($m,2,'0',STR_PAD_LEFT); ?>
                        <option value="<?=$v?>" <?=$selectedMonth==$v?'selected':''?>><?=date('F',mktime(0,0,0,$m,1))?></option>
                    <?php endforeach; ?>
                </select>
                <select name="year" onchange="this.form.submit()">
                    <?php foreach (range(date('Y')-2, date('Y')+2) as $y): ?>
                        <option value="<?=$y?>" <?=$selectedYear==$y?'selected':''?>><?=$y?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <div class="cal-grid">
            <?php foreach (['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as $h): ?>
                <div class="cal-hd"><?=$h?></div>
            <?php endforeach; 
            $firstDay = (int)date('w', strtotime("$selectedYear-$selectedMonth-01"));
            for ($i=0; $i<$firstDay; $i++): ?>
                <div></div>
            <?php endforeach;
            foreach ($attendanceData as $d):
                $cls = 'cal-day ';
                if ($d['status']=='present') $cls .= $d['is_late'] ? 'c-late' : 'c-present';
                elseif ($d['status']=='absent') $cls .= 'c-absent';
                elseif ($d['status']=='holiday') $cls .= 'c-holiday';
                elseif ($d['status']=='weekend') $cls .= 'c-weekend';
                if ($d['date']==date('Y-m-d')) $cls .= ' c-today';
                $tg = $d['status']=='present' ? ($d['is_late']?'L':'P') : ($d['status']=='absent'?'A':($d['status']=='holiday'?'H':'W'));
                $click = !in_array($d['status'],['holiday','weekend']) ? "onclick=\"openModal('{$d['date']}','{$d['status']}','{$d['punch_time']}')\"" : '';
            ?>
                <div class="<?=$cls?>" <?=$click?>>
                    <span><?=$d['day']?></span>
                    <span class="tg"><?=$tg?></span>
                    <?php if ($d['punch_time']): ?><span class="tm"><?=date('h:i',strtotime($d['punch_time']))?></span><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="legend">
            <span><span class="dot" style="background:#2ecc71;"></span> Present</span>
            <span><span class="dot" style="background:#f39c12;"></span> Late</span>
            <span><span class="dot" style="background:#e74c3c;"></span> Absent</span>
            <span><span class="dot" style="background:#f1c40f;"></span> Holiday</span>
            <span><span class="dot" style="background:#555;"></span> Weekend</span>
            <span style="margin-left:8px;">🖱️ Click day to edit</span>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal-overlay" id="modal">
    <div class="modal-box">
        <h4>Manage Attendance</h4>
        <div class="mdate" id="modalDate"></div>
        <form method="POST" id="modalForm">
            <input type="hidden" name="attendance_date" id="fDate">
            <input type="hidden" name="action" id="fAction">
            <div id="timeRow" style="display:none;">
                <label>Punch Time</label>
                <input type="time" name="punch_time" id="fTime" value="09:00">
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-green" onclick="submitForm('mark_present')"><i class="fas fa-check"></i> Present</button>
                <button type="button" class="btn btn-orange" onclick="submitForm('mark_absent')"><i class="fas fa-times"></i> Absent</button>
                <button type="button" class="btn btn-red" id="removeBtn" onclick="submitForm('remove')"><i class="fas fa-trash"></i> Remove</button>
                <button type="button" class="btn btn-gray" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(date, status, time) {
    document.getElementById('modal').classList.add('show');
    document.getElementById('fDate').value = date;
    document.getElementById('modalDate').textContent = new Date(date+'T00:00:00').toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    document.getElementById('timeRow').style.display = (status === 'absent' || status === 'weekend' || status === 'holiday') ? 'none' : 'block';
    document.getElementById('removeBtn').style.display = (status === 'absent' || status === 'present') ? 'inline-flex' : 'none';
    if (time) document.getElementById('fTime').value = time.split(' ')[1]?.substring(0,5) || '09:00';
    else document.getElementById('fTime').value = '09:00';
}
function closeModal() { document.getElementById('modal').classList.remove('show'); }
function submitForm(action) { document.getElementById('fAction').value = action; document.getElementById('modalForm').submit(); }
document.getElementById('modal').addEventListener('click',function(e){if(e.target===this)closeModal();});
</script>
</body>
</html>