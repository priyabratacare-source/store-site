<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';
$pdo = getDBConnection();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $name = trim($_POST['role_name']);
        $desc = trim($_POST['description']);
        if (empty($name)) {
            $error = 'Role name required';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO roles (role_name, description) VALUES (?, ?)");
                $stmt->execute([$name, $desc]);
                $message = 'Role added.';
            } catch (PDOException $e) {
                $error = 'Duplicate role name.';
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $name = trim($_POST['role_name']);
        $desc = trim($_POST['description']);
        $stmt = $pdo->prepare("UPDATE roles SET role_name = ?, description = ? WHERE id = ?");
        $stmt->execute([$name, $desc, $id]);
        $message = 'Role updated.';
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $check = $pdo->prepare("SELECT COUNT(*) FROM Employee WHERE role_id = ?");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) {
            $error = 'Cannot delete role assigned to employees.';
        } else {
            $stmt = $pdo->prepare("DELETE FROM roles WHERE id = ?");
            $stmt->execute([$id]);
            $message = 'Role deleted.';
        }
    }
}

$roles = $pdo->query("SELECT * FROM roles ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Role Management · CodeBihin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}
        body{background:#0f172a;min-height:100vh;display:flex;}
        .main{flex:1;margin-left:280px;padding:28px 36px;}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px;flex-wrap:wrap;gap:16px;}
        .welcome h1{font-size:28px;color:#ffffff;font-weight:600;}
        .welcome p{color:#94a3b8;margin-top:6px;}
        .user-menu{display:flex;align-items:center;gap:20px;background:rgba(255,255,255,0.05);padding:8px 20px;border-radius:48px;backdrop-filter:blur(4px);}
        .user-avatar{background:#2f6db3;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:18px;color:white;}
        .user-info .name{font-weight:600;color:white;}
        .user-info .email{font-size:12px;color:#94a3b8;}
        .logout-btn{background:rgba(231,76,60,0.2);border:none;padding:8px 16px;border-radius:40px;color:#ffaaa5;cursor:pointer;text-decoration:none;font-size:14px;display:inline-flex;align-items:center;gap:8px;}
        .logout-btn:hover{background:rgba(231,76,60,0.4);color:white;}
        .card{background:rgba(20,35,55,0.7);backdrop-filter:blur(8px);border-radius:28px;padding:24px;border:1px solid rgba(255,255,255,0.08);}
        h2{margin-bottom:20px;color:white;font-size:24px;border-left:4px solid #f9b233;padding-left:16px;}
        table{width:100%;border-collapse:collapse;}
        th,td{padding:12px;text-align:left;color:#e2e8f0;border-bottom:1px solid rgba(255,255,255,0.05);}
        th{background:rgba(0,0,0,0.3);font-weight:600;}
        .btn{background:#2f6db3;border:none;padding:8px 16px;border-radius:20px;color:white;cursor:pointer;margin-right:8px;}
        .btn-danger{background:#e74c3c;}
        .btn-success{background:#27ae60;}
        .modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);justify-content:center;align-items:center;z-index:1000;}
        .modal-content{background:#0f1a24;padding:25px;border-radius:20px;width:400px;border:1px solid rgba(255,255,255,0.1);}
        .modal-content h3{color:white;margin-bottom:15px;}
        .modal-content input,.modal-content textarea{width:100%;padding:10px;margin:10px 0;border-radius:12px;border:1px solid #3d5e7e;background:rgba(0,0,0,0.4);color:white;}
        .modal-content button{margin-top:10px;}
        .message{padding:12px 20px;border-radius:20px;margin-bottom:20px;}
        .success{background:rgba(46,204,113,0.2);border-left:4px solid #2ecc71;color:#c8f0e1;}
        .error{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c;color:#ffcfcf;}
        @media (max-width:768px){.main{margin-left:80px;padding:20px;}}
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="main">
    <div class="top-bar">
        <div class="welcome"><h1>Role Management</h1><p>Create, edit, delete roles and assign permissions</p></div>
        <div class="user-menu">
            <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'] ?? 'A',0,1)); ?></div>
            <div class="user-info"><div class="name"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></div><div class="email"><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></div></div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Exit</a>
        </div>
    </div>
    <div class="card">
        <h2>Roles</h2>
        <button class="btn" onclick="openModal('add')">+ Add Role</button>
        <?php if ($message): ?><div class="message success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="message error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <div style="overflow-x:auto; margin-top:20px;">
            <table>
                <thead><tr><th>ID</th><th>Role Name</th><th>Description</th><th>Permissions</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($roles as $r): ?>
                    <tr>
                        <td><?= $r['id'] ?></td>
                        <td><?= htmlspecialchars($r['role_name']) ?></td>
                        <td><?= htmlspecialchars($r['description']) ?></td>
                        <td><a href="role_permissions_management.php?role_id=<?= $r['id'] ?>" style="color:#f9b233;">Assign Permissions</a></td>
                        <td><button class="btn btn-success" onclick="editRole(<?= $r['id'] ?>, '<?= addslashes($r['role_name']) ?>', '<?= addslashes($r['description']) ?>')">Edit</button>
                            <button class="btn btn-danger" onclick="confirmDelete(<?= $r['id'] ?>)">Delete</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="roleModal" class="modal">
    <div class="modal-content">
        <h3 id="modalTitle">Add Role</h3>
        <form method="POST">
            <input type="hidden" name="action" id="formAction">
            <input type="hidden" name="id" id="roleId">
            <input type="text" name="role_name" id="roleName" placeholder="Role Name" required>
            <textarea name="description" id="roleDesc" placeholder="Description" rows="3"></textarea>
            <button type="submit" class="btn">Save</button>
            <button type="button" class="btn btn-danger" onclick="closeModal()">Cancel</button>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" id="deleteId"></form>

<script>
function openModal(type, id=null, name='', desc='') {
    const modal = document.getElementById('roleModal');
    document.getElementById('modalTitle').innerText = type === 'add' ? 'Add Role' : 'Edit Role';
    document.getElementById('formAction').value = type;
    document.getElementById('roleId').value = id || '';
    document.getElementById('roleName').value = name;
    document.getElementById('roleDesc').value = desc;
    modal.style.display = 'flex';
}
function editRole(id, name, desc) { openModal('edit', id, name, desc); }
function closeModal() { document.getElementById('roleModal').style.display = 'none'; }
function confirmDelete(id) { if(confirm('Delete this role?')) { document.getElementById('deleteId').value = id; document.getElementById('deleteForm').submit(); } }
window.onclick = function(e) { if (e.target === document.getElementById('roleModal')) closeModal(); }
</script>
</body>
</html>